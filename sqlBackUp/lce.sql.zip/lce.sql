-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 14, 2016 at 04:27 AM
-- Server version: 5.5.49
-- PHP Version: 5.6.23-1+deprecated+dontuse+deb.sury.org~precise+1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `lce`
--

-- --------------------------------------------------------

--
-- Table structure for table `agreements`
--

CREATE TABLE IF NOT EXISTS `agreements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL DEFAULT '0',
  `item_type` int(11) NOT NULL DEFAULT '0',
  `member_id` int(11) NOT NULL DEFAULT '0',
  `agree_flag` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `agreements`
--

INSERT INTO `agreements` (`id`, `item_id`, `item_type`, `member_id`, `agree_flag`, `created`, `updated`) VALUES
(1, 5, 0, 1, 0, '2015-03-06 03:59:51', '2015-03-06 03:59:59'),
(2, 19, 1, 1, 0, '2015-03-06 04:00:03', '2015-03-06 04:00:05'),
(3, 18, 1, 1, 1, '2015-03-06 04:00:08', '2015-03-06 04:00:13'),
(4, 22, 1, 1, 1, '2015-03-07 17:27:28', '2015-03-07 17:41:28'),
(5, 24, 0, 1, 1, '2015-03-07 23:42:59', '2015-03-07 23:42:59'),
(6, 27, 0, 1, 1, '2015-03-19 10:28:38', '2015-03-19 10:28:38'),
(7, 29, 0, 35, 1, '2015-03-22 00:41:00', '2015-03-22 00:41:00');

-- --------------------------------------------------------

--
-- Table structure for table `albums`
--

CREATE TABLE IF NOT EXISTS `albums` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `meta_description` text NOT NULL,
  `meta_keywords` text NOT NULL,
  `header` text NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE IF NOT EXISTS `announcements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `body` longtext,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE IF NOT EXISTS `articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `meta_keywords` text NOT NULL,
  `meta_description` text NOT NULL,
  `date` datetime NOT NULL,
  `header` text NOT NULL,
  `body` longtext NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `hits` int(11) NOT NULL DEFAULT '0',
  `shared` int(11) NOT NULL DEFAULT '0',
  `like` int(11) NOT NULL,
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `creator` varchar(255) DEFAULT NULL,
  `tags` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `title`, `meta_keywords`, `meta_description`, `date`, `header`, `body`, `created`, `updated`, `hits`, `shared`, `like`, `featured`, `approved`, `creator`, `tags`) VALUES
(3, 'Managing your way through corporate politics', '', '', '2014-06-20 21:43:00', 'Managing your way through corporate politics', '<p>\r\n	No one can deny that corporate environment is becoming tougher &amp; tougher. One of the top complaints I get through surveys and workshops is corporate politics. &nbsp;This includes favoritism, fierce pragmatism, lack of transparency &amp; self absorbing, and more protection of one&#39;s interest regardless of the greater good of the people and the business&rsquo; welfare.</p>\r\n<p>\r\n	Anyhow corporate politics will remain as long as humans keep running businesses. &nbsp;So instead of fighting human condition I would like to tip you on how to manage corporate politics using some basic psychological principles.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong><u>TIP (1)</u></strong><strong>: &ldquo;<u>NEVER TAKE SIDES&rdquo;</u></strong></p>\r\n<p>\r\n	That does not mean losing your identity, it simply means stick to values &amp; not people, do not allow yourself to be labeled as part of someone&rsquo;s gang.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong><u>TIPE (2)</u></strong><strong>: &ldquo;<u>PAY ATTENTION TO THE UNSEEN</u>&rdquo;</strong></p>\r\n<p>\r\n	There are unseen people in the organization though maybe low in rank but very high in privileges &amp; you may tend to bypass them, watch out for: Secretaries, receptionists, Office Boys, Admin &amp; Security guards they have a lot of information &amp; share a lot of information. Trust me you do not want to be on their blacklist, so be NICE TO THEM.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong><u>TIP (3)</u></strong><strong>: &ldquo;<u>PRAISE YOUR BOSS IN PUBLIC</u>&rdquo;</strong></p>\r\n<p>\r\n	If you already suck up to your boss in private why not to do it in public as well, as much as your boss maybe mean, I am sure he or she gets it right from time to time when they do. &nbsp;Recognize them and be sincere.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong><u>TIP (4)</u></strong><strong>: &ldquo;<u>ITS NICE TO HAVE FRIENDS BUT NEVER MAKE ENEMIES</u>&rdquo;</strong></p>\r\n<p>\r\n	Friends will support you in the work place when you need them and if they remember. Yet enemies will wake up every morning thinking how to hurt you in ways you&rsquo;d never imagine and you can never be too careful. Potential enemies are the weak &amp; inconfident whom you may be hurting &amp; stepping on everyday unintentionally via sarcasm, contempt or casual talk.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong><u>TIP (5)</u></strong><strong>: &ldquo;<u>VENT AS YOU LIKE BUT DO NOT COMPLAIN WITHOUT SUBSTANCE</u>&rdquo;</strong></p>\r\n<p>\r\n	You will only be treated like a child and will not be taken seriously. A whiner is not a label you&rsquo;d want on your name tag.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong><u>TIP (6)</u></strong><strong>: &ldquo;<u>DON&rdquo;T MINGLE TOO MUCH WITH VICTIMZERS</u>&rdquo;</strong></p>\r\n<p>\r\n	They will only suck your energy and may turn against you instantly and once they do they will report you. And guess what, victimizers get attention &amp; sympathy.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong><u>TIP (7)</u></strong><strong>: &ldquo;<u>BOSSES GIVE GREAT ATTENTION TO MATTERS THAT MAY THREAT THEIR POSTIONS</u>&rdquo;</strong></p>\r\n<p>\r\n	Do not represent a threat to your boss, you&rsquo;ll be at the top of his priorities to get rid of you.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong><u>TIP (8)</u></strong><strong>: &ldquo;<u>DON&rdquo;T STOP IMAGINING WHAT PEOPLE MAY SAY ABOUT YOU IN CLOSED ROOMS</u>&rdquo;</strong></p>\r\n<p>\r\n	Your positioning in the organization is of great importance. What do people say about you? What are you associated with? What do you want? Questions you cannot afford not to have answers for.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong><u>TIP (9)</u></strong><strong>: &ldquo;<u>NEVER &nbsp;BE THE ONE THAT COMPLAINS FIRST</u>&rdquo;</strong></p>\r\n<p>\r\n	Just keep working and whoever takes it personal and complains about you make it about the work &amp; keep working.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong><u>TIP (10)</u></strong><strong>: &ldquo;<u>DON&rdquo;T GET INVOLVED IN GOSSIP</u>&rdquo;</strong></p>\r\n<p>\r\n	What goes around comes around. If you must be around gossip, listen &amp; do not get involved, it will get to you sometime.</p>\r\n', '2014-04-05 21:43:39', '2014-06-30 10:58:16', 1965, 0, 0, 1, 1, 'Ahmed El Aawar', 'Psychology, Interpersonal, Systems Intelligence'),
(4, 'How intercultural is your communication?', '', '', '2014-06-18 18:28:00', '', '<p>\r\n	In the academic world there is a lot of discussion on the definition of culture. Can you define a country&rsquo;s culture? There might be a lot of similarities in communication style between people who share the same country of origin, but does that mean that for example all Egyptians respond in the same way when they are in a specific situation?&nbsp; Or that all Americans prefer an informal communication style, that all Dutch are direct and that Germans are all formal and hierarchical?</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	The examples show that culture cannot be defined at the level of countries, but that it needs to be looked at in a different way. Country culture does influence the way we behave, but so do the social class we grew up in, the regions where we have lived, our gender, education, and ethnic origin etc. It is therefore better to look at culture as one dimension of difference between people.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	We are all diverse individuals who cannot be pinned down to one &lsquo;cultural framework&rsquo;. The wheel below shows the dimensions of differences<a href="#_ftn1" name="_ftnref1" title="">[1]</a> between people.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p align="center">\r\n	<img height="288" src="file:///C:/Users/lenovo/AppData/Local/Temp/msohtmlclip1/01/clip_image002.png" width="299" /></p>\r\n<p align="center">\r\n	&nbsp;</p>\r\n<p>\r\n	First it starts with personality: every person is unique, also in his or her behavior. The internal dimensions look at differences that are &lsquo;unchangeable&rsquo;. For example, you cannot change the color of your skin (unless you are Michael Jackson. The external and organization dimensions look at differences based on where you grew up, education, work experience etc.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	If you want to be an effective intercultural communicator, you need to keep these dimensions of difference in the back of your mind. If you need to do business in Egypt, there is a difference in communication style between dealing with internationally educated Egyptian businessmen or the officials of a small province. &nbsp;Many articles have been published between different leadership and communication styles of women. Gender is a dimension of difference worldwide.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	A crucial step in becoming a better intercultural communicator is knowing yourself. How do you behave in certain situations? How would you describe the culture where you grew up, that formed your character? What norms were important, what do you consider wrong or right? Should you lie to the police to protect a friend from the consequences of speeding? Or should you speak the truth about the driving speed, and let your friend face the penalty?</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	What were the implicit and explicit rules you were taught? For example, I was raised with the rule that it is not &lsquo;chic&rsquo; to talk about money issues. Our table manners were to eat with knife and fork, to wait until everybody has been served and only to get up from the table when all are done. Older people had to be treated with respect, and you should obey the law.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	What beliefs do you hold about the world; what are the things you hold for true? Are men and women equal, are all humans equal? Is there a god? Try to reflect on the different cultural groups you have been part of (family, friends, workplace) or that you are part of, and how these groups have influenced your initial values, norms and beliefs. Have they changed over time? How does a longer stay in another country impact your personal cultural framework?</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Once you have reflected on your personal &lsquo;culture&rsquo;, you can look at the society or organization you are in now. Do they share the same norms, values and beliefs? If there are differences, how do you deal with them? Are you frustrated, puzzled, offended or amused? What strategy do you have to overcome differences and build bridges between yourself and the &lsquo;others&rsquo;? Do you tend to judge the behavior of others that is different from your own standards, or are you able to switch between different (cultural) viewpoints?</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	A lot of questions to answer, and I apologize for that. But it shows that &lsquo;intercultural&rsquo; issues go beyond national borders, and are more complicated then people think. Too easily our society tends to bring differences between groups of people back to cultural differences, often insinuating one culture is superior or more advanced than the other.&nbsp; We need to go beyond that and recognize the most important dimensions of difference that play a role, in our own personal lives (as woman, professionals, mothers etc.) and in our society.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	I would love to hear your opinions or answer questions. Please send an e-mail to mvanliemt@lifecoachingegypt.com</p>\r\n<div>\r\n	<br clear="all" />\r\n	<hr align="left" size="1" width="33%" />\r\n	<div id="ftn1">\r\n		<p>\r\n			<a href="#_ftnref1" name="_ftn1" title=""><em><strong>[1]</strong></em></a><em> From Gardenschwartz and Rowe</em></p>\r\n	</div>\r\n</div>\r\n<p>\r\n	&nbsp;</p>\r\n', '2014-06-18 18:31:33', '2014-06-25 13:42:16', 1035, 0, 0, 0, 1, 'Marijke Van Liemt', 'Interpersonal, Psychology');

-- --------------------------------------------------------

--
-- Table structure for table `attachments`
--

CREATE TABLE IF NOT EXISTS `attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `file` varchar(255) NOT NULL,
  `downloads` int(11) NOT NULL DEFAULT '0',
  `node_id` int(11) NOT NULL DEFAULT '0',
  `post_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `attachments`
--

INSERT INTO `attachments` (`id`, `title`, `file`, `downloads`, `node_id`, `post_id`) VALUES
(1, '', '/2016/09/1475010688parade2011100528.jpg', 0, 0, 4),
(2, '', '/2016/09/1475010692keyboard.pdf', 0, 0, 4),
(4, '', '/2016/09/1475011192test.ppt', 0, 0, 4),
(5, '', '/2016/09/1475013458parade2011100515.jpg', 0, 0, 7);

-- --------------------------------------------------------

--
-- Table structure for table `attend_events`
--

CREATE TABLE IF NOT EXISTS `attend_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `member_id` int(11) NOT NULL DEFAULT '0',
  `attend_flag` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `attend_events`
--

INSERT INTO `attend_events` (`id`, `event_id`, `member_id`, `attend_flag`) VALUES
(1, 1, 1, 0),
(2, 5, 1, 1),
(3, 14, 3, 1),
(4, 10, 3, 1),
(5, 14, 0, 1),
(6, 14, 0, 0),
(7, 14, 0, 2),
(8, 14, 0, 1),
(9, 15, 3, 1),
(10, 17, 1, 1),
(11, 9, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `audios`
--

CREATE TABLE IF NOT EXISTS `audios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `hits` int(11) NOT NULL,
  `album_id` int(11) NOT NULL,
  `header` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blocked_members`
--

CREATE TABLE IF NOT EXISTS `blocked_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `blocked_member_id` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `weight` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `title`, `parent_id`, `approved`, `created`, `updated`, `weight`, `type`) VALUES
(1, 'Category 1', 0, 1, '2016-09-27 13:18:31', '2016-09-27 13:21:57', 0, 0),
(3, 'Category 2', 0, 1, '2016-09-27 15:32:05', '2016-09-27 15:32:05', 0, 0),
(4, 'Category 3', 0, 0, '2016-09-27 15:32:14', '2016-09-27 15:32:14', 0, 0),
(5, 'Category 4', 0, 1, '2016-10-22 22:56:58', '2016-10-22 22:56:58', 0, 0),
(6, 'Category 5', 0, 1, '2016-10-22 22:58:10', '2016-10-22 22:58:10', 0, 1),
(7, 'Category 6', 0, 1, '2016-10-22 23:00:17', '2016-10-22 23:00:17', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cats`
--

CREATE TABLE IF NOT EXISTS `cats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `body` longtext NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `meta_keywords` text NOT NULL,
  `meta_description` text NOT NULL,
  `cat_type` int(11) NOT NULL DEFAULT '0',
  `parent_id` int(11) DEFAULT NULL,
  `date` date NOT NULL,
  `under_construction` tinyint(1) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `weight` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `cats`
--

INSERT INTO `cats` (`id`, `title`, `body`, `image`, `meta_keywords`, `meta_description`, `cat_type`, `parent_id`, `date`, `under_construction`, `approved`, `created`, `updated`, `weight`) VALUES
(1, 'About us', '', '', '', '', 0, NULL, '2014-04-05', 0, 1, '0000-00-00 00:00:00', '2014-04-22 15:38:14', 1),
(2, 'Our Services', '', '', '', '', 0, NULL, '0000-00-00', 0, 1, '2014-04-20 19:11:51', '2014-04-20 19:12:39', 2),
(3, 'Our Clients', '', '', '', '', 0, NULL, '0000-00-00', 0, 1, '2014-04-20 19:12:30', '2016-06-22 12:12:19', 3),
(4, 'Workshops/Trainings', '', '', '', '', 0, 2, '0000-00-00', 0, 1, '2014-04-21 15:08:32', '2014-04-21 15:08:32', 1),
(5, 'Programs', '', '', '', '', 0, 2, '0000-00-00', 0, 1, '2014-04-21 15:09:09', '2014-04-21 15:09:09', 2),
(6, 'Executive/Business Coaching', '', '', '', '', 0, 2, '0000-00-00', 0, 1, '2014-04-21 15:09:35', '2014-06-21 00:08:42', 3),
(7, 'Coaching Certification Programs', '', '', '', '', 0, 2, '0000-00-00', 0, 1, '2014-04-21 15:10:11', '2014-12-16 23:43:40', 4);

-- --------------------------------------------------------

--
-- Table structure for table `coaches`
--

CREATE TABLE IF NOT EXISTS `coaches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `statement` text,
  `biography` text,
  `facebook` varchar(255) DEFAULT NULL,
  `linkedin` varchar(255) DEFAULT NULL,
  `video_file` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `gender` tinyint(1) NOT NULL DEFAULT '0',
  `remote_coaching` tinyint(1) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `certification` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `coaches`
--

INSERT INTO `coaches` (`id`, `name`, `statement`, `biography`, `facebook`, `linkedin`, `video_file`, `email`, `mobile`, `gender`, `remote_coaching`, `approved`, `weight`, `created`, `updated`, `image`, `certification`) VALUES
(1, 'Ashraf Helal', 'Coaching transforms lives! I''m ready with the mix of Art, Science, Practice and Passion that makes it an experience of real impact!\r\nExplore opportunities in Life & Career.. Enjoy it like a Trip!', 'Ashraf holds a coaching certificate from IDDI - Spain & accreditation from the International Coach Federation (ACC). He enjoys a significant leadership profile with 23 years of experience in multinationals. Currently, An executive director at Vodafone Egypt & member of Senior Leadership of Vodafone Global.\r\nHe has a big record of mentorship, speaking and coaching for management teams at international organizations and universities like; Henley Business School – UK, AUC, GUC, Vodafone group, Ericsson, Microsoft , L’Oreal, DMG, Omantel and others.\r\nJust like in career & group coaching, Ashraf is also a remarkable Personal-Coach. In addition to a profound scientific method, he depends on his natural interest in people and connection skills to support transformation journeys of his clients.', 'https://www.facebook.com/ReachLifeCoachingAshrafHelal/', '', '', 'test.shift.mail@gmail.com', '01006505050', 0, 1, 1, 0, '2016-06-16 14:52:42', '2016-07-16 22:10:06', 'Ashraf_Helal_Cropped_2_f9f4e.jpg', 'ACC - AMP'),
(2, 'Nouzada Hady', 'I am a high energy professional doer and motivator. My mission is to explore with you your uniqueness and how you can leverage it in your relationships and career.\r\n', 'I am a family and career coach who has spent 15+ years in the corporate business. I started my coaching career after having a solid background in counseling psychology. I completed my coach training with IDDI, a program designed and accredited by the Francisco de Vitoria University in Spain and I am an Associate Certified Coach (ACC) from the International Coaching Federation (ICF). I am passionate about making a difference in other peoples'' lives and to have a positive impact on my clients'' relationships and career goals.\r\n', '', 'https://eg.linkedin.com/in/nouzada-hady-51003029', '', 'nouzada@gmail.com', '+201008403400', 1, 1, 1, 0, '2016-06-16 15:41:23', '2016-06-25 13:48:46', 'Nouzada2_0964d.jpg', 'ACC'),
(3, 'Mona Selim', 'Believe there is more to life than simply routine.  Have a new motivation for life full of energy and passion,  and you will discover your purpose. \r\nCommit to being that person today. \r\n', '"As a Performance Management and Family Coach, I specialize in coaching athletes  with their ambitious goals. Recently I initiated a project to coach 120 Olympians.  The impact has been significant in boosting their self-confidence, motivation and goals.\r\n\r\nMy extensive experience in education has connected me with understanding families, particularly teenagers’ challenges.  It is key to discover their passion early to set the right path for success. Parents must also be accounted for. It’s imperative to reconnect with their life’s purpose despite all the responsibilities they bear.\r\n\r\n‘It’s an honor to witness a moment of revelation, an ‘Epiphany’. Only then do they know life will never be the same.’"\r\n', '', '', '', 'monaseleim@gmail.com', '01222447255', 1, 1, 0, 0, '2016-06-16 15:55:41', '2016-07-06 14:44:07', 'Mona_Seleim__1__a9bcd.jpg', 'ACC'),
(4, 'Nermeen Sobhy', 'Life coaching connects me with main value of inspiring people to improve themselves aiming to develop humanity around the globe.\r\n', 'Nermeen is a Telecom professional with 16 years of experience in multinational big organizations like Schlumberger, Vodafone and Etisalat. She is business oriented and has a diversified experience through holding senior management and leadership positions in both technical and commercial departments.\r\nNermeen is concerned about people development and was leading several committees in different organizations responsible for enhancing people’s engagement to their work and life. And she started to believe in the value of life coaching when she sensed its positive impact on development of both individuals and organizations. \r\n', '', 'https://www.linkedin.com/in/nermeen-sobhy-55255510', '', 'Nermeen.toukhy@gmail.com', '01118022255', 1, 1, 1, 0, '2016-06-16 16:30:15', '2016-06-22 12:59:36', 'Nemeen_Sobhy_7bd08.jpeg', 'MBA, Certified Assessor'),
(5, 'Nevine Eid', '"The quality of your life is the quality of your relationships" \r\nAnthony Robbins\r\n', '"It’s  all about self-awareness, acceptance, presence and improving communication skills, that  is your path to enhance your relationship with your partner, children, parents and siblings.\r\n\r\nYou just need someone to hold your hand taking your first steps to live right. \r\n\r\nThis is done through a tailored process within a safe environment provoking your thoughts and empowering you to find your own solutions.\r\n\r\nEven more complex issues holding you back such as anxiety, stress, phobia or trauma, emotional and relationship issues that seem impenetrable  are all easy to address with the help of a specialised life coach on family, parenting and relationships.\r\n\r\nAll you need is to see the true you, find your strengths, deal with your fears and hopes to transform your relationship with loved on', '', '', '', 'me@nevineid.com', '+20 122 2123510', 1, 1, 1, 0, '2016-06-16 16:35:42', '2016-07-09 13:31:15', 'Nevin_Eid_4ca8a.jpg', 'BSc. Psychology, ACC'),
(6, 'Heba farrag', 'begin your journey to Discover your life purpose,connect it with your best  potential,remove emotional blockage,improve tolerance towards life occurrences,aiming for enhanced life satisfaction.\r\n\r\n', 'Heba strives to build trust and safe encounter with her clients. She aims at creating balance between heart, mind  and soul as a means of increasing the healing ability,holding her clients responsible for transforming their goals into actions aiming for enhanced life satisfaction .  \r\nShe is:\r\nCertified life coach by ICF- International Coaching Federation,from University Francisco deVetoria,Spain.\r\nCrystal healer practitioner (healing with energy).\r\nCertified trainer.\r\nFamily counselor diploma holder.\r\nCurrently, is an Executive Manager and Trainer of Ro2ya educational curriculum\r\nHer experience in training , combined with her healing practice, and background in sociology have given her an added advantage as a coach and allowed her to relate and build deep connection with clients easily.', '', '', '', 'HEBAFARRAG75@GMAIL.COM', '+201148111788', 1, 1, 1, 0, '2016-06-16 16:51:39', '2016-07-06 15:33:11', 'HEBA_FARRAG_002_5f854.jpg', 'BSc. sociology ,DCC'),
(7, 'Laila Hussein', 'Do you want to work with someone calm, wise and creative? That’s what clients say about me.My motive in life is to help people gain clarity, confidence and new skills.\r\n', 'Coaching is a practical way of helping people gain insights and clarity, shift their thinking, grow their confidence, manage their emotions, take action and achieve their goals. The way I work is matched to who you are and what you want to achieve.\r\n\r\nI do coaching face to face in Cairo and by telephone,, skype or viber all over Egypt and internationally."\r\n', '', '', '', 'Laila.hussein@gmail.com', '+201001052222', 1, 1, 1, 0, '2016-06-16 17:04:59', '2016-06-22 12:59:19', 'Laila.JPG_4155b.jpg', 'DCC, Certified Assesor '),
(8, 'Hanady Moustafa', 'You won''t imagine how a dialogue can transform your life! Coaching helps to plunge into your self, to find answers shall unleash your inner talents. Come and discover this in a session with me.\r\n', 'Human beings are full of tiny details. To discover your self, one of the best ways is to understand these details and this is when you need a details-oriented coach like Hanady. \r\n\r\nShe listens to you actively. She uses your own words to understand your challenges and feelings. You cannot express? No need to worry; She asks you questions that delve deeply into you generating answers. This dialogue clears your vision and shifts your perspective towards yourself. This is when you discover your true self and say ""Aha"". This is when you start taking advantage of your full potential and move forward.\r\n \r\nHanady is Dialogical Certified Coach (DCC) accredited from Francisco de Vitoria University in Madrid (Spain) and Associate certified Meta Coach (ACMC) accredited from Meta Coaching Foundation', 'https://www.facebook.com/HanadyyMostafa', 'https://eg.linkedin.com/in/hanady-mostafa-a0bb6160', '', 'hanady_mostafa1@yahoo.com', '+201128833395', 1, 1, 1, 0, '2016-06-16 17:14:04', '2016-06-19 18:02:45', 'Hanady_Mostafa1_1afae.jpg', 'DCC - ACMC'),
(9, 'Abdallah Ramzy', 'Career Coach, Writer, Speaker & Trainer dedicated to your Peak Performance\r\n', 'Abdallah Ramzy is a Performance, Leadership and career Coach who has over 15 years of experience in multinational Organizations. His areas of interest and passion are in Human Performance and their careers based on their strengths and talents. He is a Master Trainer specializing in delivering Intra/Inter-personal Skills, Emotional Intelligence, Personality types and Leadership Strategies and Concepts through creative content. Abdallah holds “Dialogical Coaching Certification” from IDDI Dialogical Coaching School at Francisco de Vitoria University, Madrid, Spain. He is an Associate certified Coach (ACC) credential from International Coach Federation (ICF). He is also a coach member of the ICF Egyptian Chapter.\r\n', '', '', '', 'aramzy2020@gmail.com', '+21099929598', 0, 1, 1, 0, '2016-06-19 18:24:40', '2016-06-19 18:25:32', 'Abdallah_Photo.JPG_b52a9.jpg', 'ACC'),
(10, 'Sara Farid', 'You deserve to be happy just clear your path; coaching is my tool to help you connect with your true self, finding your purpose, enjoy living to reach inner peace and happiness.\r\n', 'Sara is a certified coach with 10 years experience of helping women explore their strength and inspiring them to achieve their full potential. \r\nConducting one to one coaching sessions,facilities group coaching and trainings.\r\nSara''s coaching is based mainly on confidentiality, openness and trust. \r\nDialogical Coaching Certification Program ACSTH.\r\nUniversdad Francisco De Vitoria.\r\nCertified trainer.\r\nEnneagram Practicener.\r\n', 'https://www.facebook.com/Sara-Farid-674476212654524/', '', '', 'sarafarid2508@gmail.com', '+21019242985', 1, 1, 1, 0, '2016-06-20 15:16:01', '2016-07-10 15:29:07', 'Sara_Farid.JPG_e08d4.jpg', 'DCC'),
(11, 'Reem El Naggar', 'Life is beautiful ... Enjoy its aroma \r\n', 'I''m a passionate life coach who has very high hopes and wishes to see people happy and fulfilled.. \r\nMy plan is to continue learning to also be a relationship coach .. Seeing the sad fact about relationships and their effect on people''s fulfilment and the following generation stability, seeing that makes me very much wanting to help there\r\n', '', '', '', 'Reemelnaggar@yahoo.com', '+201006066806', 1, 1, 0, 0, '2016-06-20 15:40:54', '2016-07-10 17:11:16', '', 'CTI and DCC'),
(12, 'Tarek Nabil', 'There is always the best version of “YOU”, even if it is buried deep & not very visible. Search for it and always connect to it. For the sake of  “YOU” & "Those WHOM YOU LOVE"\r\n', 'Tarek is a senior executive having 20+ years of progressive multinational experience in Telecoms, Internet, Technology and Oil & Gas industries across a number of Organisations and roles. Tarek has assumed several leadership roles across different disciplines as Commercial, Technology and cross functional strategy & planning. Tarek has been the Managing Director of Grapes''n''Berries - the innovative Mobile applications creators- since June 2015. \r\nTarek is an MBA holder from Maastricht school of management, during his career he worked with, managed and reported into a variety of different cultures. Tarek is an achiever who excels in setting strategies & delivery in a number of different cultures, industries and countries with a strong business and technical accumen.\r\n', '', 'https://www.linkedin.com/in/tarek-nabil-4597371?trk=hp-identity-name', '', 'tarek.nabilkamel@gmail.com', '', 0, 1, 1, 0, '2016-06-20 15:46:50', '2016-07-10 14:52:21', 'Tarek_Nabil_9ed2d.jpg', 'DCC, MBA'),
(13, 'Mona Esmail Helal', 'God does not change the condition of  people until they change what is in themselves.\r\n', 'Acting from experience. I was there before I know how it feels .\r\nI had overcome it Hamdollah and so can all of us. I am here to accompany you in this journey by highlighting the MEANING, THE BEING & THE PATH  to over come the challenge.\r\n', '', '', '', 'monaesmail@gmail.com', '+1091383438', 1, 1, 1, 0, '2016-06-20 15:57:41', '2016-07-10 17:17:52', 'Mona_Ismail.JPG_7daa8.jpg', 'DCC'),
(14, 'Esraa Zaki', 'Searching for someone to listen to you, non- judgmental, trustful and helps you to connect with the best version of you. walk with till you reach your dream and achieve your goal. Call me your Coach\r\n', 'Studied Managing Of Maritime Transport and Logistics at The Arab Academy Of Science and Technology . Worked as Assistant teacher at Heritage Canadian School.  Administration manager at Canadian Ideal School for Special Needs. Completed Art of Life Management Course. A DCC Life Coach.\r\n', 'https://www.facebook.com/Esraa-Zaki-1005847456119460/', '', '', 'esraa_yas@yahoo.com', '+201111000076', 1, 1, 1, 0, '2016-06-20 16:00:01', '2016-06-25 14:33:17', 'Esraa_81535.jpg', 'DCC'),
(15, 'Mohamed Zein', 'Business coach who will sincerely help you explore your internal treasures and discover your potential to success\r\n', 'Mohamed Zein holds a B.Sc. in Civil Engineering from Ain Shams University in Cairo-Egypt in the year of 1988.He possesses more than 25 years of rich & comprehensive experience in management, business development and sales & marketing functions with more than seventeen years of working experience in Multinational Oil Companies in local and regional assignments. Mohamed is ACC Certified (Associate Certified Coach) and also he is a member of ICF (International Coach Federation) with more than 300 coaching hours\r\n', '', 'https://eg.linkedin.com/in/mohzein66', '', 'tybaleader@gmail.com', '+201062220080', 0, 1, 1, 0, '2016-06-20 16:01:47', '2016-07-10 17:06:31', 'Mohamed_Zein_d8216.jpg', 'ACC'),
(16, 'Heba Sultan', 'Parents/teens relationships is now a great concern in so many families.\r\nDivorce, life stresses, peer pressure and other factors led to this. Helping families to break through this phase is my passion', '"I''m a German School graduate with a Bachelor of Arts from Helwan University in Tourism and Hotel management.  I''m also a professional behaviors & motivators analyst and I got my “Dialogical Life Coaching Diploma” from University of Francisco de Vitoria (Madrid) in cooperation with Life Coaching Egypt.  \r\n\r\nOne day I decided that I will stop doing "What I have to do" and start doing "What I want to do". That decision led me to a journey back to myself. I learned a lot through this journey, but the most important lesson I learned is that we are all here for a reason, we have a mission and God gave us all the tools needed for that mission. \r\nWe just need to find the reason, the purpose and most of all find our true selves.\r\nI hope to help others through this beautiful journey. So help me God', 'www.facebook.com/coachiology', '', '', 'hsultan92@gmail.com', '+20100 5144939', 1, 1, 1, 0, '2016-06-20 16:04:51', '2016-07-10 17:13:29', 'Heba_Sultan_3db4f.jpg', 'DCC'),
(17, 'Ebtihal Taha', 'Anything I do, I do with passion\r\n', 'I am passionate about helping people get together, whether teams in  the corporate world or blended families. Growing roots to stand strong and withstand every day struggles.\r\n', '', 'https://www.linkedin.com/in/ebtihal-taha-a1688491', '', 'et_taha@yahoo.com', '+201008183077', 0, 1, 1, 0, '2016-06-23 15:48:34', '2016-06-23 16:01:01', 'Ebtihal_Taha_10f61.png', 'DCC, Certified Trainer'),
(18, 'Eman Reda', ' Your journey has moulded you for greater Good. It''s exactly the way it needed to be; NO time lost. It took Each and Every situation you''ve encountered to bring you to Now. And Now is''Right on Time''.', '"In a moment of recognition and awerness . Things become clearer and begin to flow more easily into my life and I gained a sense of purpose. I started changing the  the way l move through the world, and allow my self to sense the inner peace and stillness to govern my actions and reactions. Self awareness is not an easy path, but it is filled with blessings, magic, and opportunities to live with greater love, joy, and fulfillment than ever before, and had brought me to alliance with my highest purpose; Believing that in being yourself in a world that is constantly trying to make you someone else is your greatest accomplishment...\r\n"" From this I understand that \r\nwhat I want also wants me,\r\nis looking for me and attracting me.\r\nThere is a great secret here \r\nfor anyone who can grasp it..."', '', '', '', 'emanmohreda@gmail.com', '+201005805738', 1, 1, 0, 0, '2016-06-23 15:57:23', '2016-07-10 17:20:22', 'Eman_Reda_a93c8.jpg', 'DCC, Reiki Practicioner'),
(19, 'Rasha Reyad', 'Unleash Your Powers', 'Loving human beings; accepting them; helping them to thrive all the time; yet specifically in critical times -- is my Passion.\r\nI use coaching (my passion) as a tool to increase one ''s awareness about his/ her potentials & capabilities; to  make use of them through their different challenges, also as a tool to align their encounters  with their purpose in life.\r\nWhile discovering the challenge together; not just the words you say are heard also the emotions created them, using thoughtful questions to offer you deeper insight , we begin to perceive your issues under different lights, increasing new awareness and ultimate options for positive change that we agree on how to practice.\r\nwilling to challenge yourself to grow more from your challenges is what makes our coaching  journey enjoyable', '', '', '', 'sha7111981@hotmail.com', '+201002555396', 0, 1, 1, 0, '2016-06-23 16:17:43', '2016-07-10 14:49:29', 'Rasha_Reyad_bf9e9.png', 'DCC, NLP Practitioner'),
(20, 'Rania Fouad', 'I believe that coaching assists people to actually live their dream as they start to see life differently, enjoy it and get all their dreams into reality.\r\n', 'Rania Fouad is a passionate life coach who inspires her clients with great positive energy assisting them in knowing their value, utilizing their resources, taking suitable decisions, looking to issues from different perspectives, moving towards more success in life, leading the change in their characters and in their lives, having more healthy relationships and having more fulfilling happier lives. She is a good listener with a calm simple and cheerful personality which allows clients to open smoothly in their talk which accordingly reflected on the fruitfulness of the coaching process.\r\n', 'https://www.facebook.com/pages/Rania-Fouad-Life-Coach/529379067215745', '', '', 'raniafouadfawzy@gmail.com', '+201145582448', 1, 1, 0, 0, '2016-06-23 16:52:28', '2016-07-06 14:40:44', '', 'DCC'),
(21, 'Malaka Ibrahim', 'Unleashing the potential in people\r\n', 'I have been in Corporate for the past 15 years, handling different assignments in different multinationals, all in Human Resources where i have reached senior positions. Being in contact with the people side, i came to see how much potential people would have and have always been longing to do more. After I finished my certification as a life coach, i became sure thats exactly what i want to do.  I have unlearned to assess and evaluated people, to more wonder and care to support them grow and be in their best shape.\r\n', '', 'https://www.linkedin.com/m/?sessionid=3450317989478400#', '', 'malaka.ibrahim@hotmail.com', '+201002800023', 1, 1, 1, 0, '2016-06-23 16:57:00', '2016-07-10 14:42:36', 'Malaka_ccfc0.jpg', 'DCC'),
(22, 'Rania Sabrah', 'I consider my mission as a life coach is to help others reconnect with themselves, with their inner true self, and to handle their imperfections from place of worthiness.\r\n', 'I have a passion in accompanying people in their journey, I can achieve few goals in my life, but accompanying people in their goals make me achieve them all. \r\nI have 20 years of professional experience in different fields, in different countries, and different organizations, this diversity gave me the ability to understand people accept them and  recognize that people capabilities are unlimited.\r\nI had the opportunity to acquire life coaching course from the respectable ""Life Coaching Egypt"" and IDDI institute Madrid. Where I learned from the best professionals in the field worldwide tailored to our Egyptian culture. All my clients have felt the value, they found it a life changing experience they could notice the change in themselves and people around them recognized the change too.', 'https://m.facebook.com/Space-Center-453944924800373/', '', '', 'rania.sabrah@gmail.com', '+201118525257', 1, 1, 1, 0, '2016-06-23 17:06:11', '2016-07-10 17:09:35', 'RaniaSabrah_a61f5.jpg', 'ACC, MSc.'),
(23, 'Rania Salah', 'I help my clients to identify their careers and work motives using different techniques, developing different  skills and enhancing self-awareness using the MBTI profile.\r\n', 'Rania is having 19 years of experience in management & leadership positions in the Telecom industry. In-depth 13 years in the Human Resources, career progression, performance management,learning & development. \r\nRania’s coaching is based mainly on Confidentiality, Trust & Openness, during the session she adapts a flexible approach that focuses on enabling her client to reflect, develop, aspire & achieve.\r\nCertificates:\r\n·  Associate Certified Coach (ACC) from the International Coaching Federation\r\n·  Dialogical Coaching Certification Program ACSTH – Universidad Francisco De Vitoria\r\n·  Certified MBTI Step I &II practitioner\r\n·  Certified Psychometric Tests Professional\r\n·  Haylite Reports (360, Climate, Leadership styles) Feedback Accredited\r\n·  Enneagram practitioner\r\n·  Certified Trainer', '', 'https://www.linkedin.com/in/rania-salah-976263?trk=hp-identity-photo&_mSplash=1', '', 'Rania8salah3@gmail.com', '+201005003339', 1, 1, 1, 0, '2016-06-25 13:43:53', '2016-07-10 14:47:33', 'Rania_Salah_706a4.jpg', 'ACC'),
(24, 'Heba Galal', 'Explore your uniqueness & your inner authentic self, discover values & barriers, create awareness & get prepared to independently achieve your dreams, self-actualization, fulfilment & happiness. \r\n', 'Heba is passionate to create companionship with people seeking change in their lives, with a strong believe that in every boundary there’s an opportunity waiting for us to take.\r\nHer clients appreciates her genuine presence, active listening & empathy, taking them to unexplored territories with creative tools that inspire actions & encourage long term solutions.\r\nTrained & certified by an international certification program of Dialogical Coaching program delivered by “Francisco De Vitoria University in Madrid” & “Life coaching Egypt”. Prior her coaching education, she was graduated with honor in Languages & Translation, Spanish Major, 6th of October University, then took out her Diploma in Tourism Guidance, Helwan University, in addition to a diversity of courses in Human Development.', '', '', '', 'heba.guide@gmail.com', '+201274628646', 1, 1, 1, 0, '2016-06-25 13:51:47', '2016-07-10 14:35:16', 'Heba_Galal.JPG_2d240.jpg', 'DCC'),
(25, 'Hala El Hawary', 'Passionate about helping  people, advocating on their behalf to find  their most fulfilling  lives goals and  she decided to focus  on coaching and studying human behavior\r\n', 'Hala is a coach, motivational speaker, & corporate trainer. \r\nHala has a corporate experience of more than 30 years experience across the different HR functions spanning Organizational Strategy and Development, Job Analysis and Profiling and Evaluation, Performance Management, Recruitment and Selection, Salary Structuring, Talent Management, Training needs analysis , & planning and evaluation in foreign and local banks. \r\nHala is the General Manager of Training & Development & Performance Management sector in Banque Misr, whose accountabilities include setting overall training strategy in alliance to the Bank’s overall goals.\r\n', '', '', '', 'Halaelhawary1@Gmail.com', '+201009991484', 1, 1, 1, 0, '2016-06-25 13:56:54', '2016-07-10 14:32:58', 'Hala_dbf03.jpg', 'DCC'),
(27, 'Mai Nabil', 'Hope, Trust and confidence are all what I can offer for anyone to overcome and defeat his challenges, Self discovery journey will help revealing the power you didn''t know or forgot it existed in you ', 'I graduated from faculty of commerce and completed a diploma in economics, since 18 years ago I joined banking sector and have been promoted to be a manger, a long my journey my job has helped me to be a good listener and quick problem solver, many skills have been acquired throughout my journey dealing with people from different backgrounds taught me how to accept differences between human beings and flexibilty. I don''t like drama, although I had tons of it, alongside challenges in my life, but I choose to accept it, overcome it and learn from it. My life changing moment was inspired by positivity and wanting to expand my comfort zone, I decided to appreciate peoples individuality and help them explore and overcome their challenges, while disposing stereotypes and exaggeration  \r\n', '', '', '', 'mai_nabeel@hotmail.com', '+201001720194', 1, 1, 1, 0, '2016-06-25 14:01:11', '2016-07-10 14:40:39', 'Mai_Nabil.JPG_82259.jpg', 'DCC'),
(28, 'Marwa Elmougy ', 'Coaching for me means the path that allows human''s growth on all aspects \r\nLife is unfolded for you in a way to being you clear \r\nCoaching is the true encounter that helps to connect to your trueself', 'I followed my Instinct & passion of human empowerment & development  which I found in Coaching. \r\nI have completed the fundamental course of the Dialogical coaching certification from Universidad Francisco De Vitoria-Madrid which is approved by the Internatioal Coaching Fedration (ICF) \r\nI am coming from a banking career which added to my qualifications & competencies \r\nMy approach in coaching is based on my belief that all humans were born with unique resources that helps them to perform their chapter in life in a unique & enjoyment way. \r\nWe all have ambition & obstacles, ups & downs, enthusiasm & stress.\r\nMy role is to help you in identifying , empowering your potentials & utilize them in a way that makes you happy \r\nThe essence of my coaching style is the authenticity & confidentiality', '', '', '', 'me20@mohamedelsayed.net', '+2 01111414011', 1, 1, 1, 0, '2016-06-25 14:03:42', '2016-07-18 00:38:33', 'Marwa_Elmougy.JPG_628f3.jpg', 'DCC'),
(29, 'Eman Rifaat Ghobashi', 'Our life is whole!\r\nI have the blend of knowledge and experience to accompany you in your career journey that can transform your life as well as life journey that can boost your success!\r\n', 'Unleash your potentials stepping in a future of no regrets!\r\nEman comes with a rich 17 years experience in multinationals.\r\nThis acts as a decent foundation for her coaching career that is complemented by business NLP and dialogical coaching certificates.\r\nEman''s experience diversely  includes Leadership for big teams, customers'' experience and offshoring.\r\nHer passion is career coaching where she coaches individuals as an instrumental part for corporate transformation as well as their own personal success!\r\n', '', 'https://eg.linkedin.com/in/eman-rifaat-472a502', '', 'eman.rifaat@vodafone.com', '+201001005333', 1, 1, 1, 0, '2016-06-25 14:06:05', '2016-07-10 14:30:58', 'Eman_Rifaat_f280e.jpg', 'DCC'),
(30, 'Ola Bennis', 'Health and happiness mean the world to me, happy to spread them everywhere\r\n', 'As I''ve noticed most of my clients who come for nutrition coaching have a hidden reasons for their weight disorders, I decided to help them discover their hidden reasons and lead them to healthier and happier versions of themselves. \r\nThrough my journey as a nutritionist I discovered that everyone defines health differently. To me, health is not just a number on the scale, it''s a state of mind, a feeling of soul, a fit body and a happy heart. A state of well-being. It''s about your looks, your confidence, your happiness when you look to yourself in the mirror, a life style and above all being a healthy you. That''s why I''m here to help you discover the treasures you behold and reflect them on your actions. I''m here to help you set realistic goals and join you on a journey to fulfillment.', 'https://www.facebook.com/Ola-Bennis-Health-Coach-1474817109481242/', '', '', 'olabennis@gmail.com', '+201000688086', 1, 1, 1, 0, '2016-06-25 14:16:01', '2016-07-10 16:58:13', 'Ola_Bennis.JPG_a6327.jpg', 'DCC'),
(31, 'Dina El Rafie', 'Every challenge has a solution. The solution lies within you, the solution is you. I love to help you find it. I love to see you grow happy\r\n', 'Every since is was young I was always that person that people turn to and share their challenges with which I gladly listen and enjoy helping them out. This hobby continued to grow within me and everyday I enjoy it more and more. \r\n\r\nNow I am DCC certified and working on my ACC and very passionate about it as that will help me fullfill my passion. I decided to help as much people as I can to solve their challenges and enjoy life from a different prespective and with inner peace. I want to see people happy, meet them with in tears or anxieties, leave them with a smile. That is my role in life and I will always work towards it.\r\n', '', '', '', 'elrafie@aucegypt.edu', '+201222775036', 1, 1, 1, 0, '2016-06-25 14:18:04', '2016-07-10 14:29:04', 'Dina_El_Rafie_2bdf8.jpg', 'DCC'),
(32, 'Sarah Fathalla ', '"Discovering the truth  about ourselves is a lifetime''s work ,but it is worth the  effort"\r\nFred Rogers (Mr.rogers)\r\nAs for me, do your  best  & Allah will do the rest."\r\n', 'Do your best to discover what you were born to do, do your best to unlock the full potential that''s in you and passionately pursue your dreams.\r\n \r\nI look back over my career in business , I discovered that each forward step I took. Was because I decided to take charge of my self and be the pillar of my life.\r\n\r\nI love empowering others to take charge of their lives. I love helping others see their true worth because .I have had experiences and people like my own coach who have helped me to be able to see my self with new eyes. And use all my best to be who really I am.\r\n\r\nAnd that led me to be a coach and walk beside  others in their own life journeys.\r\n\r\nSo,what is your best to do?\r\n', '', '', '', 'sarahessamfathlla@gmail.com', '+201006639339', 1, 1, 1, 0, '2016-06-25 14:20:05', '2016-07-10 16:55:51', 'Sara_Fathalla.JPG_1240c.jpg', 'DCC, MBA'),
(33, 'Menna Samy', 'Life Coaching is a Journey of Awareness, Reflection and Enlightenment, that Fulfils and Empowers\r\n', 'Human Development Expert and Trainer, with diversified experience working with all organizational levels. Studied Human Resources & Organizational Behavior at the German University in Cairo. Passionate about Human Development through different ways, one of them is Life Coaching. Life Coaching to me is a Journey of Awareness, Reflection and Enlightenment, that Fulfills and Empower. Joining the Dialogical Coach Certification Program with “Universidad Francisco De Vitoria” (approved by the International Coach Federation), was a Milestone in my path to serve my Life Purpose and to keep me aligned with my Values. I believe in my clients'' potential to achieve what they aim for, through working together discovering their own meaning and purpose, while finding the path to fulfilment and success.\r\n', '', '', '', 'mennasamy.lifecoaching@hotmail.com', '+2 01006665588', 1, 1, 1, 0, '2016-06-25 14:30:20', '2016-07-06 14:15:26', 'Menna_Samy_96017.jpg', 'DCC'),
(34, 'Ahmed El Aawar', 'I will hold you big, stretch you beyond your expectations like you''ve never experienced before!', 'Ahmed is a Certified Corporate Coach (ICF) accredited with more than 4000 hours of coaching individuals, executives, and business owners. He is one of the pioneers in the area of professional coaching in Egypt. Ahmed leverages his rich business background as an ex CEO of a leading restaurant business, 21 years of experience in senior management positions as CEO and Vice Chairman, along with being a Certified Board member on multiple multinational companies.\r\nEducation\r\n• MA Cognitive Psychology from Columbia University (USA)\r\n• Currently PhD student at the University College of London since 2014 in Organizational Psychology\r\n• Co-active certified personal coach (CCPC), CTI, USA\r\n• PCC \r\n• Cognitive Behavioural Therapist, Arthur Freeman Institute, USA\r\n• Enneagram Instistute, Stoneridge, NY', 'https://www.facebook.com/ahmedelaawar', '', '', 'ahmedsaeedelaawar@gmail.com', '+2 01009870000', 0, 1, 1, 0, '2016-07-06 15:48:22', '2016-07-10 14:27:12', 'Aawar_7d692.jpg', 'PCC MA Cognitive Psychology'),
(35, 'Shehab Azmy', '"My job is to Make Your quote Come true" ', 'Shehab is a certified coach to help people know How to live their life, manage It, Enjoy It and not to waste Any single moment of It without happiness, Joy, Being positive, full of energy, Being strong and motivated for every challenge.\r\nShehab is trained for individual coaching and group coaching to Let You find Who You Really Are, to Get The Best out of You.\r\nTogether You Will discover Who You Are, What Are Your values, The True You, What Can You Do, What Did you forget about Your self, How to treat Your self, to celberate with Your self. to find You The True inner You. \r\nShehab belives that "My aim Is to Make You alive Not Just living.', 'https://www.facebook.com/ShehabAzmyLifeCoach/', '', '', 'shehabazmy@yahoo.com', '+2 01025555999', 0, 1, 1, 0, '2016-07-06 16:13:59', '2016-07-11 14:07:31', 'Shehab_Azmy_c936d.jpg', 'DCC'),
(36, 'Hend Eissa', '"Never settle for less in life than what\r\nyou were intended for!"\r\n', '"I’m an Associate Certified Coach (ACC) from the International Coaching \r\nFederation (ICF) and a founding member in the ICF Egypt Chapter. I’m also among the first local trainers teaching the Dialogical Coaching Program in Egypt, and a member of the life coaching team preparing the Egyptian Olympics National Team athletes representing Egypt in Rio Olympics.\r\nI’ve roamed the private sector for 12 years holding top marketing posts in both local & multinational companies, till I discovered that nothing gives me a greater satisfaction in life more than serving people. \r\nThrough Life Coaching, I help my clients grow, pursue their dreams and achieve their life balance. I build authentic, energizing, respectful, and trustworthy relationships with my clients, so looking forward to welcome you soon', '', '', '', 'hend_eissa@yahoo.com', '+201111144557', 1, 1, 1, 0, '2016-07-10 14:58:40', '2016-07-10 15:12:22', 'Hend_Eissa_31c6b.jpg', 'Associate Certified Coach (ACC)'),
(37, 'Mohamed Mustafa', 'Reviving lives for better world \r\n', '"Life''s a journey. Everyday we face different challenges and choices which define our destiny.\r\n\r\nI am passionate about helping you find your own way in life. Discover your true self and perform the role intended for you in this life. Transform your life and live your own story. \r\n\r\nWe will work together to set down your goals, define your priorities and draw your life roadmap."\r\n', 'https://www.facebook.com/mohamed.dynamo', '', '', 'mohamed.dynamo@gmail.com', '+201006858822', 0, 1, 1, 0, '2016-07-10 15:06:55', '2016-07-10 16:56:11', 'Mohamed_Mostafa_454bf.jpg', 'DCC'),
(38, 'Yasmine Sarhan', 'I would love to accompany you through your journey of self-discovery, self-growth and personal fulfilment. ', '"The aim of my work as a coach is to empower my clients to write the story of their lives while realizing happiness, meaning and purpose. The main pillar for that is my trust in the potentiality of human beings and the transformation that happens as a consequence of heightened awareness and hence an increased sense of responsibility. \r\nMy coaching style is very subtle yet very effective. I have been endowed with calmness, trust, openness and compassion, which establish a deep connection bonding me with my client and welcoming his/her presence with mine. In this safe space my client and I start understanding the aspirations, exploring feelings, challenging thoughts, seeing things from different perspectives and recognizing areas for fulfillment and growth. "', '', '', '', 'ysarhan@lifecoachingegypt.com', '+2 01067488775', 1, 1, 1, 0, '2016-07-10 15:19:35', '2016-07-10 15:20:12', 'Yassmine_Sarhan_0dd08.jpg', 'ACC');

-- --------------------------------------------------------

--
-- Table structure for table `coaches_geographys`
--

CREATE TABLE IF NOT EXISTS `coaches_geographys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `coach_id` int(11) NOT NULL DEFAULT '0',
  `geography_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `coaches_specializations`
--

CREATE TABLE IF NOT EXISTS `coaches_specializations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `coach_id` int(11) NOT NULL DEFAULT '0',
  `specialization_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=66 ;

--
-- Dumping data for table `coaches_specializations`
--

INSERT INTO `coaches_specializations` (`id`, `coach_id`, `specialization_id`) VALUES
(1, 1, 2),
(2, 1, 1),
(3, 5, 1),
(4, 5, 3),
(6, 2, 2),
(7, 3, 2),
(8, 3, 6),
(9, 8, 1),
(10, 8, 4),
(11, 4, 2),
(12, 4, 3),
(13, 7, 1),
(14, 7, 2),
(15, 6, 1),
(16, 6, 4),
(17, 9, 2),
(18, 10, 1),
(19, 10, 4),
(20, 11, 1),
(21, 12, 1),
(22, 12, 7),
(23, 13, 1),
(24, 16, 1),
(25, 16, 3),
(26, 15, 7),
(27, 15, 5),
(28, 14, 1),
(29, 14, 4),
(30, 18, 1),
(31, 18, 4),
(32, 17, 3),
(33, 17, 5),
(34, 19, 1),
(35, 20, 2),
(36, 20, 4),
(37, 21, 2),
(38, 21, 4),
(39, 22, 2),
(40, 22, 5),
(41, 23, 2),
(42, 23, 7),
(43, 2, 3),
(44, 24, 1),
(45, 25, 1),
(46, 25, 5),
(48, 27, 1),
(49, 28, 1),
(50, 29, 1),
(51, 29, 2),
(52, 30, 1),
(53, 30, 6),
(54, 31, 1),
(55, 31, 4),
(56, 33, 1),
(57, 33, 4),
(58, 34, 1),
(59, 34, 7),
(60, 35, 1),
(61, 35, 4),
(62, 36, 1),
(63, 37, 1),
(64, 37, 2),
(65, 38, 1);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `created` datetime NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `article_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `contents`
--

CREATE TABLE IF NOT EXISTS `contents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `body` longtext NOT NULL,
  `map_iframe` longtext,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `mail` varchar(255) DEFAULT NULL,
  `facebook_link` varchar(255) DEFAULT NULL,
  `linkedin_link` varchar(255) DEFAULT NULL,
  `working_hours` text,
  `inner_title` varchar(255) DEFAULT NULL,
  `forum_flag` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `contents`
--

INSERT INTO `contents` (`id`, `title`, `body`, `map_iframe`, `address`, `phone`, `mail`, `facebook_link`, `linkedin_link`, `working_hours`, `inner_title`, `forum_flag`) VALUES
(1, 'Contact Us', '<p>\r\n	Kindly send us a message and we will get back to you the soonest</p>\r\n', '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3451.6925017661433!2d31.37417462215797!3d30.102991764325335!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14581614a596a26b%3A0x959abef9901227e2!2z2LPZitivINiy2YPYp9ix2YrYpw!5e0!3m2!1sar!2seg!4v1403997863417" width="600" height="450" frameborder="0" style="border:0"></iframe>', '22 Sayed Zakareya Khalil St., Sheraton Heliopolis', '(002) 0100 9870000', 'info@lifecoachingegypt.com', 'https://www.facebook.com/groups/175047865085/', '', '', 'Send us a message', 0),
(2, 'Terms and Conditions', '<ul>\r\n	<li>\r\n		<span style="font-size:14px;">LCE accepts the following credit cards:</span>\r\n		<ul>\r\n			<li>\r\n				<span style="font-size:14px;">Visa</span></li>\r\n			<li>\r\n				<span style="font-size:14px;">MasterCard</span></li>\r\n			<li>\r\n				<span style="font-size:14px;">JCB</span></li>\r\n		</ul>\r\n	</li>\r\n	<li>\r\n		<span style="font-size:14px;">Online payments are secure:</span>\r\n		<ul>\r\n			<li>\r\n				<span style="font-size:14px;">Payments will be processed directly by the MiGS Payment Gateway using Secure Socket Layer (SSL) technology.</span></li>\r\n			<li>\r\n				<span style="font-size:14px;">Credit card numbers are protected with a high level of encryption when transmitted over the Internet.</span></li>\r\n			<li>\r\n				<span style="font-size:14px;">LCE does not have access to your credit card details.</span></li>\r\n		</ul>\r\n	</li>\r\n	<li>\r\n		<span style="font-size:14px;">LCE will confirm your payment details via email.</span></li>\r\n	<li>\r\n		<span style="font-size:14px;">By using LCE&#39;s online payment facilities, you agree to all applicable LCE policies relating to your Internet resources.</span></li>\r\n	<li>\r\n		<span style="font-size:14px;">LCE&#39;s Terms and Conditions for online payments are subject to change at any time. Each transaction shall be subject to the specific Terms and Conditions that were in place at the time of the transaction.</span></li>\r\n</ul>\r\n', '', '', '', '', '', '', '', '', 0),
(3, 'Welcome note', '<p>\r\n	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(4, 'Happening now', '<p>\r\n	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE IF NOT EXISTS `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `time_from` time NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `brief` longtext,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `duration` int(11) NOT NULL DEFAULT '1',
  `time_to` time NOT NULL,
  `ticket_price` int(11) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `image` varchar(255) DEFAULT NULL,
  `instructors_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `agenda_word_file` longtext,
  `minutes_of_meeting_file` longtext,
  `p_and_l_sheet` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `from_date`, `to_date`, `time_from`, `location`, `brief`, `member_id`, `created`, `updated`, `approved`, `duration`, `time_to`, `ticket_price`, `weight`, `image`, `instructors_id`, `type`, `agenda_word_file`, `minutes_of_meeting_file`, `p_and_l_sheet`) VALUES
(6, 'xss', '2016-09-18', '0000-00-00', '23:41:00', 'ssss', '<p>\r\n	sss</p>\r\n', 0, '2016-09-18 23:42:37', '2016-09-19 00:11:13', 1, 1, '23:41:00', 1, 0, '2K511782_0f195.jpg', 0, 0, NULL, NULL, NULL),
(8, 'ssss', '2016-09-18', '0000-00-00', '23:44:00', 'ss', '<p>\r\n	sss</p>\r\n', 0, '2016-09-18 23:44:50', '2016-09-18 23:44:50', 0, 1, '23:44:00', 1, 0, '', 0, 0, NULL, NULL, NULL),
(9, 'cs', '2016-09-18', '0000-00-00', '23:45:00', '', '', 0, '2016-09-18 23:45:44', '2016-09-19 01:52:32', 0, 1, '23:45:00', 1, 0, '', 0, 0, NULL, NULL, NULL),
(10, 'qqq', '2016-09-19', '2036-01-01', '00:57:00', 'q', '', 0, '2016-09-19 00:58:28', '2016-09-23 05:11:27', 1, 1, '00:57:00', 1, 0, '', 0, 2, 'https://docs.google.com/document/d/1OhBiRW2tefmnPoJWOzPdVF-tVSQm2QtnaaKoOs74FAA/edit', 'https://docs.google.com/document/d/1OhBiRW2tefmnPoJWOzPdVF-tVSQm2QtnaaKoOs74FAA/edit', ''),
(13, 'hhh', '2016-09-20', '0000-00-00', '21:34:00', '', '', 0, '2016-09-20 21:34:29', '2016-09-20 21:34:29', 0, 1, '21:34:00', 1, 0, '', 0, 1, NULL, NULL, NULL),
(14, 'Test Event 1', '2016-09-11', '2016-09-13', '01:29:00', 'Cairo', '<p>\r\n	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit</p>\r\n<p>\r\n	in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n', 0, '2016-09-21 01:29:56', '2016-10-18 09:59:49', 1, 1, '02:29:00', 0, 0, '2y811899_929f2.jpg', 0, 0, NULL, NULL, NULL),
(15, 'hhhhh', '2016-09-23', '2016-09-23', '04:06:00', '', '', 0, '2016-09-23 04:06:25', '2016-09-23 04:06:25', 1, 1, '04:06:00', 0, 0, '', 0, 1, NULL, NULL, NULL),
(16, 'Test Url #1', '2016-09-24', '2016-09-24', '22:33:00', '', '', 0, '2016-09-24 22:34:13', '2016-09-25 00:58:02', 1, 1, '22:33:00', 0, 0, '', 0, 2, '', '', ''),
(17, 'dddd', '2016-10-08', '2016-10-08', '02:19:00', '', '', 0, '2016-10-08 02:19:42', '2016-10-08 02:19:42', 1, 1, '02:19:00', 0, 0, '', 0, 1, NULL, NULL, NULL),
(18, 'sssss', '2016-10-08', '2016-10-08', '03:32:00', '', '', 0, '2016-10-08 03:32:17', '2016-10-08 03:32:17', 0, 1, '03:32:00', 0, 0, '', 0, 1, NULL, NULL, NULL),
(19, 'Test Event 100', '2016-10-28', '2016-10-18', '06:34:00', '', '', 0, '2016-10-15 06:34:48', '2016-10-22 23:41:36', 1, 1, '06:34:00', 1, 0, '13179430_1212667675440632_566650885497591201_n_ca717_08dd8.jpg', 0, 0, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `events_instructors`
--

CREATE TABLE IF NOT EXISTS `events_instructors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `instructor_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `events_instructors`
--

INSERT INTO `events_instructors` (`id`, `event_id`, `instructor_id`) VALUES
(1, 6, 2),
(2, 9, 8),
(3, 14, 2),
(4, 14, 5),
(5, 19, 2);

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE IF NOT EXISTS `faqs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL,
  `answer` text NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `weight` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`id`, `question`, `answer`, `approved`, `created`, `updated`, `weight`) VALUES
(1, 'What is Coaching?', '<p>\r\n	Coaching in essence is a process of deep connection that enables learning and development to occur.&nbsp; It is a combination of art and science that helps individuals reach state of awareness about their full profile, seeing clearly, the limitations, path for growth and areas to accept.</p>\r\n', 1, '0000-00-00 00:00:00', '2014-08-18 13:12:05', 1),
(2, 'Do you work with individuals or only corporates?', '<p>\r\n	We &nbsp;work with both.&nbsp; Other than the corporate profile, we do one on one coaching for individuals and we sometimes hold public sessions.</p>\r\n', 1, '2014-04-19 22:31:24', '2014-06-28 18:06:01', 3),
(3, 'If I need to hire a coach, what should I do?', '<p>\r\n	You can send us a request through &ldquo;Contact Us&rdquo;, and we will get back to you.</p>\r\n', 1, '2014-06-28 18:04:09', '2014-06-28 18:06:36', 4),
(5, 'What are the differences between coaching, mentoring and counselling?', '<p>\r\n	Some people can get confused between coaching and mentoring in business, or between coaching and mentoring on the personal level. &nbsp;To help you differentiate between these three roles of helping, below is a brief definition of each:</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<u>Coaching:</u> helping another person improve awareness, to set and achieve goals in order to improve a particular behavioral performance</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<u>Mentoring:</u> helping an individual shape the beliefs and values in a positive way; often a long term career relationship with someone (the mentor) who has &#39;done it before&#39;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<u>Counselling:</u> helping an individual improve performance by resolving situations from the past</p>\r\n', 1, '2014-06-28 18:23:05', '2014-08-18 13:11:15', 2);

-- --------------------------------------------------------

--
-- Table structure for table `forum_comments`
--

CREATE TABLE IF NOT EXISTS `forum_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` longtext NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  `attachement` varchar(255) DEFAULT NULL,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `post_id` int(11) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `forum_comments`
--

INSERT INTO `forum_comments` (`id`, `comment`, `image`, `video`, `attachement`, `member_id`, `post_id`, `approved`, `created`, `updated`) VALUES
(22, 'Test', '', '', '', 1, 17, 1, '2015-03-07 17:26:40', '2015-03-07 17:26:40'),
(23, 'Test 2', 'MailChimp_error_99b94.png', '', '', 1, 17, 1, '2015-03-07 17:28:18', '2015-03-07 17:28:18'),
(24, 'https://www.youtube.com/watch?v=IEVE3KSKQ0o\r\n\r\n', '', '', '', 1, 17, 1, '2015-03-07 18:18:21', '2015-03-07 18:18:21'),
(25, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '', '', '', 1, 5, 1, '2015-03-07 18:38:52', '2015-03-07 18:38:52'),
(26, 'ccc', '', '', '', 1, 17, 1, '2015-03-07 19:21:55', '2015-03-07 19:21:55'),
(27, 'test', '', '', 'Testdoc1_fcfca.doc', 1, 17, 1, '2015-03-07 19:23:23', '2015-03-07 19:23:23'),
(28, 'gg', '', '', '', 3, 1, 1, '2016-09-27 15:09:13', '2016-09-27 15:09:13'),
(29, 'gggg', '', '', '', 3, 4, 1, '2016-09-27 23:27:49', '2016-09-27 23:27:49'),
(30, 'sssss', '', '', '', 3, 4, 1, '2016-09-27 23:28:45', '2016-09-27 23:28:45'),
(31, 'dddd', '', '', 'test_28360.ppt', 3, 4, 1, '2016-09-27 23:32:03', '2016-09-27 23:32:03'),
(32, 'test', '', '', '', 1, 2, 1, '2016-10-15 06:33:48', '2016-10-15 06:33:48');

-- --------------------------------------------------------

--
-- Table structure for table `gals`
--

CREATE TABLE IF NOT EXISTS `gals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `caption` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `node_id` int(11) NOT NULL DEFAULT '0',
  `content_id` int(11) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL DEFAULT '0',
  `article_id` int(11) NOT NULL DEFAULT '0',
  `url` text,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `library_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=242 ;

--
-- Dumping data for table `gals`
--

INSERT INTO `gals` (`id`, `caption`, `image`, `node_id`, `content_id`, `position`, `article_id`, `url`, `event_id`, `library_id`) VALUES
(21, '', '93_f2e6e.jpg', 4, 0, 6, 0, NULL, 0, 0),
(25, '', 'Sanofi_Aventis_Cropped_56bd8.jpg', 4, 0, 4, 0, NULL, 0, 0),
(26, '', 'ASTRAZENECA_5ca08.png', 4, 0, 12, 0, NULL, 0, 0),
(29, '', 'Alcatel_Lucent_2_42bba.jpg', 4, 0, 20, 0, NULL, 0, 0),
(31, '', 'Audi_logo_46bbe.png', 4, 0, 16, 0, NULL, 0, 0),
(33, '', 'd0261314_d9af_4152_bd56_3bef78bbfff9_a5d8f.png', 4, 0, 20, 0, NULL, 0, 0),
(38, '', 'QNB_d8efb.jpg', 4, 0, 10, 0, NULL, 0, 0),
(42, '', 'Nile_University_Crop_1_b5046.png', 4, 0, 13, 0, NULL, 0, 0),
(43, '', 'Rich_Bake_Crop1_cbdf0.png', 4, 0, 19, 0, NULL, 0, 0),
(44, '', 'Olympic_Crop_1_35cc7.jpg', 4, 0, 14, 0, NULL, 0, 0),
(45, '', 'Vodafone_Crop_1_d68d1.png', 4, 0, 11, 0, NULL, 0, 0),
(46, '', 'etisalat_crop_1_544c4.png', 4, 0, 3, 0, NULL, 0, 0),
(47, '', 'Mcdonald_s_Crop_1_bfac0.png', 4, 0, 7, 0, NULL, 0, 0),
(52, '', 'Electrolux_2_62f44.jpg', 4, 0, 8, 0, NULL, 0, 0),
(53, '', '', 0, 0, 17, 0, NULL, 0, 0),
(54, '', 'TE_Data_Final_6fa7b.jpg', 4, 0, 20, 0, NULL, 0, 0),
(55, '', 'Al_futtaim_Crop_1_87431.png', 4, 0, 18, 0, NULL, 0, 0),
(56, '', 'Pepsi_crop_3_0c2b3.png', 4, 0, 9, 0, NULL, 0, 0),
(58, '', 'GSK_Crop_1_bc9f9.png', 4, 0, 17, 0, NULL, 0, 0),
(59, '', 'images_225a9.jpg', 4, 0, 2, 0, NULL, 0, 0),
(61, '', 'P_G_Crop_1_72073.png', 4, 0, 5, 0, NULL, 0, 0),
(62, '', '', 0, 0, 6, 0, NULL, 0, 0),
(63, '', 'EMC_Crop_1_f01e3.png', 4, 0, 1, 0, NULL, 0, 0),
(65, '', 'AUC_Crop_2_83b44.jpg', 4, 0, 15, 0, NULL, 0, 0),
(66, '', '', 0, 0, 15, 0, NULL, 0, 0),
(74, '', 'Partners_Crop_6_b84cf.png', 5, 0, 0, 0, NULL, 0, 0),
(75, '', '6_ae011.jpg', 0, 0, 0, 3, NULL, 0, 0),
(79, '', 'Intercultural_Crop_3_a3e6d.jpg', 0, 0, 0, 4, NULL, 0, 0),
(80, '', 'Leading_Modified_285db.jpg', 25, 0, 0, 0, NULL, 0, 0),
(81, '', 'Leading_Modified_9264f.jpg', 26, 0, 0, 0, NULL, 0, 0),
(82, '', '', 0, 0, 0, 0, '', 8, 0),
(84, '', '4image005_0dd28.jpg', 0, 4, 0, 0, NULL, 0, 0),
(85, '', 'thumb_253__533x800__34179_cde1e.jpg', 0, 3, 0, 0, NULL, 0, 0),
(86, '', '', 0, 0, 0, 0, '', 8, 0),
(87, '', '', 0, 0, 0, 0, '', 8, 0),
(89, '', '', 0, 0, 0, 0, '', 0, 14),
(92, '', '', 0, 0, 0, 0, '', 0, 24),
(93, '', '', 0, 0, 0, 0, 'https://drive.google.com/file/d/0B41iGlOelMmUY19Hd1h2RjFXOXM/view?usp=sharing', 0, 14),
(94, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUblctUmprWTBUdXM', 0, 14),
(95, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUZElRQTdFZzlhalE', 0, 14),
(96, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUN3JKWDlhXzZoNXM', 0, 14),
(97, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUb2dKN3hucFNWWUE', 0, 14),
(98, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUcjJQREF1T0oySjA', 0, 14),
(99, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmURzl0bkJBcVFEdVU', 0, 14),
(100, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmURU1DempFQWEwQjQ', 0, 14),
(101, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUNEtodTlUTkpiU00', 0, 14),
(102, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUTFJaZ1c3cWg2eFE', 0, 14),
(103, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUQ1FkWXk1UW5YbFE', 0, 14),
(104, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUajdmM0o4cnRUMmc', 0, 14),
(105, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUYWUwRm42UDNoNlk', 0, 14),
(106, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUSm9DaVFzV0pmbEE', 0, 14),
(107, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUb3NYaUpUb0hqTlk', 0, 14),
(108, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUanhMMWtBRnJ1OWs', 0, 14),
(109, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUcEdwaU1YWjlINTg', 0, 14),
(110, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUX2pVU3dHTTF0blE', 0, 14),
(111, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUZTV5R0hGSkdDRlE', 0, 14),
(112, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUb0ZoZGlVNllBd1k', 0, 14),
(113, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUTXptaW1KM1BJTkU', 0, 14),
(114, '', '', 0, 0, 0, 0, 'https://drive.google.com/file/d/0B41iGlOelMmUUzFCZW81b2d4aWs/view?usp=sharing', 0, 14),
(115, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUcW9IM3lkcVhFMDA', 0, 14),
(116, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmURlg5RkRER04tMUk', 0, 14),
(117, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUQ25ldnZaYjdTX1k', 0, 14),
(118, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUeG0xMWYzUldPbkk', 0, 14),
(119, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUZF9TbWMzUjlZS1U', 0, 14),
(120, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUZTVrenBNWFFZc2s', 0, 14),
(121, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUQ1VXZS1WUl9UZmc', 0, 14),
(122, '', '', 0, 0, 0, 0, '', 8, 0),
(126, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmURWpDV3l0cnZWamM', 0, 27),
(127, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUWHAxN1IydmN1YTg', 0, 27),
(128, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUd2FCQUtaZ1RlZmc', 0, 27),
(129, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUVkNqbE5rSXlmRjA', 0, 27),
(130, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUdC03dFlUcGpnVUk', 0, 27),
(131, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUR2tFc0Q0YTR6YVk', 0, 27),
(132, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmURU9tZXpwUWJURkE', 0, 27),
(133, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUd1k3WW14bjQzWGs', 0, 27),
(134, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUeUtNZS1RMFFQTmc', 0, 27),
(135, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUb0ZXTVV5S2RTUVk', 0, 27),
(136, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUU1dIYnY5ZVlqY2M', 0, 27),
(137, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUTVdDMlI1VEhZVG8', 0, 27),
(138, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUQXpjdGpDdzhPdzQ', 0, 27),
(139, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUUmdtUkhwZEdLa1U', 0, 27),
(140, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUd29lWmdlNkNqLW8', 0, 27),
(141, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUUEcyQWZMRTdJMUE', 0, 27),
(142, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B41iGlOelMmUTEE4eWUyVDRvMHc', 0, 27),
(143, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bd2loclA2T2VOSXM', 0, 28),
(144, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bdFhDV3RCTDlSQ28', 0, 28),
(145, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7ba2w5eW9xenZuZmM', 0, 28),
(146, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bUVlIeU5NYndlZlU', 0, 28),
(147, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bQndDN0VuZnRvT2c', 0, 28),
(148, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bdUtEcndMUDIwMDA', 0, 28),
(149, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bOEFfVjltdTBidTQ', 0, 28),
(150, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bd25Xc1d6djRNQUk', 0, 28),
(151, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7baC1xdlNrVC1xMHM', 0, 28),
(152, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bLTZhbTM4RXhQM0k', 0, 28),
(153, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bTVhGdmJZeHBVdnc', 0, 28),
(154, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bazB6dmE4UFlvUWs', 0, 28),
(155, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bR0ltNnhyZ3J5QVE', 0, 28),
(156, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7banUwVmZKbmREVW8', 0, 28),
(157, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bQ0dPQ1hwSjlKYUk', 0, 28),
(158, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bZ25pNWV4aTBjX0U', 0, 28),
(159, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7belhmNVlyTEN5QlU', 0, 28),
(160, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bQm5lNGFIS0hHQUE', 0, 28),
(161, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bcjZuSXRqMWlzdWM', 0, 28),
(162, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bNWFZVVB2aHdLQzg', 0, 28),
(163, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bNWFZVVB2aHdLQzg', 0, 28),
(164, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bUFY3Q3Q5MG9nME0', 0, 28),
(165, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bUHFWLWNUZ1RNVnM', 0, 28),
(166, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bbVpucHR1bDVJbjg', 0, 28),
(167, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bRVVqbGE0eDItaFE', 0, 28),
(168, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bWUp6WUw0eUJKSjg', 0, 28),
(169, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bS1RfLVZ4TmNiZWs', 0, 28),
(170, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bclo0b3J4aTdObm8', 0, 28),
(171, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bVVJ4UVl5ckRVZjA', 0, 28),
(172, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7ba3lTM1RIMlktcDg', 0, 28),
(173, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bYzVXZlcyckZYSzQ', 0, 28),
(174, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bOExZZVVDSE5DWTA', 0, 28),
(175, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7beHFDZW9PQnNpSlU', 0, 28),
(176, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bUVBuY080bmptazA', 0, 28),
(177, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bcVlqOXNNeVZ3MTQ', 0, 28),
(178, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bS3pwZWUwUW1udTA', 0, 28),
(179, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bS0lCNzJFc0FpSlk', 0, 28),
(180, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bR2lOd0FsTzNIZUE', 0, 28),
(181, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bLW9JdDI1QnhCd0E', 0, 28),
(182, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bNTNuWjRrNF90YVE', 0, 28),
(183, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bc1RxMEVZMUlNeUE', 0, 28),
(184, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bT1hPSFUzTEh0Q1E', 0, 28),
(185, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bRFoyRGZCT1BQX3c', 0, 28),
(186, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bRHowYnBsWWhwREE', 0, 28),
(187, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bQkxVUjdTTHNxdG8', 0, 28),
(188, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bWTA5YVJaakJmMzg', 0, 28),
(189, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bb293OGtoeVBCbFE', 0, 28),
(190, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7baXVFUWVHSXhaR0k', 0, 28),
(191, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bZXpQeGlwbUgyRkU', 0, 28),
(192, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bQ0R6cDRuSjE3LTg', 0, 28),
(193, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bbnZQbjNESE5aSlE', 0, 28),
(194, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bY2FSUExHLV9BMVE', 0, 28),
(195, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bUUVBRllqbHRoaEE', 0, 28),
(196, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bRXV0YXdQR1ZVa3c', 0, 28),
(197, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bVDB5emhLLXhyWFU', 0, 28),
(198, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bMUlvWUYxYjlwWTQ', 0, 28),
(199, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7beENHU3hXQi1IUzg', 0, 28),
(200, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bVS1EdjE2aE5nVEE', 0, 28),
(201, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bVlE4eXhZOGJLVjQ', 0, 28),
(202, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bWWNTTllPbGtxZ3c', 0, 28),
(203, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bczk3M2paYVpWM2c', 0, 28),
(204, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bYlZ1Q3B2VHlDVjA', 0, 28),
(205, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7ba0R3czZxMTRlRlk', 0, 28),
(206, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bRzFxdGZ3R2l6dGs', 0, 28),
(207, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bTGVCSjNDckFzM1E', 0, 28),
(208, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bVENla3RueE9SUkk', 0, 28),
(209, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bd0RTVEoxbzlIbEk', 0, 28),
(210, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bX2hOV2sxMVdvbjg', 0, 28),
(211, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bQm9MYkQ2ZzFXR3c', 0, 28),
(212, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bQldtbnp4VFNPVnM', 0, 28),
(213, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bWmM5Z3MwSXVEeUE', 0, 28),
(214, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bVjJyT1lEc3NTcDA', 0, 28),
(215, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bS3U3QUxfa0RNdm8', 0, 28),
(216, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bUldiQjNLVGFCNnM', 0, 28),
(217, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bOG9lOEd2ak0yZTQ', 0, 28),
(218, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bbEJmTXI1dmdBN0U', 0, 28),
(219, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7baGZRUFpDd09qSTA', 0, 28),
(220, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bTVo5dEZQWnN5Z2c', 0, 28),
(221, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bNG1KZVIzWVg1OXc', 0, 28),
(222, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bbjlZT2dzcWU4S00', 0, 28),
(223, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bZGxaa3lIYklyOVk', 0, 28),
(224, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bOUZ2VlZJS0x1Q0k', 0, 28),
(225, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bZk1EUVdTSGpHM1k', 0, 28),
(226, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bYzBvM3BEdWZhMFU', 0, 28),
(227, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bN2NPT2pLWHhFRTQ', 0, 28),
(228, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bNEZHNjZQYlV5Nmc', 0, 28),
(229, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bRDM2MVdDSVRHOG8', 0, 28),
(230, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bR3IzcnctYzhiR2s', 0, 28),
(231, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bQm1RNC12NmxhdXM', 0, 28),
(232, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7baE1XeFpzMzM0b3M', 0, 28),
(233, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bcW90MVh2VURNRk0', 0, 28),
(234, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bV19PdDRGTVgyRlU', 0, 28),
(235, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bbXpEb1dPNzhfSEE', 0, 28),
(236, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bWW42LXVNX1R3eWs', 0, 28),
(237, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bdlo2RU93SEpGd2M', 0, 28),
(238, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bQk5BZ0tJN0dOdFk', 0, 28),
(239, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bdTJSbUM5MkpZNzg', 0, 28),
(240, '', '', 0, 0, 0, 0, 'https://drive.google.com/open?id=0B8QKVx9W3y7bNndwNERXcURTeDQ', 0, 28);

-- --------------------------------------------------------

--
-- Table structure for table `geographys`
--

CREATE TABLE IF NOT EXISTS `geographys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `weight` int(11) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `title`, `created`, `updated`, `weight`, `approved`) VALUES
(1, 'Group #1', '2016-09-11 06:32:27', '2016-09-11 06:34:18', 0, 1),
(2, 'Group #2', '2016-09-11 08:09:43', '2016-09-11 08:09:43', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `instructors`
--

CREATE TABLE IF NOT EXISTS `instructors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `position` varchar(255) DEFAULT NULL,
  `biography` text,
  `image` varchar(255) DEFAULT NULL,
  `mail` varchar(255) DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `linkedin` varchar(255) DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `forum_flag` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `instructors`
--

INSERT INTO `instructors` (`id`, `name`, `position`, `biography`, `image`, `mail`, `facebook`, `linkedin`, `created`, `updated`, `approved`, `weight`, `forum_flag`) VALUES
(1, 'Ahmed El Aawar', 'Founder & CEO of LCE', '<p style="margin: 0px; color: rgb(83, 83, 83); font-family: Montserrat; font-size: 18px; text-align: justify;">\r\n	Ahmed is the founder and CEO of Life Coaching Egypt, with more than18 years of progressively responsible leadership positions in multi-national and local companies directing more than 2,000 employeesand up to 15 direct reports of senior department heads. Posts held by Ahmed were:</p>\r\n<ul>\r\n	<li>\r\n		McDonalds Operations Manager</li>\r\n	<li>\r\n		McDonalds Training Director</li>\r\n	<li>\r\n		KFC Egypt General Manager</li>\r\n	<li>\r\n		Vice President Business Development El Sewedy Group</li>\r\n	<li>\r\n		Vice Chairman Siemens</li>\r\n	<li>\r\n		Board member at several companies in the industries of</li>\r\n	<li>\r\n		Petroleum, manufacturing and retail.</li>\r\n</ul>\r\n<p style="margin: 0px; color: rgb(83, 83, 83); font-family: Montserrat; font-size: 18px; text-align: justify;">\r\n	Ahmed&nbsp; now being a professional Coach (First international accredited coach in Egypt) and Psychologist leads workshops all around the world with significant success, handles culture management projects with large and middle size businesses. Ahmed holds an Executive MBA in Management Strategy, Georgetown, USA, Master Degree In Cognitive Psychology Columbia State University, He&rsquo;s PhD. Student in Organizational Psychology, University of London, Certified Professional Co Active Coach (CCPC), the Coaches Training Institute (CTI).</p>\r\n<ul>\r\n	<li>\r\n		Accredited Certified Coach (ACC) from the International Coach Federation (ICF)</li>\r\n	<li>\r\n		Certified Cognitive Behavioral Therapist (CBT), Arthur Freeman Institute, USA</li>\r\n	<li>\r\n		Graduate from The Co Active Accredited Leadership Program, Sitges, Spain.</li>\r\n</ul>\r\n<p style="margin: 0px; color: rgb(83, 83, 83); font-family: Montserrat; font-size: 18px; text-align: justify;">\r\n	Ahmed currently travels all around</p>\r\n<p style="margin: 0px; color: rgb(83, 83, 83); font-family: Montserrat; font-size: 18px; text-align: justify;">\r\n	&nbsp;</p>\r\n<p style="margin: 0px; color: rgb(83, 83, 83); font-family: Montserrat; font-size: 18px; text-align: justify;">\r\n	&nbsp;</p>\r\n<p style="margin: 0px; color: rgb(83, 83, 83); font-family: Montserrat; font-size: 18px; text-align: justify;">\r\n	Ahmed currently travels all around the world as a keynote speaker, managing culture transformation, leading leadership Programs and Value Based programs.</p>\r\n<p style="margin: 0px; color: rgb(83, 83, 83); font-family: Montserrat; font-size: 18px; text-align: justify;">\r\n	Ahmed has consistent appearance in Media and has a consistent Radio Program that is heard from more than 5 million people.</p>\r\n', 'Ahmed_El_Aawar.JPG_3fcb1.jpg', 'aawar@lifecoachingegypt.com', '', '', '2016-06-23 15:04:30', '2016-06-25 03:18:49', 1, 0, 0),
(2, 'Monica Larrabeiti', '', '<div>\r\n	Monica is the academic director of the IDDI Dialogical Coaching Certification Programme in Egypt. &nbsp;She has a been colaborating with the University Francisco De Vitoria for 3 years in the dialogical coaching programme as a trainer, suprevisor, mentor and coach.</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	Monica is accreditted by the ICF (International Coach Federation) as a PCC (Professional Certified Coach) and has more than 2500 hours of coaching in her records. &nbsp;She has worked as an executive coach and trainer for companies as Airbus, Nestle, Astra Zeneca, Etisalat, Vodafone, Al Ahram/Heineken, ING - Nationale Nederlanden, Desigual, Bank Sabadell, Mapfre, Telefonica, Zurich, Lafarge, Ageon, etc...</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	Monica has also been collaborating with LCE (Life Coaching Egypt) for 4 years as a coach and trainer in several transformational leadership and mentoring projects.</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	She has a bachelor degree in Economics and Business Administration by the Universidad de Deusto-Spain (1990) and she develpped a successful career at P&amp;G for 16 years in the fields of Marketing and Business Development, leading several departments with multifunctional and international teams. &nbsp;She has a wide corporate experience.</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	Education related to Coaching and Self-Growth:</div>\r\n<div>\r\n	&nbsp;</div>\r\n<ul>\r\n	<li>\r\n		CoPactive Coaching and Ontological Coaching (CTI and European School of coaching) (2005P2008)</li>\r\n	<li>\r\n		Graduate in International Leadership and Coaching CTI (Coaches Training Institute) (2010)</li>\r\n	<li>\r\n		Organizations and Relationships Systemic Coaching CRR (Center for Right Relationship) (2009)</li>\r\n	<li>\r\n		NLP Practitioner (Neuro Plinguistic Programming) SCT Systemic (2005)</li>\r\n	<li>\r\n		Robert Dilts &ndash; The heroe&rsquo;s journey (2005)</li>\r\n	<li>\r\n		Advanced Systemic Constellations with Bert Hellinger and Svagito Liebermeister (2004P2009)&nbsp;</li>\r\n	<li>\r\n		Counselling Skills Training (2007)</li>\r\n	<li>\r\n		Systemic Pedagogy (2004)</li>\r\n	<li>\r\n		<div>\r\n			Enneagram. Enneagram Institute NY - USA&nbsp;</div>\r\n		<div>\r\n			&nbsp;</div>\r\n	</li>\r\n</ul>\r\n', 'Monica_8c6e0.jpg', 'monica.larrabeiti@lifecoachingegypt.com', '', '', '2016-07-01 15:55:45', '2016-07-01 15:55:45', 1, 0, 1),
(3, 'ddd', '', '', '', '', '', '', '2016-09-18 22:38:10', '2016-09-18 22:38:16', 0, 0, 0),
(4, 'dddd', '', '', '', '', '', '', '2016-09-19 01:27:34', '2016-09-19 01:27:34', 0, 0, 1),
(5, 'Mohamed', 'Web Developer', '<p>\r\n	dddd</p>\r\n', '', '', '', '', '2016-09-19 01:28:54', '2016-10-15 22:17:35', 1, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `libraries`
--

CREATE TABLE IF NOT EXISTS `libraries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `type1` int(11) NOT NULL DEFAULT '0',
  `type2` int(11) NOT NULL DEFAULT '0',
  `file` varchar(255) DEFAULT NULL,
  `google_drive_url` text,
  `youtube_url` text,
  `module` int(11) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `weight` int(11) NOT NULL DEFAULT '0',
  `type3` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=63 ;

--
-- Dumping data for table `libraries`
--

INSERT INTO `libraries` (`id`, `title`, `type1`, `type2`, `file`, `google_drive_url`, `youtube_url`, `module`, `approved`, `created`, `updated`, `weight`, `type3`) VALUES
(3, 'اسأل ونحن نجيب', 1, 0, 'اسئل_ونحن_نجيبب_f0598.docx', '', '', 0, 1, '2016-10-09 20:58:02', '2016-10-09 20:58:02', 0, 0),
(4, 'المذاكرة', 1, 0, '', 'https://docs.google.com/document/d/12pIHETd8vsaOT_ZF2P3K6VdICXumqj195izPVdTNuHA/edit?usp=sharing', '', 0, 1, '2016-10-09 21:00:41', '2016-10-09 21:00:41', 0, 0),
(5, 'تربية الأبناء', 1, 0, 'تربيه_الابناء_f0d5d.docx', '', '', 0, 1, '2016-10-09 21:01:50', '2016-10-09 21:01:50', 0, 0),
(6, 'الذكاء الإجتماعي', 1, 0, 'الذكاء_الاجتماعي_cd6d0.docx', '', '', 0, 1, '2016-10-09 21:02:13', '2016-10-09 21:02:13', 0, 0),
(7, 'الشباب', 1, 0, 'الشباب_912d4.docx', '', '', 0, 1, '2016-10-09 21:02:33', '2016-10-09 21:02:33', 0, 0),
(8, 'خواطر للحياة', 1, 0, 'خواطر_للحياه_c31f6.docx', '', '', 0, 1, '2016-10-09 21:03:00', '2016-10-09 21:03:00', 0, 0),
(9, 'علاقة الرجل والمرأة', 1, 0, 'علاقه_الرجل_والمراه_629b8.docx', '', '', 0, 1, '2016-10-09 21:03:28', '2016-10-09 21:03:28', 0, 0),
(10, 'فهم النفس', 1, 0, 'فهم_النفس_32ac2.docx', '', '', 0, 1, '2016-10-09 21:03:53', '2016-10-09 21:03:53', 0, 0),
(13, 'Video 1', 2, 5, '', '', 'https://www.youtube.com/watch?v=uVYkE8q9Fko', 0, 1, '2016-10-09 21:16:57', '2016-10-09 21:16:57', 0, 0),
(14, 'DCC Group 3 ', 3, 0, '', NULL, NULL, 0, 1, '2016-10-17 22:53:10', '2016-10-18 23:34:40', 0, 0),
(15, 'M1 ANTHROPOLOGICAL FOUNDATIONS OF THE DIALOGICAL COACHING MODEL', 0, 3, 'M1_ANTHROPOLOGICAL_FOUNDATIONS_OF_THE_DIALOGICAL_COACHING_MODEL_3867d.pdf', '', '', 0, 1, '2016-10-17 23:22:33', '2016-10-17 23:26:38', 0, 0),
(16, 'M1 The Little Prince', 0, 3, 'M1_The_Little_Prince_775cf.pdf', '', '', 0, 1, '2016-10-17 23:29:08', '2016-10-17 23:29:08', 0, 0),
(17, 'M1 ANTHROPOLOGICAL FOUNDATIONS OF THE DIALOGICAL COACHING MODEL', 0, 0, 'M1_ANTHROPOLOGICAL_FOUNDATIONS_OF_THE_DIALOGICAL_COACHING_MODEL_94f50.pdf', '', '', 0, 1, '2016-10-17 23:29:52', '2016-10-17 23:29:52', 0, 0),
(18, 'Slides Coaching', 0, 0, 'slides_coaching_d4e34.pdf', '', '', 0, 1, '2016-10-17 23:32:05', '2016-10-17 23:32:05', 0, 1),
(19, 'Programme Tools', 0, 0, 'Programme_Tools_4ac35.pdf', '', '', 0, 1, '2016-10-17 23:32:54', '2016-10-17 23:32:54', 0, 1),
(20, 'Other Resources[1]', 0, 0, 'Other_Resources_1__74d32.pdf', '', '', 0, 1, '2016-10-17 23:33:44', '2016-10-17 23:33:44', 0, 1),
(21, 'Inter-module Assignment[1]', 0, 0, 'Inter_module_Assignment_1__0db2b.pdf', '', '', 0, 1, '2016-10-17 23:33:52', '2016-10-17 23:33:52', 0, 1),
(22, 'M1 Introduction a few basic concepts', 0, 0, 'M1_Introduction_a_few_basic_concepts_b49ce.pdf', '', '', 0, 1, '2016-10-17 23:34:24', '2016-10-17 23:34:24', 0, 1),
(23, 'M1 COMPETENCES OF THE DIALOGICAL COACH', 0, 0, 'M1_COMPETENCES_OF_THE_DIALOGICAL_COACH_89707.pdf', '', '', 0, 1, '2016-10-17 23:35:52', '2016-10-17 23:35:52', 0, 1),
(24, 'Man searching for meaning', 0, 0, '', 'https://drive.google.com/file/d/0B3wfaqWuSlu9eGVDb1RVUDJPRWc/view?usp=sharing', '', 1, 0, '2016-10-23 06:49:27', '2016-10-23 06:49:27', 0, 0),
(25, 'M2 Fields of Dialogical Coaching and the Coach''s competences Part. III', 0, 3, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9WjVTVGlEdmZSems', '', 1, 1, '2016-10-23 06:54:18', '2016-10-23 06:54:18', 0, 1),
(26, 'October Community Meeting ', 4, 0, 'Meeting_Agenda__October_22__2016_d3fba.pdf', '', '', 0, 1, '2016-10-24 23:23:10', '2016-10-31 13:18:31', 0, 0),
(27, 'DCC Group 1 module 1', 3, 0, '', NULL, NULL, 0, 1, '2016-10-25 07:15:53', '2016-10-25 07:24:44', 0, 0),
(28, 'DCC Group 1 module 2', 3, 0, '', NULL, NULL, 0, 1, '2016-10-28 11:29:52', '2016-10-28 11:29:52', 0, 0),
(29, 'THE UNDERLYING ANTHROPOLOGICAL IDENTITY', 0, 3, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9ZExRcEFicHJheE0', '', 2, 1, '2016-10-29 06:30:41', '2016-10-29 06:30:41', 1, 0),
(30, 'PREPARATION OF THE THIRD ANTHROPOLOGICAL DIALOGUE:', 0, 0, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9SFV2eElDaFVvSkk', '', 2, 1, '2016-10-29 06:32:01', '2016-10-29 06:32:01', 2, 0),
(31, 'FIELD OF BEING & PATH', 0, 3, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9NU5LTkZqTDFiS00', '', 2, 1, '2016-10-29 06:34:23', '2016-10-29 06:34:23', 0, 1),
(32, 'M 3 slides', 0, 1, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9N0R3YWhjYTU0QjQ', '', 2, 1, '2016-10-29 06:36:18', '2016-10-29 06:36:18', 1, 1),
(33, 'TOOLS TO BE USED IN COACHING IN THE FIELD OF BEING', 0, 3, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9ckZSclNiOTRhLTQ', '', 2, 1, '2016-10-29 06:37:49', '2016-10-29 06:37:49', 2, 1),
(34, 'Second Assignment Fundamental Cycle', 0, 3, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9UURQa3NMd0h3QkU', '', 2, 1, '2016-10-29 06:40:10', '2016-10-29 06:40:10', 3, 1),
(35, 'Summary of Modules ', 0, 3, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9QjBhSVdJOW5XWTg', '', 2, 1, '2016-10-29 06:41:47', '2016-10-29 06:41:47', 0, 1),
(36, 'FIELD OF THE CLIENT''S RELATIONSHIPS AND  SYSTEMS', 0, 3, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9a2RsYkQ2ZTdMeU0', '', 3, 1, '2016-10-29 06:58:21', '2016-10-29 06:58:21', 0, 1),
(37, 'Preparation of Anthropological Dialogue "The personal subject is a being of encounter”', 0, 3, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9TmVyWlRxYm1Fekk', '', 3, 1, '2016-10-29 06:59:48', '2016-10-29 06:59:48', 1, 0),
(38, 'M4 slides', 0, 1, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9dXVHOWdRcXEzaFU', '', 3, 1, '2016-10-29 07:02:26', '2016-10-29 07:02:26', 0, 1),
(39, 'M4 Dialogical Coaching Tools', 0, 0, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9bWRqX2xEOUZPS3M', '', 3, 1, '2016-10-29 07:03:22', '2016-10-29 07:03:22', 0, 1),
(40, 'M4  Systems Flower', 0, 3, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9bERjbDNPWk5aNEE', '', 3, 1, '2016-10-29 07:04:16', '2016-10-29 07:04:16', 0, 1),
(41, 'M4 The Wheel of Encounter', 0, 3, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9aWZ6YWEwOUV1VDg', '', 3, 1, '2016-10-29 07:04:57', '2016-10-29 07:04:57', 0, 1),
(42, 'Assignment 3: Personal self-discovery, Improving as a coach', 0, 3, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9aHRSb2taLTdvNWs', '', 3, 1, '2016-10-29 07:07:22', '2016-10-29 07:07:22', 0, 1),
(43, 'M 4 - Relation and encounter', 0, 1, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9SWEzWVpPU0FuZFE', '', 3, 1, '2016-10-29 07:11:40', '2016-10-29 07:11:40', 0, 1),
(44, 'M5 Preparation of Antropological Dialogue', 0, 3, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9MEZJNHgxcVJqM2M', '', 4, 1, '2016-10-29 07:13:30', '2016-10-29 07:13:30', 0, 0),
(45, 'Conclusion: The Accomplished Subject', 0, 3, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9OG1taWVzdVh6Vjg', '', 4, 1, '2016-10-29 07:15:55', '2016-10-29 07:15:55', 0, 0),
(46, 'M5 Coaching Material', 0, 3, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9blpkdzBrWjNMTDQ', '', 4, 1, '2016-10-29 07:17:51', '2016-10-29 07:17:51', 0, 1),
(47, 'M 5 slides', 0, 3, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9VVo1bWZzckV2NUk', '', 4, 1, '2016-10-29 07:18:49', '2016-10-29 07:18:49', 0, 1),
(48, 'M5 ICF Code of Ethics', 0, 3, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9bHh1M2YyQURXODg', '', 4, 1, '2016-10-29 07:19:50', '2016-10-29 07:19:50', 0, 1),
(49, 'M5 Fourth Task', 0, 3, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9YnZ1eFhBVWhEOTg', '', 4, 1, '2016-10-29 07:21:09', '2016-10-29 07:21:09', 0, 1),
(50, 'M5 Slides Anthropology', 0, 1, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9bVM3aHhBdzBfM1U', '', 4, 1, '2016-10-29 07:23:54', '2016-10-29 07:23:54', 0, 0),
(51, 'M2 Fields of Dialogical Coaching and the Coach''s competences Part III', 0, 3, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9WjVTVGlEdmZSems', '', 1, 1, '2016-10-29 07:27:23', '2016-10-29 07:27:23', 0, 1),
(52, 'M2 Preparation Anthropological Dialogue', 0, 3, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9SU5MdFZSM1l0cWM', '', 1, 1, '2016-10-29 07:29:02', '2016-10-29 07:29:02', 0, 0),
(53, 'M2 The Dialogical Coaching Method part. II', 0, 3, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9RUVnQ1dUZFpJV3M', '', 1, 1, '2016-10-29 07:29:59', '2016-10-29 07:29:59', 0, 1),
(54, 'First Assignment', 0, 3, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9cTE2NkxFRl9QMHc', '', 1, 1, '2016-10-29 07:31:24', '2016-10-29 07:31:24', 3, 1),
(55, 'M2  slides', 0, 3, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9UlZ4SHpDUzBtNnM', '', 1, 1, '2016-10-29 07:32:27', '2016-10-29 07:32:27', 1, 1),
(56, 'M2  tools', 0, 3, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9SHF0YjlWOWduU2c', '', 1, 1, '2016-10-29 07:33:24', '2016-10-29 07:33:24', 2, 1),
(57, 'Dynamic Challenge & Meaning', 0, 3, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9ZzQxR3pGcjhYazQ', '', 1, 1, '2016-10-29 07:34:25', '2016-10-29 07:34:25', 0, 1),
(58, 'M2 Coaching Slides', 0, 1, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9N2g0R0dvdVUwNjQ', '', 1, 1, '2016-10-29 07:36:32', '2016-10-29 07:36:32', 0, 1),
(59, 'M2 The Initial Session of the Dialogical Coaching Process', 0, 3, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9TV9CenJfcUtqdnM', '', 1, 1, '2016-10-29 07:37:28', '2016-10-29 07:37:28', 0, 1),
(60, 'M2 Inter-Module Assignment', 0, 3, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9cFA3TXFNc0RkRnc', '', 1, 1, '2016-10-29 07:38:31', '2016-10-29 07:38:31', 0, 0),
(61, 'Questions to Discover the Flow', 0, 3, '', 'https://drive.google.com/open?id=0B3wfaqWuSlu9Z0ZWQlZBMDJJWmc', '', 1, 1, '2016-10-29 07:39:34', '2016-10-29 07:39:34', 0, 1),
(62, 'September Community Meeting', 4, 0, 'Meeting_Agenda__September_24__2016_029da.pdf', '', '', 0, 0, '2016-10-31 13:19:28', '2016-10-31 13:19:28', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `logos`
--

CREATE TABLE IF NOT EXISTS `logos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `weight` int(11) DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `logos`
--

INSERT INTO `logos` (`id`, `title`, `image`, `url`, `weight`, `approved`, `created`, `updated`) VALUES
(1, 'test logo', 'bot_logo_7f20e.jpg', 'http://facebook.com/', 5, 1, '2014-04-12 18:09:29', '2014-04-12 18:09:29'),
(2, 'test logo 2', 'bot_logo2_6bb1f.jpg', 'http://facebook.com/', 6, 1, '2014-04-12 19:54:39', '2014-04-12 19:54:39'),
(3, 'test logo 3', 'bot_logo3_28c74.jpg', 'http://facebook.com/', NULL, 1, '2014-04-12 19:56:31', '2014-04-12 19:56:31'),
(4, 'test logo 4', 'bot_logo4_cafb4.jpg', 'http://facebook.com/', NULL, 1, '2014-04-12 19:57:02', '2014-04-12 19:57:02'),
(5, 'test logo 5', 'bot_logo5_91e1f.jpg', 'http://facebook.com/', NULL, 1, '2014-04-12 19:57:23', '2014-04-12 19:57:38');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE IF NOT EXISTS `members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `job_title` varchar(255) DEFAULT NULL,
  `role` int(11) NOT NULL DEFAULT '2',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `block_posts_notification` tinyint(1) NOT NULL DEFAULT '0',
  `block_comments_notification` tinyint(1) NOT NULL DEFAULT '0',
  `block_announcements_notification` tinyint(1) NOT NULL DEFAULT '0',
  `block_events_notification` tinyint(1) NOT NULL DEFAULT '0',
  `confirm_code` varchar(255) DEFAULT NULL,
  `group_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=37 ;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `fullname`, `username`, `password`, `email`, `mobile`, `image`, `job_title`, `role`, `approved`, `block_posts_notification`, `block_comments_notification`, `block_announcements_notification`, `block_events_notification`, `confirm_code`, `group_id`) VALUES
(1, 'Mohamed Elsayed', 'master', '1228a4fb70b51bf896be98a35717af389ce84325', 'me@mohamedelsayed.net', '0108076143', '', 'Web Developer', 0, 1, 0, 0, 0, 0, NULL, 0),
(3, 'Shady Barakat', 'ShadyBarakat', '021367fd06d035825d0b23767a236e70ded2c699', 'shady.a.barakat@gmail.com', '01115000504', 'CTI_TURKEY__800x533__2aa6c.jpg', 'Trainer/Coach', 1, 1, 0, 0, 0, 0, '54f624ee-ca20-4946-bc35-41d44298a274', 2),
(7, 'Dalia Abou Alam', 'DAlam', 'd9877b71f3f7259472492847330c8fa4afec2648', 'dalia.alam@yahoo.com', '', '', '', 2, 1, 0, 0, 0, 0, NULL, 1),
(8, 'Abdallah Ramzy', 'ARamzy', '2d8f74f6c4116147ec43e37e1b2b7f9db03f6740', 'aramzy2020@gmail.com', '01111144557', '', '', 2, 1, 0, 0, 0, 0, NULL, 1),
(9, 'Hend Eissa', 'HEissa', '3d56e47d30f79d3b3a3a3a11d868746810d273df', 'hend_eissa@yahoo.com', '01111144557', '', '', 2, 1, 0, 0, 0, 0, NULL, 1),
(10, 'Mohammad Zein', 'MZein', '48f55d2362813ff866eb4a279f19feb4f971b9a8', 'Tybaleader@gmail.com', '01062220080', '', '', 2, 1, 0, 0, 0, 0, NULL, 1),
(11, 'Nevine Eid', 'NEid', '6ecee652bc82accc69b527ef772b8b5465634a14', 'freshop@link.net', '01222123510', '', '', 2, 1, 0, 0, 0, 0, NULL, 0),
(12, 'Yasmin Sarhan', 'YSarhan', 'ccf9d0dd6cfd83cf6e7d3fceb37d0b256ccc552b', 'sarhanyasmine@gmail.com', '01000159648', '', '', 2, 1, 0, 0, 0, 0, NULL, 0),
(13, 'Rania Abu Rabia', 'RAburabia', '998dee777799bab42b751b3b1e76811549e13b12', 'rania.aburabia@gmail.com', '01001112057', '', '', 2, 1, 0, 0, 0, 0, NULL, 0),
(14, 'Tamer Zanaty', 'TZanaty', 'e581cf573eb1490b10002e906ac8021d4a9736d2', 'Tzanaty@gmail.com', '01111110010', '', '', 2, 1, 0, 0, 0, 0, NULL, 0),
(15, 'Marwa Mamdouh', 'MMamdouh', '7651bb62e516152279678ac13f90ef213b562d4a', 'miromamdouh@gmail.com', '01066696367', '', '', 2, 1, 0, 0, 0, 0, NULL, 0),
(16, 'Angy El Sewedy', 'AElsewedy', '8b4b3ed8d0b6ad0a67915d54aa9f497d040dee7b', 'angy.elsedawey@yahoo.com', '01002117565', '', '', 2, 1, 0, 0, 0, 0, NULL, 0),
(17, 'Ahmed Ghalwash', 'AGhalwash', '4c89be67e7c6664d40af9ff2913f659264a98fd0', 'a.ghalwash@gmail.com', '01005459000', '', '', 2, 1, 0, 0, 0, 0, NULL, 0),
(18, 'Mai Elwy', 'MElwy', 'd06b6ca4a7866dbc3bd830af050cba568f1c3a00', 'maielwy@aucegypt.edu', '01003619996', '', '', 2, 1, 0, 0, 0, 0, NULL, 0),
(19, 'Rania Salah', 'RSalah', 'a23cf70c7650e8a804217a089965688889387105', 'rania.salah@vodafone.com', '01005003339', '', '', 2, 1, 0, 0, 0, 0, NULL, 0),
(20, 'Ashraf Helal', 'AHelal', '884dbe5d1b041a8cff855ebc2dc51893799c9f21', 'Ashraf.helal@vodafone.com', '0100 5050150 ', '', '', 2, 1, 0, 0, 0, 0, NULL, 0),
(21, 'Mahmoud Gebril', 'MGebril', 'a164f278b4d62c1cf2f160cc21af5492945f7421', 'mgebril@email.com', '01222118898', '382622_10150369673936120_814114291_n__2__c98d8.jpg', '', 2, 1, 0, 0, 0, 0, NULL, 0),
(22, 'Bassem Youssef', 'BYoussef', 'a5c63994a18b3ca0a16951f4a1e89fb4b56ac657', 'bassemyoussef82@gmail.com', '01223126354', '', '', 2, 1, 0, 0, 0, 0, NULL, 0),
(23, 'Hanan Ashry', 'HAshry', 'ce39f7260b88659a9e41d8db7e2953464fcf28d1', 'Hanan.Ashry@etisalat.com', '', '', '', 2, 1, 0, 0, 0, 0, NULL, 0),
(24, 'Natalie Zuraikat', 'NZuraikat', 'd6a6153046f893228fbe5b6f36829615cd254f74', 'natalie_zuraikat@hotmail.com', '01275535525', '', '', 2, 1, 0, 0, 0, 0, NULL, 0),
(25, 'Nesreen El Sherbini', 'NElSherbini', 'b472acb12ca9a26e91cc849463501782c956191a', 'nesreen.elsherbini@gmail.com', '01006699656', '', '', 2, 1, 0, 0, 0, 0, NULL, 0),
(26, 'Perihan Ali', 'PAli', '0019cd41f3eecbe642b95e5e45c01563fa1f608f', 'Perihan.ALi@etisalat.com', '01111000160', '', '', 2, 1, 0, 0, 0, 0, NULL, 0),
(27, 'Reem Hamoudah', 'RHamouda', '2d96ec8b6333c3c4c5e3529b306a77004b646500', 'reem.hamouda@hotmail.com', '01005000442', '', '', 2, 1, 0, 0, 0, 0, NULL, 0),
(28, 'Fayza Riad   ', 'FRiad', '5f96ee5914e729704d677ccdf4361cd8fa00261e', 'fayza.riad@vodafone.com', '01001631385', '', '', 2, 1, 0, 0, 0, 0, NULL, 0),
(29, ' Dina Abdel Aziz', 'DAbdelaziz', 'c9399913d5f0a0af6521fadc854ffaa53acd299d', 'Dina.AbdElAziz-Aziz@vodafone.com', '0105663815', '', '', 2, 1, 0, 0, 0, 0, NULL, 0),
(30, 'Lamia Bahaie', 'LBahaie', '22461e911db772693c7e00979e8ab50918a8edbd', 'lamia_ba@aucegypt.edu', '01064444420', '', '', 2, 1, 0, 0, 0, 0, NULL, 0),
(31, 'Marwa Atef', 'MAtef', 'a5bbd7f88abe923d789dc03f92c06192180d4786', 'marwa_atef@yahoo.com', '01064040605', '', '', 2, 1, 0, 0, 0, 0, NULL, 0),
(32, 'Noha Abbas', 'NAbbas', 'af76031ba8c5d3e7442ca4c4813ec7ae04f8d68b', 'Noha.Abbas@etisalat.com', '01118459994', '', '', 2, 1, 0, 0, 0, 0, NULL, 0),
(33, 'Shaimaa El Beshlawy', 'SElbeshlawy', 'e65150b171ee3a26b430c29703a92ddd00badfcf', 'shaimaa.elbeshlawy@etisalat.com', '01114444105', '', '', 2, 1, 0, 0, 0, 0, NULL, 0),
(34, 'Mona Seleim', 'MSelim', '4c81c90d288492990a6534bf14bd9f84d15da417', 'mona.seleim@lifecoachingegypt.com', '', '', '', 2, 1, 0, 0, 0, 0, NULL, 0),
(35, 'Ahmed El Aawar', 'AAwar', '2623940d14e9564bf70d115585f405cafeb48af0', 'aawar@lifecoachingegypt.com', '', '', '', 2, 1, 0, 0, 0, 0, '550df34f-6b28-4712-bc87-e3e74298a274', 0),
(36, 'admin', 'adminadmin', 'bae599758efe824046ce80b02c340dc5e3042e47', 'admin@ccc.com', '00000', '', '', 1, 1, 0, 0, 0, 0, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `nevents`
--

CREATE TABLE IF NOT EXISTS `nevents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `location` varchar(255) NOT NULL,
  `start_date` date NOT NULL,
  `duration` int(11) NOT NULL DEFAULT '1',
  `time_from` time NOT NULL,
  `time_to` time NOT NULL,
  `ticket_price` int(11) NOT NULL DEFAULT '0',
  `instructor_id` int(11) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `number_of_participants` int(11) NOT NULL DEFAULT '0',
  `fully_booked` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `nevents`
--

INSERT INTO `nevents` (`id`, `title`, `description`, `location`, `start_date`, `duration`, `time_from`, `time_to`, `ticket_price`, `instructor_id`, `approved`, `weight`, `created`, `updated`, `image`, `number_of_participants`, `fully_booked`) VALUES
(2, 'DCC: Module 1 (Foundation of Dialogical Coaching)', '<p>\r\n	This is the first module of the Dialogical Coaching Certification (DCC). &nbsp;During this module the following topics will be covered:</p>\r\n<ul>\r\n	<li>\r\n		What Coaching is and is not. &nbsp; Basic principles of the dialogical model</li>\r\n	<li>\r\n		Skills in practice: mindfulness, dialogical listening and effective questions</li>\r\n	<li>\r\n		How to build a coaching relationship with clients: the coach&#39;s unique perspective</li>\r\n	<li>\r\n		Setting goals and developing effective action plans</li>\r\n	<li>\r\n		Anthropological Foundation: worldview of the contemporary individual and the birth of coaching&nbsp;</li>\r\n</ul>\r\n', 'Concorde El Salam', '2016-09-23', 2, '09:00:00', '19:00:00', 11000, 1, 1, 0, '2016-06-23 14:01:10', '2016-09-18 22:39:25', 'IMG_9164.JPG_d2079.jpg', 27, 0),
(3, 'DCC: Module 2 (Revealing the Meaning)', '<p>\r\n	<span style="color: rgb(84, 84, 85); font-family: Montserrat; font-size: 18px; text-align: justify;">This is the second module of the Dialogical Coaching Certification (DCC). &nbsp;During this module the following topics will be covered:</span></p>\r\n<ul>\r\n	<li>\r\n		<span style="font-size:16px;"><span style="color: rgb(84, 84, 85); font-family: Montserrat; text-align: justify;">How to reveal the &quot;Meaning&quot; and life purpose for our clients</span></span></li>\r\n	<li>\r\n		<span style="font-size:16px;"><span style="color: rgb(84, 84, 85); font-family: Montserrat; text-align: justify;">Wonder is a key attitude in Relationships</span></span></li>\r\n	<li>\r\n		<span style="font-size:16px;"><span style="color: rgb(84, 84, 85); font-family: Montserrat; text-align: justify;">Tools for discovering our clients&#39; vision, mission, values &amp; the best version of themselves</span></span></li>\r\n	<li>\r\n		<span style="font-size:16px;"><span style="color: rgb(84, 84, 85); font-family: Montserrat; text-align: justify;">Skills in practice: exploring sensory context, using poetic resources and finding flow</span></span></li>\r\n	<li>\r\n		<span style="font-size:16px;"><span style="color: rgb(84, 84, 85); font-family: Montserrat; text-align: justify;">Antropological Foundation: wonder &amp; the search for meaning at the core of human nature</span></span></li>\r\n</ul>\r\n', 'Concorde El Salam', '2016-10-21', 2, '09:00:00', '19:00:00', 11000, 0, 1, 0, '2016-07-01 16:07:52', '2016-09-19 00:24:35', '', 30, 0),
(4, 'DCC: Module 3 (Revealing the "Being")', '<p>\r\n	<span style="color: rgb(84, 84, 85); font-family: Montserrat; font-size: 18px; text-align: justify;">This is the third module of the Dialogical Coaching Certification (DCC). &nbsp;During this module the following topics will be covered:</span></p>\r\n<ul>\r\n	<li style="float: none;">\r\n		<span style="font-size:16px;">How to work with the present moment: experience, emotions, energy.</span></li>\r\n	<li style="float: none;">\r\n		<span style="font-size:16px;">How to reveal and transform our clients&#39; mindset.</span></li>\r\n	<li style="float: none;">\r\n		<span style="font-size:16px;">How to change limiting beliefs,overcome inner barriers and tap into inner resources</span></li>\r\n	<li style="float: none;">\r\n		<span style="font-size:16px;">Respect and truthfulness in the coaching relationship.</span></li>\r\n	<li style="float: none;">\r\n		<span style="font-size:16px;">Skills in practice: intuition, recognition and deep connection.</span></li>\r\n	<li style="float: none;">\r\n		<span style="font-size:16px;">Anthropological Foundation: faculties and dimensions of the person.</span></li>\r\n</ul>\r\n', 'Concorde El Salam', '2016-11-25', 2, '09:00:00', '19:00:00', 11000, 0, 1, 0, '2016-07-01 16:16:56', '2016-07-01 16:26:20', 'IMG_9164.JPG_6a2a9.jpg', 30, 0),
(5, 'DCC: Module 4 (Revealing Relationships and Systems)', '<div>\r\n	<span style="color: rgb(84, 84, 85); font-family: Montserrat; font-size: 18px; text-align: justify;">This is the fourth module of the Dialogical Coaching Certification (DCC). &nbsp;During this module the following topics will be covered:</span></div>\r\n<ul style="position: relative; color: rgb(58, 58, 58); font-family: Montserrat; font-size: 18px;">\r\n	<li style="float: none;">\r\n		<span style="font-size:16px;">Revealing the client&#39;s systems.</span></li>\r\n	<li style="float: none;">\r\n		<span style="font-size:16px;">Tools for helping clients to influence the system to which they belong.</span></li>\r\n	<li style="float: none;">\r\n		<span style="font-size:16px;">Tools for improving relationships.</span></li>\r\n	<li style="float: none;">\r\n		<span style="font-size:16px;">Skills in practice: articulating and refining.</span></li>\r\n	<li style="float: none;">\r\n		<span style="font-size:16px;">Anthropological Foundation: the relational dimension of the person &amp; the Encounter</span></li>\r\n</ul>\r\n', 'Concorde El Salam', '2016-12-16', 2, '09:00:00', '19:00:00', 11000, 0, 1, 0, '2016-07-01 16:26:00', '2016-07-01 16:26:00', 'IMG_9164.JPG_e174c.jpg', 30, 0),
(6, 'DCC: Module 5 (Turning limits into Opportunities)', '<p>\r\n	<span style="color: rgb(84, 84, 85); font-family: Montserrat; font-size: 18px; text-align: justify;">This is the fifth module of the Dialogical Coaching Certification (DCC). &nbsp;During this module the following topics will be covered:</span></p>\r\n<ul>\r\n	<li style="float: none;">\r\n		<span style="font-size:16px;">Advanced tools for overcoming barriers &amp; helping clients leave their comfort zone</span></li>\r\n	<li style="float: none;">\r\n		<span style="font-size:16px;">Practicing the art of challenging and expressing vulnerability.</span></li>\r\n	<li style="float: none;">\r\n		<span style="font-size:16px;">How far you can go as a coach? A look at your future in coaching.</span></li>\r\n	<li style="float: none;">\r\n		<span style="font-size:16px;">Supervised practices.</span></li>\r\n	<li style="float: none;">\r\n		<span style="font-size:16px;">Trust and vulnerability.</span></li>\r\n	<li style="float: none;">\r\n		<span style="font-size:16px;">Anthropological Foundation: the transcendent dimension of the person.</span></li>\r\n</ul>\r\n', 'Concorde El Salam', '2017-01-20', 2, '09:00:00', '19:00:00', 11000, 0, 1, 0, '2016-07-01 16:28:50', '2016-07-01 16:29:37', 'IMG_9164.JPG_9a733.jpg', 30, 0),
(7, 'Social Intelligence', '<ul>\r\n	<li>\r\n		Learn in an experiential atmosphere the basic fundamentals of human dynamics.</li>\r\n	<li>\r\n		Learn the different ego states that govern human dynamics.</li>\r\n	<li>\r\n		Learn why people seek attention and cannot help otherwise</li>\r\n	<li>\r\n		Learn about the different games people play to gain love and attention.</li>\r\n	<li>\r\n		Learn to become an effective communicator.</li>\r\n	<li>\r\n		Learn to transform challenging relationship to healthy ones.</li>\r\n	<li>\r\n		Learn to be aware when you&#39;re acting from a better or less than place.<br />\r\n		&nbsp;</li>\r\n</ul>\r\n', 'Concord El Salam Hotel', '2016-07-30', 2, '10:00:00', '19:00:00', 2000, 0, 1, 0, '2016-07-03 14:23:03', '2016-07-22 03:18:17', 'Social_956d9.jpg', 5, 0),
(8, 'Executive Coach ', '<ul>\r\n	<li>\r\n		Learn the basics steps and techniques of Executive Coaching.</li>\r\n	<li>\r\n		understand the difference between Life Coaching and Executive Caching.</li>\r\n	<li>\r\n		Tips of Dos and Don&#39;ts to maitain credibility while doing Executive coaching.</li>\r\n	<li>\r\n		Master the skills needed to conduct a triplet meeting with client and sponsor.</li>\r\n	<li>\r\n		Receiving a personaliezed 360 assessment for each participant.</li>\r\n	<li>\r\n		Learn how to present an executive coaching offer / pitch to companies.</li>\r\n	<li>\r\n		Explore the codeof ethics governing Executive coaching.</li>\r\n</ul>\r\n', 'Concord El Salam Hotel', '2016-10-16', 3, '09:00:00', '17:00:00', 9000, 0, 1, 0, '2016-07-03 14:42:16', '2016-07-03 16:08:23', '13179430_1212667675440632_566650885497591201_n_ca717.jpg', 20, 0),
(9, 'Social Intelligence', '<ul>\r\n	<li>\r\n		Learn in an experiential atmosphere the basic fundamentals of human dynamics.</li>\r\n	<li>\r\n		Learn the different ego states that govern human dynamics.</li>\r\n	<li>\r\n		Learn why people seek attention and cannot help otherwise</li>\r\n	<li>\r\n		Learn about the different games people play to gain love and attention.</li>\r\n	<li>\r\n		Learn to become an effective communicator.</li>\r\n	<li>\r\n		Learn to transform challenging relationship to healthy ones.</li>\r\n	<li>\r\n		Learn to be aware when you&#39;re acting from a better or less than place.</li>\r\n</ul>\r\n', 'Concord El Salam Hotel', '2016-10-05', 2, '10:00:00', '19:00:00', 2000, 0, 1, 0, '2016-07-06 17:22:36', '2016-10-23 00:11:19', '13529110_1246113228762743_6254184763977375952_n_bc3d4.jpg', 30, 1);

-- --------------------------------------------------------

--
-- Table structure for table `nevents_instructors`
--

CREATE TABLE IF NOT EXISTS `nevents_instructors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `instructor_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `nevents_instructors`
--

INSERT INTO `nevents_instructors` (`id`, `event_id`, `instructor_id`) VALUES
(3, 3, 1),
(4, 3, 2),
(5, 4, 1),
(6, 4, 2),
(7, 5, 1),
(8, 5, 2),
(9, 6, 1),
(10, 6, 2),
(11, 8, 1),
(12, 7, 1),
(13, 9, 1);

-- --------------------------------------------------------

--
-- Table structure for table `nevents_orders`
--

CREATE TABLE IF NOT EXISTS `nevents_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile_number` varchar(255) NOT NULL,
  `receipt_number` varchar(255) NOT NULL,
  `transaction_number` varchar(255) NOT NULL,
  `event_id` int(11) NOT NULL DEFAULT '0',
  `amount` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `tickets_number` int(11) NOT NULL DEFAULT '1',
  `installment_flag` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `nevents_orders`
--

INSERT INTO `nevents_orders` (`id`, `name`, `email`, `mobile_number`, `receipt_number`, `transaction_number`, `event_id`, `amount`, `created`, `updated`, `tickets_number`, `installment_flag`) VALUES
(1, '', '', '', 'No Value Returned', '0', 2, 11000, '2016-06-23 14:48:47', '2016-06-23 14:48:47', 1, 0),
(2, 'Shady Barakat', 'shady.a.barakat@gmail.com', '01115000504', '617601480101', '913', 2, 11000, '2016-06-23 17:51:13', '2016-06-23 17:51:13', 1, 0),
(3, 'Mohamed Elsayed', 'me3@mohamedelsayed.net', '01008076143', '619218454012', '2000002219', 0, 5, '2016-07-10 10:21:57', '2016-07-10 10:21:57', 1, 1),
(4, 'Mohamed Elsayed', 'me3@mohamedelsayed.net', '01008076143', '619218454374', '2000002220', 0, 5, '2016-07-10 10:32:23', '2016-07-10 10:32:23', 1, 1),
(5, 'Mohamed Elsayed', 'me3@mohamedelsayed.net', '01008076143', '619218454520', '2000002221', 0, 5, '2016-07-10 10:36:59', '2016-07-10 10:36:59', 1, 1),
(6, 'Mohamed Elsayed', 'me3@mohamedelsayed.net', '01008076143', '619218454664', '2000002222', 0, 5, '2016-07-10 10:40:45', '2016-07-10 10:40:45', 1, 1),
(7, 'Mohamed Elsayed', 'me3@mohamedelsayed.net', '01008076143', '619218454759', '2000002223', 0, 5, '2016-07-10 10:43:59', '2016-07-10 10:43:59', 1, 1),
(8, 'Mohamed Elsayed', 'me3@mohamedelsayed.net', '01008076143', '619218455213', '2000002224', 0, 5, '2016-07-10 10:57:16', '2016-07-10 10:57:16', 1, 1),
(9, 'mahmoud', 'mahmoudsakr@aaib.com', '01004338384', '619318495540', '2000002246', 7, 2000, '2016-07-11 10:50:17', '2016-07-11 10:50:17', 1, 0),
(10, 'mahmoud', 'mahmoudsakr@aaib.com', '01004338384', '619319496275', '2000002247', 7, 6000, '2016-07-11 11:07:03', '2016-07-11 11:07:03', 1, 0),
(11, 'master', 'me@mohamedelsayed.net', '01008076143', '628420548131', '2000003179', 8, 9000, '2016-10-10 11:38:49', '2016-10-10 11:38:49', 1, 0),
(12, 'Mohamed Elsayed', 'me@mohamedelsayed.net', '01008076143', '630408405005', '1708', 4, 11000, '2016-10-29 23:49:00', '2016-10-29 23:49:00', 1, 0),
(13, 'Mohamed Elsayed', 'me@mohamedelsayed.net', '01008076143', '630408405136', '1709', 4, 22000, '2016-10-29 23:51:01', '2016-10-29 23:51:01', 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `newsletters`
--

CREATE TABLE IF NOT EXISTS `newsletters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_name` varchar(255) DEFAULT NULL,
  `from_email` varchar(255) DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `body` longtext NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `newsletters`
--

INSERT INTO `newsletters` (`id`, `from_name`, `from_email`, `subject`, `body`, `created`, `updated`, `user_id`) VALUES
(1, 'Mohamed Elsayed', 'lce@mohamedelsayed.net', 'test Newsletter', '<p style="text-align: center;">\r\n	<strong>test Newsletter<img alt="" src="/app/webroot/img/ckeditor/2image001.jpg" /></strong></p>\r\n', '2014-04-22 16:35:45', '2014-04-22 16:35:45', 0);

-- --------------------------------------------------------

--
-- Table structure for table `nodes`
--

CREATE TABLE IF NOT EXISTS `nodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `teaser` text NOT NULL,
  `body` longtext NOT NULL,
  `viewed` int(11) NOT NULL DEFAULT '0',
  `created` date NOT NULL,
  `updated` date NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `cat_id` int(11) NOT NULL DEFAULT '0',
  `meta_keywords` text NOT NULL,
  `meta_description` text NOT NULL,
  `date` date NOT NULL,
  `duration` varchar(255) DEFAULT NULL,
  `participants` int(11) DEFAULT NULL,
  `weight` int(11) DEFAULT '0',
  `top_image` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `nodes`
--

INSERT INTO `nodes` (`id`, `title`, `teaser`, `body`, `viewed`, `created`, `updated`, `approved`, `cat_id`, `meta_keywords`, `meta_description`, `date`, `duration`, `participants`, `weight`, `top_image`) VALUES
(1, 'Who we are?', '', '<p>\r\n	Combining the art of coaching with the science of psychology, LCE workshops tap into the psychological profile of every individual, giving each person the customized tools that they need to achieve personal and professional development.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	LCE goes past the conventional trainings that give one-size-fits-all solutions; we do not aim for a short-lived emotional boost. Our multi-dimensional workshops are designed to venture into the unique intricacies of every individual.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	With a team of diverse instructors bringing different cultures and backgrounds to the table, we use internationally recognized psychometric analysis tools to give participants deep self-knowledge, identifying their strongest assets and areas of improvement and igniting an ongoing process of development.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	All shields melt away throughout a fun-filled workshop governed by curiosity and exploration, giving way to sincere and authentic exchanges that have a transforming effect not only on individuals but also on inter-personal relations between co-workers.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	We deal with the full human beings with all aspects of life with a belief that the way people do anything is the way they do everything.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Given the space and tools to dig deep into themselves, people are able to identify the roots of many of their struggles and are put on the beginning of the road for a deep transformation.</p>\r\n', 0, '2014-04-05', '2016-11-14', 1, 1, '', '', '0000-00-00', '', 0, 1, 0),
(2, 'Board Members', '', '', 0, '2014-04-12', '2016-06-22', 0, 1, '', '', '0000-00-00', '', 0, 4, 0),
(3, 'Our Team', '', '', 0, '2014-04-12', '2014-05-11', 1, 1, '', '', '0000-00-00', '', 0, 5, 0),
(4, 'Clients', '', '', 0, '2014-04-20', '2014-05-28', 1, 3, '', '', '0000-00-00', '', 0, 1, 0),
(5, 'Partners', '', '<p>\r\n	We have established the partnership with reputable and strong coaching institutions that cover different specializations. &nbsp;Our partners help us get the latest information, updates and best practices in the whole coaching spectrum. &nbsp;Our partners cover individual, teams and systems coaching &nbsp;</p>\r\n', 0, '2014-04-20', '2016-06-25', 1, 3, '', '', '0000-00-00', '', 0, 2, 0),
(6, 'Testimonials', '', '', 0, '2014-04-20', '2016-06-23', 0, 3, '', '', '0000-00-00', '', 0, 3, 0),
(8, 'Leading By Coaching', '', '<p>\r\n	This workshop introduces a new dimension to today&rsquo;s leaders to help them empower their people and boost their development. There are many definitions to Coaching, but one that relates directly to managers is:&rdquo; Coaching is a learning and development process based on deep connection to help individuals achieve a specific competence, result or goal&rdquo;.</p>\r\n<p>\r\n	Becoming a successful Coach requires knowledge and understanding of the process as well as the variety of styles, skills and techniques that are appropriate to the context in which the coaching takes place. &nbsp;Coaching is growing in popularity because of the value it adds to staff relationships, team work, as well as individual and Organizational productivity.</p>\r\n<p>\r\n	The workshop covers three main areas: knowledge, skills and behaviors needed for coaching</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong><u>Knowledge</u></strong><strong>: As a coach you need to know</strong></p>\r\n<ul>\r\n	<li>\r\n		What coaching means and what distinguishes coaching from other learning and helping roles</li>\r\n	<li>\r\n		What the coaching process involves and what coaching models underpin your role as a coach</li>\r\n	<li>\r\n		Where coaching fits within wider developmental processes (particular within organizations)</li>\r\n	<li>\r\n		What personal and professional capabilities the coachee needs to develop</li>\r\n	<li>\r\n		How to manage the coaching relationship and to set clear boundaries</li>\r\n	<li>\r\n		How people respond to, manage and resist change</li>\r\n	<li>\r\n		How people learn and adapt coaching to suit different learning styles</li>\r\n	<li>\r\n		The limits and boundaries of your own practice</li>\r\n</ul>\r\n<p>\r\n	<strong><u>Skills</u></strong><strong>: As a coach you need to be able to</strong></p>\r\n<ul>\r\n	<li>\r\n		Actively listen and communicate at different levels</li>\r\n	<li>\r\n		Employ your intuition</li>\r\n	<li>\r\n		Creatively ask questions</li>\r\n	<li>\r\n		Influence with integrity</li>\r\n	<li>\r\n		Give feedback artfully</li>\r\n	<li>\r\n		Be empathic in face of setbacks</li>\r\n	<li>\r\n		Demonstrate confidence in self and coachee</li>\r\n	<li>\r\n		Be compassionate</li>\r\n	<li>\r\n		Work openly and collaboratively</li>\r\n	<li>\r\n		Challenge coachee</li>\r\n	<li>\r\n		Help coachee engage in problem‐solving</li>\r\n	<li>\r\n		Facilitate goal‐setting &amp; generation of own strategies</li>\r\n	<li>\r\n		Focus on action</li>\r\n	<li>\r\n		Inspire persistence</li>\r\n	<li>\r\n		Act in the best interests of the coachee</li>\r\n	<li>\r\n		Network and access resources</li>\r\n	<li>\r\n		Manage self</li>\r\n	<li>\r\n		Demonstrate passion</li>\r\n	<li>\r\n		Act ethically and with the highest integrity</li>\r\n</ul>\r\n<p>\r\n	<strong><u>Behaviors</u></strong><strong>: As a coach you should</strong></p>\r\n<ul>\r\n	<li>\r\n		Demonstrate empathy &amp; build rapport</li>\r\n	<li>\r\n		Promote and facilitate excellence</li>\r\n	<li>\r\n		Inspire curiosity to open up new horizons</li>\r\n	<li>\r\n		Encourage self‐discovery</li>\r\n	<li>\r\n		Act as a role model</li>\r\n	<li>\r\n		Be non‐judgmental</li>\r\n	<li>\r\n		Possess sense of humor &amp; use appropriately</li>\r\n	<li>\r\n		Value diversity and difference</li>\r\n	<li>\r\n		Show tact and diplomacy</li>\r\n	<li>\r\n		Maintain trust and confidentiality</li>\r\n	<li>\r\n		Signpost client to other sources of support</li>\r\n	<li>\r\n		Seek opportunities to build client&rsquo;s confidence and self esteem</li>\r\n	<li>\r\n		Critically evaluate own practice</li>\r\n	<li>\r\n		Engage in continuous professional development (CPD)</li>\r\n	<li>\r\n		Share learning with clients and peers and wider coaching community&nbsp;</li>\r\n</ul>\r\n', 0, '2014-04-21', '2014-06-16', 1, 4, '', '', '0000-00-00', '3 Days', 25, 2, 0),
(9, 'Deep Communication', '', '<p>\r\n	We believe that this workshop is an artful blend of science and practice forming a unique approach to effective communication. About 20% of the workshop is based on a deep scientific theory and 80% focuses on application through anchors, exercises and games.</p>\r\n<p>\r\n	The theory upon which the workshop is based is the Transactional Analysis theory (TA) by Dr. Berne, showing how humans interact with the sole intention of seeking emotional strokes (called social unit).&nbsp; This can be done through achievements, seeking recognition or attention, and from that they start playing roles via regulated emotions.&nbsp; A 2 way communication or interaction is called a transaction (social interaction). The key point here is that when people seek strokes they do it from 3 ego states:</p>\r\n<ul>\r\n	<li>\r\n		Parent (extereo ego)</li>\r\n	<li>\r\n		Adult (neo ego)</li>\r\n	<li>\r\n		Child (archeo ego)</li>\r\n</ul>\r\n<p>\r\n	These 3 ego states have resulted in the corporate set up in 10 communication modes :</p>\r\n<ul>\r\n	<li>\r\n		Four effective ones (Structuring, supporting, co creating and playful) and they are accessed from the adult ego state.</li>\r\n	<li>\r\n		Six Ineffective ones (Criticizing, inconsistent, interfering, ruthless, opposition and over adapting) and they are accessed from the parent or child ego state.</li>\r\n</ul>\r\n<p>\r\n	Most of the parent/child ego states are not activated from a place of presence or consciousness but rather an auto pilot mode.</p>\r\n', 0, '2014-04-21', '2014-06-16', 1, 4, '', '', '0000-00-00', '3 Days', 25, 3, 0),
(10, 'Power of Decision', '', '<p>\r\n	The power of decision workshop allows the participant in a very unique way to enter the kitchen of his/her decision making process, a journey of discovery in the depth of his/her psyche in a simplified manner backed up with psychological and coaching methodology and science not with the intention of getting a psychological analysis yet to deeply comprehend how he/she can better show up as an authentic leader/manager.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	When making decisions as a leader and manager, several factors work dynamically together to influence and form such decisions with a lot of in and out information perceived, interpreted and processed by your mind.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Of course giving too much information about this process can result in a brain overload and thus paralysis, which this workshop has masterfully overcome by providing the participant a simple approach and tools to become aware of their own decision making process and thus the freedom to&nbsp; change it and fully show up as a leader/manager. As only when you are aware you have the freedom to change.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	The following diagram shows the process in brief:</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<img alt="" src="/app/webroot/img/ckeditor/Power of Decision.jpg" style="width: 500px; height: 217px;" /></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Standing behind every decision are four main factors (the committee of four);</p>\r\n<ul>\r\n	<li>\r\n		<u>Belief System</u> integrated via corporate culture (Our sense of what is right and wrong (unconscious rules and constitution)</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		<u>Value System</u></li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		<u>Default way of thinking and processing</u> information/company&rsquo;s systems and procedures.</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		<u>Emotional State</u> (How leaders feel towards anything/company&rsquo;s survival at the 7 levels of corporate/leadership consciousness)</li>\r\n</ul>\r\n<p>\r\n	And in order for the leaders to shape their decisions without the dogmatic influence of the committee of four, they need to master three main attributes:</p>\r\n<ul>\r\n	<li>\r\n		<u>Space Mindset (free will): </u>&nbsp;The dynamism acquired by focusing in what needs to be done rather than becoming paralyzed by the challenges faced in the day to day issues in the workplace</li>\r\n	<li>\r\n		<u>Self-Awareness (clarity and understanding):</u> The ability to generate high quality information about one&rsquo;s self. What I can influence what I know, and what I don&rsquo;t know influences me. &nbsp;</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		<u>Tolerance</u>: The ability to provide enough energy in order to face the ongoing stress coming from fast paced and competitive work environments&nbsp;</li>\r\n</ul>\r\n', 0, '2014-04-21', '2014-06-16', 1, 4, '', '', '0000-00-00', '3 Days', 25, 4, 0),
(11, 'Change Management', '', '<p>\r\n	Our Change Management program provides change leaders with a comprehensive understanding of the change process. It also provides them with the practical and operationally focused knowledge and skills required to effectively manage change ranging from small department projects to large-scale, rapid cultural transformation initiatives on an organization-wide basis.</p>\r\n<p>\r\n	This Change Management training process:</p>\r\n<ul>\r\n	<li>\r\n		Contextualizes change management within an organization&rsquo;s operational framework and presents implementation practices in the context of daily activities</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Ensures a proactive approach that minimizes problems before they occur</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Utilizes a time-tested structured process for project management that is easy to understand and can be rapidly and practically applied&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Incorporates lessons learned from thousands of companies and change projects ranging from 50 people&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; to tens of thousands of participants across multiple locations</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Provides practical tools and examples throughout a proven 6-Step guided process for ease of application and implementation</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Practical exercises ensure participants rapidly apply concepts upon returning to work&nbsp;&nbsp;&nbsp;&nbsp;</li>\r\n</ul>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	The workshop is divided into three main sections:</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong>Day 1: Change Management Overview</strong></p>\r\n<ul>\r\n	<li>\r\n		Competitive Advantage: Achieving and Sustaining Top Performance&nbsp;&nbsp;&nbsp;</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Understanding Strategy: Purpose, Vision, Mission, Values</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Transactional versus Transformational change</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Motivation &amp; Personal Development: Motivation Concepts &amp; Principles&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Change Management: Concepts, Principles and Foundations for Change&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Change Management: Methodology and Procedure</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		6-Step Change Model and Tools</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Change Team Participants</li>\r\n</ul>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong>Day 2: Managing Change Personally</strong></p>\r\n<ul>\r\n	<li>\r\n		Behavioral Development and the DiSC Model of Behavior&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Recognizing Behavioral Styles</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Fear Factors of Each Behavioral Style</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Barriers and Resistance to Change&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Team Dynamics&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Behavioral Styles and Change Management&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>\r\n</ul>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong>Day 3:&nbsp; Managing Change Organizationally</strong></p>\r\n<ul>\r\n	<li>\r\n		Managing the People Side of Change&nbsp;&nbsp;&nbsp;&nbsp;</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Change Participants</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		A New Leadership Paradigm and Leadership for Change</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Transitional Stages of Change and Performance Impact</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Management Strategies to Encourage Buy in to Change&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Managing Resistance to Change &ndash; Tools to Overcome Resistance&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Change Management Communications</li>\r\n</ul>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	The overall objective of this program is to introduce Change Management principles and methodologies with the aim of creating awareness and understanding along with the practical knowledge and skills needed to effectively manage change personally and organizationally, thereby ensuring change is sustained.&nbsp; This is done through an action based learning design, where theory only consumes about 30% of the time.&nbsp;</p>\r\n', 0, '2014-04-21', '2014-06-16', 1, 4, '', '', '0000-00-00', '3 Days', 40, 5, 0),
(12, 'Systems Intelligence', '', '<p>\r\n	Systems intelligence is a natural evolution of both emotional and social intelligence; it allows the individual to grasp a glimpse of how the parts affect the whole including his role. This workshop is designed to allow one to get a deep insight of others whom he/she collaborates with and others whom he/she may not see or comprehend their role including marginalized voices such as receptionists, secretaries, office boys and security officers. This is an unprecedented workshop that will heighten one&rsquo;s systems&rsquo; intelligence resulting in the impossibility of behaving the same.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	This workshop helps the participants understand the existence of systems intelligence and accordingly raise their maturity level with regards to cross functional collaboration.&nbsp; The workshop also helps the participants nurture their leadership skills and become more proactive in shaping their organization&rsquo;s culture</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	The workshop is designed based on structure and anchoring creation including fun plays displayed by different departments and then sharing key messages stated.It includes role plays emphasizing key shared KPI&rsquo;s via accessing their systems intelligence and incorporating barriers of &ldquo;What&rsquo;s In It For Me (WIIFM)&rdquo;.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	The key point here is engraving key images for each participants to easily recall and access during his/her daily interaction with colleagues that will impact their behavior and increase initiatives and team work spirit regardless of the cultural barriers.</p>\r\n', 0, '2014-04-21', '2014-07-10', 1, 4, '', '', '0000-00-00', '1 Day', 24, 6, 0),
(19, 'Vision & Mission', '', '', 0, '2014-05-11', '2016-06-13', 1, 1, '', '', '0000-00-00', '', NULL, 2, 0),
(20, 'Values', '', '', 0, '2014-05-11', '2016-06-12', 1, 1, '', '', '0000-00-00', '', NULL, 3, 0),
(21, 'Train the Trainer', '', '<p>\r\n	This workshop targets the internal trainers of corporates, and goes beyond the traditional presentation skills training.&nbsp; Training is a process of knowledge sharing through presence and deep impact rather than a superficial presentation of facts and entertaining the audience.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	The focus here is on bringing the trainer on top of the whole process and helping him/her to hold the room, create presence, read the impact (intentional and unintentional), lock-in the knowledge and develop his/her own style.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	There are four main pillars in that workshop divided as follows:</p>\r\n<p>\r\n	<strong>Preparation</strong></p>\r\n<ul>\r\n	<li>\r\n		Intentions</li>\r\n	<li>\r\n		Profiling</li>\r\n	<li>\r\n		Design</li>\r\n	<li>\r\n		Practice</li>\r\n</ul>\r\n<p>\r\n	<strong>Presence</strong></p>\r\n<ul>\r\n	<li>\r\n		Who are you being</li>\r\n	<li>\r\n		Unintended Impact</li>\r\n</ul>\r\n<p>\r\n	<strong>Process</strong></p>\r\n<ul>\r\n	<li>\r\n		Style (Visual, Auditory, Kinesthetic)</li>\r\n	<li>\r\n		Distractions</li>\r\n</ul>\r\n<p>\r\n	<strong>Audience</strong></p>\r\n<ul>\r\n	<li>\r\n		Types of Participants</li>\r\n	<li>\r\n		Learning Types</li>\r\n	<li>\r\n		Managing yourself/audience</li>\r\n	<li>\r\n		Training Tips</li>\r\n</ul>\r\n', 0, '2014-06-17', '2014-06-17', 1, 4, '', '', '0000-00-00', '2 Days', 10, 7, 0),
(22, 'Transformational Leadership', '', '<p>\r\n	The TLP is a program that scientifically, artfully and professionally creates transformational Leaders that will help their organizations evolve &amp; transform, speaking the same language. The TLP is necessary in today&rsquo;s world with the evolvement of the human collective behavior (culture), fierce market dynamics (Huge Customer Base) and complex future anticipation.&nbsp; All of the previous created a need for new Leadership Mindsets that are</p>\r\n<ul>\r\n	<li>\r\n		Authentic</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Dynamic and Flexible</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Tapper on Group Intelligence (Network systems)</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Creative</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Servant (Empowerment)</li>\r\n</ul>\r\n<p>\r\n	Avoiding:</p>\r\n<ul>\r\n	<li>\r\n		Expensive Mercenary Cultures</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Slow Decision Making (Red Tape)</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Hindrance of mobilizing hidden assets</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Octopus Revenue</li>\r\n</ul>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	The program aims at providing the participants with:</p>\r\n<ul>\r\n	<li>\r\n		A full leadership blueprint (heightened awareness)</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Tool box of managing relationships.</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		The ability to become culture change and management catalysts</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		The ability to clearly maneuver and implement company strategy</li>\r\n</ul>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	The program is carried through 4 modules spread over almost one year.&nbsp; The modules are as follows:</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong><u>Module 1: Self Leadership</u> (Egocentric-reflective mindset part I )</strong></p>\r\n<ul>\r\n	<li>\r\n		Participants will be exposed to new information regarding their leadership capacities seldom tapped before and at multiple levels.</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Participants will strike equilibrium in creating a reflection of who truly they are as leaders.</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Participants will acquire a tool kit to continuously acquire this knowledge.</li>\r\n</ul>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<u>Basic Competencies:</u></p>\r\n<p>\r\n	This module is the reference point of other modules and their competencies. The subjects of this module are:</p>\r\n<ul>\r\n	<li>\r\n		Wisdom</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Awareness, Consciousness</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Presence</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Discovering Authentic Self &amp; Life Purpose</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Values &amp; Principle Based Life</li>\r\n</ul>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong><u>Module 2: Self Leadership (Egocentric-Practical Mindset part II)</u></strong></p>\r\n<ul>\r\n	<li>\r\n		Participants will learn to summon the knowledge in the right time</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Apply knowledge thoroughly</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Learn to realize and measure what they apply (new skills)</li>\r\n</ul>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<u>Basic Competencies:</u></p>\r\n<ul>\r\n	<li>\r\n		Self-discipline</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Self-Tolerance</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Self-appreciation</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Accountability</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Prudence</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Systematic &amp; Clear Thinking</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Sound Judgment &amp;Decision Making</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Continuous Improving</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Measuring and Assessment</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Managing Information</li>\r\n</ul>\r\n<p style="margin-left:.5in;">\r\n	&nbsp;</p>\r\n<p>\r\n	<strong><u>Module 3: Interpersonal Leadership (Cooperative Mindset-Sociocentric)</u></strong></p>\r\n<ul>\r\n	<li>\r\n		Either in or out of the organization, Managers have to communicate with multiple roles and master them effectively.</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		While he is managing instead of concentrating on the sides of relations separately, he should concentrate on the <em>relationship itself.&nbsp;</em></li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		In addition, this module gives the insight of team working which is a crucial factor for being successful as a leader.</li>\r\n</ul>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<u>Basic Competencies:</u></p>\r\n<ul>\r\n	<li>\r\n		Conscious and Intentional Relationships</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Effective Communication</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Coaching</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Unleashing The Potential</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Team Building and Development</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Motivating</li>\r\n</ul>\r\n<p style="margin-left:.5in;">\r\n	&nbsp;</p>\r\n<p>\r\n	<strong><u>Module 4: Organizational Leadership (Action Mindset-Worldcentric)</u></strong></p>\r\n<ul>\r\n	<li>\r\n		Managing Change</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		To make a good plan is half of our achievement. This is &lsquo;Must do&rsquo; for us to reach our goal.</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		For taking an appropriate action for change, leaders have to move all sides included in the plan in a perfect harmony and pay all their attention to the change by <em>coordinating and controlling. </em></li>\r\n</ul>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<u>Basic Competencies:</u></p>\r\n<ul>\r\n	<li>\r\n		Execution</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Delivering Results</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Commitment</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Persistence</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Change Management</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Decisiveness</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Discipline</li>\r\n</ul>\r\n', 0, '2014-06-17', '2014-06-17', 1, 5, '', '', '0000-00-00', '3 Days/Module', 20, 1, 0),
(23, 'One On One Coaching', '', '<p>\r\n	There are a number of definitions of Coaching, but one that relates directly to managers is that coaching is: &quot;Coaching is a process that enables learning and development to occur via deep connection&rdquo;. Coaching combines art and science to help individuals reach a state of awareness about their full profile, seeing clearly, the limitations, path for growth and areas to accept.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Leaders go for coaching when they are ready to do something different but are not sure what that &ldquo;something&rdquo; is. Perhaps they are looking for change, a different perspective, or have important goals to reach.&nbsp; Executive or &ldquo;business&rdquo; coaching focuses on helping individuals go from where they are, to where they want themselves and their company to be.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	It is believed that &ldquo;the more an individual is involved in identifying problems, in working out and applying solutions for them and in reviewing results, the more complete and the more long-lasting the learning is. This form of self-improvement tends to bring about learning with a deeper understanding than learning that is taught.&rdquo; &nbsp;Given the right circumstances, one-on-one interaction with an objective third party, who is not tied to the organization or other executive or company influences, can provide a focus that other forms of organizational support cannot. Coaching develops the leader in &ldquo;real time&rdquo; within the context of their current job while allowing them to maintain their day-to-day responsibilities.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Coaching focuses on what the client wants and utilizes a process through the one-on-one coaching sessions to enable the client to self-discover, learn and determine their own &ldquo;answers&rdquo;. It is the client who determines the goals and commits to their goal, while allowing the coach to help hold them accountable.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	In today&rsquo;s hectic, fast paced and competitive business environment, leaders usually need coaches because they struggle to fulfill the responsibilities of their positions and are too busy and too stressed to step back and learn from their experiences or to implement changes to satisfy best management practices. &nbsp;</p>\r\n', 0, '2014-06-17', '2014-06-17', 1, 6, '', '', '0000-00-00', '', NULL, 1, 0),
(24, 'Systems Team Coaching', '', '<p>\r\n	This workshop is an artful blend of coaching with process-oriented psychology to help teams get aligned towards a common goal.&nbsp; It is based on the Deep Democracy process. The Deep Democracy process was originally developed by Arnold Mindell as part of his Process-Oriented psychology work, and then further developed by Faith Fuller and Marita Fridjhon &ndash; the co-founders of the Organizational Systems Coaching model (ORSC).</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	At its heart, a Deep Democracy process is designed to enable a dialogue that would not be possible through meetings that use more traditional methods of discussion and debate.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	The primary objective of a Deep Democracy process is to develop and tap into the collective awareness and intelligence of a team or group by facilitating a new kind of dialogue. The process starts with a specific topic or issue as the focus point.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	The process enables all voices within a group or team to be heard, including those voices that are normally marginalized or considered provocative. New awareness and insights generated are then used as a basis for new agreements and more effective decision-making and action planning.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	A Deep Democracy workshop is an experiential process. It is facilitated in such a way as to enable different voices to be heard and to enter into constructive dialogue.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Participants are asked to stand and physically occupy space that represents a voice or role of the group (for example, the voice of staff, senior management, customers or other stakeholders). Participants are encouraged to speak from points of view other than their own personal perspective.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	While the process is a personal experience for participants, each voice that is heard is viewed as belonging to the whole group or team. All opinions or points of view that are expressed belong to the whole system, and it is this that enables a growth in individual and collective awareness. People speak from different roles and perspectives, listen to the points and issues raised and then respond from the role or perspective that they are occupying.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Participants are encouraged to move between roles and speak with a range of different voices, particularly those that they may not normally speak from. Dialogue between two or more voices is facilitated to create deep learning about the system&rsquo;s dynamics and a range of different views about a specific topic or issue.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	The facilitated dialogue generally lasts between 60 and 90 minutes and is then followed by a debrief and action planning session.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Participants regularly report that they gain deep insights into the issue they are considering and that the expanded awareness of the group or team enables them to design and agree a more effective forward plan.</p>\r\n', 0, '2014-06-17', '2014-06-17', 1, 6, '', '', '0000-00-00', '2 Days', 15, 2, 0),
(26, 'Dialogical Coaching Certification (DCC)', '', '<p>\r\n	<img alt="" src="/app/webroot/img/ckeditor/Leading Modified(1).jpg" style="width: 700px; height: 364px;" /></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<u style="font-size: 22px;">Dialogical Coaching School</u></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<span style="font-size:18px;">For the first time in Egypt, Life Coaching Egypt and the IDDI Dialogical Coaching School at Francisco de Vitoria University have collaborated to offer the Foundation Course of the Dialogical Coaching Certification Programme, an ICF-accredtied training programme for professional coaches. &nbsp;This programme meets the ICF* (International Coach Federation) requirements for coaches interested in applying for the ACC credential (Accredited Certified Coach).</span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<span style="font-size:18px;">The Dialogical Coaching School is part of the IDDI (Institute for Comprehensive Management Development) at Francisco de Vitoria University in Madrid, Spain which belongs to an international university group located in 17 countries. &nbsp;The school&#39;s primary objective is to advance and enrich the coaching profession at the international level, contributing new ideas and innovative solutions and providing a quality education that enhances the public prestige and efficacy of coaching professionals.</span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<span style="font-size:18px;">The Dialogical Coaching model is a product of rigorous multidisciplinary research that interweaves elements of philosophy, psychology and coaching. &nbsp;This research, combined with the IDDI&#39;s 10+ years of experience in the area of management development, allowed us to design a model of the highest quality which in turn inspired the creation of a new professional coach training programme: the Dialogical Coaching Certification programme (DCC). &nbsp;In the ten editions offered to date in Spain, this prestigious programme has already earned an international reputation for quality and excellence.</span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<span style="font-size:12px;">*ICF is the most internationally renowned association to certify coaches globally.</span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<span style="font-size:22px;"><u>Dialogical Coaching Model</u></span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<span style="font-size:18px;">Our model is based on the idea that human beings thrive and flourish by experiencing relationships of deep meaning, also known as relationships of Encounter. &nbsp;The coach&#39;s job is to reveal the client&#39;s meaning, being and path to self-fulfilment. &nbsp;This model focuses on the person as a whole, providing coaches with effective tools and techniques for giving their clients every possible motivation to pursue and achieve their goals. &nbsp;It also incorporates aspects of the relational or systemic approach to one-on-one coaching.</span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<span style="font-size:18px;">Its basic principles are as follows:</span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<span style="font-size:18px;"><strong>The client is a free being who is searching for meaning, who discovers and develops him or herself through relationships of encounter. &nbsp;Coaching is a specific relationship of encounter between coach and client. &nbsp;The coaching process reveals the client&#39;s fulfilment in passing through the ambits of Meaning, Being and Path. &nbsp;The coach&#39;s eye takes in the client in his relationships and systems</strong></span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<span style="font-size:22px;">Key Advantages of the Foundation Course of the Dialogical Coaching Certification Programme (DCC)</span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<span style="font-size:18px;">The proogramme is ACSTH (Approved Coach Specific Training Hours) accredited by the International Coach Federation (ICF). &nbsp;It provides the compleete package for participants to get the ACC (Accredited Certified Coach) credential from ICF via the Portfolio Path:</span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<span style="font-size:18px;">- 116 hours of accredited coach-specific training.</span></p>\r\n<p>\r\n	<span style="font-size:18px;">- 7 hours of group mentor coaching with expert mentor coaches.</span></p>\r\n<p>\r\n	<span style="font-size:18px;">- 3 hours of one-on-one mentor coaching with expert mentor coaches.</span></p>\r\n<ul>\r\n	<li>\r\n		<span style="font-size:18px;">Particpants will get the ACC credential by applying to the ICF written exam once they complete the above plus 100 hours of coaching experience.</span></li>\r\n	<li>\r\n		<span style="font-size:18px;">It teaches coaches to see and work with the person as a whole, helping clients to build efficient, creative relationships with the people around them.</span></li>\r\n	<li>\r\n		<span style="font-size:18px;">It gives coaching a solid foundation in anthropology.</span></li>\r\n	<li>\r\n		<span style="font-size:18px;">It incorporates the relational and systemic approach in one-on-one coaching from a &quot;dialogical perspective&quot;.</span></li>\r\n	<li>\r\n		<span style="font-size:18px;">It provides expert instructors</span></li>\r\n	<li>\r\n		<span style="font-size:18px;">It uses experiential learning methodology with constant opportunities for practical application</span></li>\r\n	<li>\r\n		<span style="font-size:18px;">It provides immediate feedback to one-on-one and group mentor coaching on real sessions.</span></li>\r\n</ul>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<span style="font-size:22px;">Recommended For</span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<ul>\r\n	<li>\r\n		<span style="font-size:18px;">Experienced Professionals who want to become coaches or use coaching skills to improve their performance</span></li>\r\n	<li>\r\n		<span style="font-size:18px;">Corporate executives and middle management</span></li>\r\n	<li>\r\n		<span style="font-size:18px;">Professionals in transition</span></li>\r\n	<li>\r\n		<span style="font-size:18px;">Education professionals</span></li>\r\n	<li>\r\n		<span style="font-size:18px;">Personal development consultants</span></li>\r\n	<li>\r\n		<span style="font-size:18px;">Practicing psychologists and therapists who want to acquire new working tools</span></li>\r\n</ul>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<span style="font-size:22px;">Fundamentals Programme</span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<span style="font-size:18px;">The Fundamentals programme gives participants a thorough grasp of the fundamentals of the dialogfical coaching model and what it can achieve. &nbsp;Participants will practice coaching from day one and discover for themselves the surprising power of Encounter relationships and the keys to personal fulfilment . &nbsp;The Fundamentals program is divided into five units</span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<span style="font-size:22px;"><u>Module 1: Foundation of Dialogical Coaching</u></span></p>\r\n<ul>\r\n	<li>\r\n		What Coaching is and is not.</li>\r\n	<li>\r\n		Basic principles of the dialogical model.</li>\r\n	<li>\r\n		Skills in practice: mindfulness, dialogical listening and effective questions.</li>\r\n	<li>\r\n		How to build a coaching relationship with a clients: the coach&#39;s unique perspective.</li>\r\n	<li>\r\n		Setting goals and developing effective action plans.</li>\r\n	<li>\r\n		Anthropological Foundation: worldview of the contemporary individual and the birth of coaching</li>\r\n</ul>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<span style="font-size:22px;"><u>Module 2: Revealing the &quot;Meaning&quot;</u></span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<ul>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		How to reveal &quot;Meaning&quot; and life purpose for our clients.</li>\r\n	<li>\r\n		Wonder is a key attitude in relationships.</li>\r\n	<li>\r\n		Tools for discovering our clients&#39; vision, mission, values and the best version of themselves.</li>\r\n	<li>\r\n		Skills in practice: exploring the sensory context, using poetic resources and finding the flow.</li>\r\n	<li>\r\n		Anthropological Foundation: wonder and the search for meaning at the core of human nature.</li>\r\n</ul>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<span style="font-size:22px;"><u>Module 3: Revealing the &quot;Being&quot;</u></span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<ul>\r\n	<li>\r\n		<span style="font-size:18px;">How to work with the present moment: experience, emotions, energy.</span></li>\r\n	<li>\r\n		<span style="font-size:18px;">How to reveal and transform our clients&#39; mindset.</span></li>\r\n	<li>\r\n		<span style="font-size:18px;">How to change limiting beliefs.</span></li>\r\n	<li>\r\n		<span style="font-size:18px;">How to reveal and overcome inner barriers.</span></li>\r\n	<li>\r\n		<span style="font-size:18px;">How to help clients tap into their inner resources.</span></li>\r\n	<li>\r\n		<span style="font-size:18px;">Respect and truthfulness in the coaching relationship.</span></li>\r\n	<li>\r\n		<span style="font-size:18px;">Skills in practice: intuition, recognition and deep connection.</span></li>\r\n	<li>\r\n		<span style="font-size:18px;">Anthropological Foundation: faculties and dimensions of the person.</span></li>\r\n</ul>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<span style="font-size:22px;"><u>Module 4: Revealing Relationships and Systems</u></span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<ul>\r\n</ul>\r\n<div>\r\n	<ul>\r\n		<li>\r\n			Revealing the client&#39;s systems.</li>\r\n		<li>\r\n			Tools for helping clients to influence the system to which they belong.</li>\r\n		<li>\r\n			Tools for improving relationships.</li>\r\n		<li>\r\n			Skills in practice: articulating and refining.</li>\r\n		<li>\r\n			Anthropological Foundation: the relational dimension of the person and the Encounter</li>\r\n	</ul>\r\n	<p>\r\n		&nbsp;</p>\r\n	<p>\r\n		<span style="font-size:22px;"><u>Module 5: Turning Limits into opportunities&nbsp;</u></span></p>\r\n	<p>\r\n		&nbsp;</p>\r\n	<div>\r\n		<ul>\r\n			<li>\r\n				Advanced tools for overcoming barriers.</li>\r\n			<li>\r\n				How to help clients come out of their comfort zone.</li>\r\n			<li>\r\n				Practicing the art of challenging and expressing vulnerability.</li>\r\n			<li>\r\n				How far you can go as a coach? A look at your future in coaching.</li>\r\n			<li>\r\n				Supervised practices.</li>\r\n			<li>\r\n				Trust and vulnerability.</li>\r\n			<li>\r\n				Anthropological Foundation: the transcendent dimension of the person.</li>\r\n		</ul>\r\n		<p>\r\n			&nbsp;</p>\r\n	</div>\r\n	<p>\r\n		<img alt="" src="/app/webroot/img/ckeditor/_MG_9042.JPG" style="width: 800px; height: 566px;" /></p>\r\n	<div>\r\n		<ul>\r\n		</ul>\r\n	</div>\r\n	<p>\r\n		&nbsp;</p>\r\n	<ul>\r\n	</ul>\r\n</div>\r\n<p>\r\n	&nbsp;</p>\r\n', 0, '2014-12-08', '2016-07-01', 1, 7, '', '', '0000-00-00', '', NULL, NULL, 1),
(27, 'Authentic Leadership', '', '<p>\r\n	The Authentic Leadership Workshop (ALW) is a completely untraditional out of box leadership workshop that connects participants deeply with their authentic capacities that shape their leadership naturally versus superficially. This allows them to inspire and lead their teams effectively. Every leader is stuck in a persona or a role that he portrays to his team, and most of the structure of that persona is coming from what should be done or the ego which results in a major disconnection and unintentional impact that defeats the purpose of the business.</p>\r\n<p>\r\n	The ALW is based on psychology and coaching methodology to achieve real transformation in one&rsquo;s leadership. Its foundation tackles 3 main leadership traits from several dimensions and they are;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<u>Self-Awareness:</u> The trait of deep sense of understanding revealing:</p>\r\n<ul>\r\n	<li>\r\n		My virtues (high self) versus vices (low self)</li>\r\n	<li>\r\n		My strengths and challenges,</li>\r\n	<li>\r\n		What triggers and motivates oneself</li>\r\n	<li>\r\n		My fears and desires</li>\r\n	<li>\r\n		What I prefer and not in others</li>\r\n	<li>\r\n		Who do I prefer working with and why</li>\r\n</ul>\r\n<p>\r\n	<u>Space Mentality</u>: The trait of proactivity and movement, the ability to:</p>\r\n<ul>\r\n	<li>\r\n		See space to move and deal with challenges</li>\r\n	<li>\r\n		Identify which problems to tackle and which to let go of</li>\r\n	<li>\r\n		Distinct what is really the problem at hand and why am I struggling with it to begin with</li>\r\n	<li>\r\n		See quick and partial solutions that enables you to move versus paralysis of analysis and stagnation</li>\r\n</ul>\r\n<p>\r\n	<u>Self-Acceptance:</u> The trait of dealing and managing your imperfections, to be able to</p>\r\n<ul>\r\n	<li>\r\n		Manage your frustration and sense of in confidence</li>\r\n	<li>\r\n		Differentiate between what you must accept and learn to pick your battles when it comes to development.</li>\r\n	<li>\r\n		Grow your self esteem to gain and boost your energy (morale) to continue striving for better.(self motivation)</li>\r\n	<li>\r\n		Neutralizing your self-negative judgment process that only brings you down versus holding yourself accountableThe Authentic Leadership Workshop (us holding yourself accountable</li>\r\n</ul>\r\n<p>\r\n	The workshop is full of group exercise and games full of excitement and reflection&nbsp;</p>\r\n', 0, '2016-07-01', '2016-07-01', 1, 4, '', '', '0000-00-00', '2', 20, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `points`
--

CREATE TABLE IF NOT EXISTS `points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `body` text,
  `image` varchar(255) DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `weight` int(11) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `points`
--

INSERT INTO `points` (`id`, `title`, `body`, `image`, `created`, `updated`, `weight`, `approved`) VALUES
(1, 'Vision', '<p>\r\n	<span style="font-size:18px;">&quot;Empowering People through self-knowledge to become the best versions of themselves as individuals and communities.&quot;</span></p>\r\n', 'img_ahout_vision_c22cb.png', '2016-06-13 20:09:10', '2016-06-13 20:09:10', 1, 1),
(2, 'Mission', '<p>\r\n	<span style="font-size:18px;">&quot;LCE was created to provide a safe environment for our clients where they can gain awareness about themselves and develop. We are keen to develop strong relationships with our clients, giving them undivided focus and offering interactive workshops that stimulate reflection. We also aim to engage in research in the fields of coaching and psychology to continuously develop new tools to help our clients.&quot; </span></p>\r\n', 'img_ahout_mission_0daa8.png', '2016-06-13 20:09:46', '2016-06-13 20:09:46', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `body` longtext,
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(355) DEFAULT NULL,
  `attachement` varchar(255) DEFAULT NULL,
  `category_id` int(11) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `body`, `image`, `video`, `attachement`, `category_id`, `approved`, `created`, `updated`, `member_id`, `type`) VALUES
(2, 'sss', '', NULL, NULL, '', 1, 1, '2016-09-27 15:33:07', '2016-09-28 00:57:45', 3, 0),
(3, 'ssss', '', NULL, NULL, NULL, 3, 1, '2016-09-27 23:10:52', '2016-09-28 00:56:36', 3, 0),
(4, 'dddd', '', NULL, NULL, NULL, 1, 1, '2016-09-27 23:11:34', '2016-09-27 23:19:54', 3, 0),
(7, 'ssss', '', NULL, NULL, NULL, 1, 1, '2016-09-27 23:57:40', '2016-09-27 23:57:40', 10, 0),
(8, 'This is a test post check it', '', NULL, NULL, NULL, 1, 1, '2016-10-15 03:55:57', '2016-10-15 03:55:57', 3, 0),
(9, 'test 4', '', NULL, NULL, NULL, 1, 1, '2016-10-16 01:55:48', '2016-10-16 01:55:48', 1, 1),
(10, 'test 4', '', NULL, NULL, NULL, 1, 1, '2016-10-16 02:04:27', '2016-10-16 02:04:27', 1, 1),
(11, 'ccc', '', NULL, NULL, NULL, 1, 1, '2016-10-16 02:04:44', '2016-10-16 02:04:44', 1, 1),
(12, 'sss', '', NULL, NULL, NULL, 1, 1, '2016-10-16 02:06:08', '2016-10-16 02:06:08', 1, 1),
(13, 'test 51', '<p>\r\n	xxx</p>\r\n', NULL, NULL, NULL, 6, 1, '2016-10-22 21:51:33', '2016-10-22 21:51:33', 1, 2),
(15, 'test 45', '', NULL, NULL, NULL, 6, 1, '2016-10-22 23:06:16', '2016-10-22 23:06:16', 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `queues`
--

CREATE TABLE IF NOT EXISTS `queues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `newsletter_id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `queues`
--

INSERT INTO `queues` (`id`, `newsletter_id`, `status`) VALUES
(1, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `quotes`
--

CREATE TABLE IF NOT EXISTS `quotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `body` text,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `quotes`
--

INSERT INTO `quotes` (`id`, `name`, `body`, `approved`, `created`, `updated`) VALUES
(1, 'Helen Keller', '<p>\r\n	The only thing worse than beingblind is having sight but no vision.</p>\r\n', 1, '2014-04-06 00:54:42', '2014-04-12 15:01:45'),
(2, 'Mark Nepo', '<p>\r\n	Before fixing what you&#39;re looking at, check what you&#39;re looking through</p>\r\n', 1, '2014-06-28 18:40:13', '2014-06-28 18:40:13'),
(3, 'Lao-Tzu', '<p>\r\n	All streams flow to the sea because it is lower than they are. &nbsp;Humility gives it its power</p>\r\n', 1, '2014-06-28 18:41:44', '2014-06-28 18:41:44'),
(4, 'Oscar Wilde', '<p>\r\n	Experience is simply the name we give to our mistakes</p>\r\n', 1, '2014-06-28 18:43:37', '2014-06-28 18:43:37'),
(5, 'Mark Nepo', '<p>\r\n	If you can&#39;t see what you&#39;re looking for, see what&#39;s there</p>\r\n', 1, '2014-06-28 18:44:26', '2014-06-28 18:44:26');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `footer` varchar(255) NOT NULL,
  `meta_keywords` text NOT NULL,
  `meta_description` text NOT NULL,
  `file_types` varchar(255) NOT NULL,
  `image_types` varchar(255) NOT NULL,
  `max_upload_size` int(11) NOT NULL,
  `resize` int(1) NOT NULL,
  `max_image_width` int(11) NOT NULL,
  `master_image_width` int(11) NOT NULL,
  `master_image_height` int(11) NOT NULL,
  `large_image_width` int(11) NOT NULL,
  `large_image_height` int(11) NOT NULL,
  `medium_image_width` int(11) NOT NULL,
  `medium_image_height` int(11) NOT NULL,
  `thumb_width` int(11) NOT NULL,
  `thumb_height` int(11) NOT NULL,
  `video_width` int(11) NOT NULL,
  `video_height` int(11) NOT NULL,
  `limit` int(11) NOT NULL DEFAULT '0',
  `google_analytics_propertyid` varchar(255) NOT NULL,
  `audio_width` int(11) NOT NULL,
  `audio_height` int(11) NOT NULL,
  `facbook_link` varchar(255) DEFAULT NULL,
  `linkedin_link` varchar(255) DEFAULT NULL,
  `youtube_link` varchar(255) DEFAULT NULL,
  `twitter_link` varchar(255) DEFAULT NULL,
  `contact_us_email` varchar(255) NOT NULL,
  `paging_limit` int(11) NOT NULL DEFAULT '12',
  `minimum_year` int(11) NOT NULL,
  `maximum_year` int(11) NOT NULL,
  `newsletter_limit` int(11) NOT NULL,
  `return_path_email` varchar(255) NOT NULL,
  `comment_paging_limit` int(11) NOT NULL DEFAULT '0',
  `home_string` varchar(255) NOT NULL,
  `blog_string` varchar(255) NOT NULL,
  `faq_string` varchar(255) NOT NULL,
  `faq_fotter_string` varchar(255) NOT NULL,
  `maintenance_mode` tinyint(1) NOT NULL DEFAULT '0',
  `maintenance_mode_text` text,
  `testimonial_cut_string` int(11) NOT NULL DEFAULT '0',
  `article_cut_string` int(11) NOT NULL DEFAULT '0',
  `article_cut_string_inner` int(11) NOT NULL DEFAULT '0',
  `hide_geography` tinyint(1) NOT NULL DEFAULT '0',
  `coaches_email` text NOT NULL,
  `number_of_instalments` int(11) NOT NULL DEFAULT '1',
  `value_for_each_installment` int(11) NOT NULL DEFAULT '1',
  `payment_email` text NOT NULL,
  `color1` varchar(255) DEFAULT NULL,
  `color2` varchar(255) DEFAULT NULL,
  `color3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `url`, `email`, `title`, `footer`, `meta_keywords`, `meta_description`, `file_types`, `image_types`, `max_upload_size`, `resize`, `max_image_width`, `master_image_width`, `master_image_height`, `large_image_width`, `large_image_height`, `medium_image_width`, `medium_image_height`, `thumb_width`, `thumb_height`, `video_width`, `video_height`, `limit`, `google_analytics_propertyid`, `audio_width`, `audio_height`, `facbook_link`, `linkedin_link`, `youtube_link`, `twitter_link`, `contact_us_email`, `paging_limit`, `minimum_year`, `maximum_year`, `newsletter_limit`, `return_path_email`, `comment_paging_limit`, `home_string`, `blog_string`, `faq_string`, `faq_fotter_string`, `maintenance_mode`, `maintenance_mode_text`, `testimonial_cut_string`, `article_cut_string`, `article_cut_string_inner`, `hide_geography`, `coaches_email`, `number_of_instalments`, `value_for_each_installment`, `payment_email`, `color1`, `color2`, `color3`) VALUES
(1, 'http://www.lifecoachingegypt.com', 'me@mohamedelsayed.net2', 'LCE - Life Coaching Egypt', '© All Copyrights Reserved.', '', '', 'zip,rar,pdf,doc,docx,flv,mp3,xls,xlsx,ppt,pptx,jpeg,jpg,gif,png,mp4', 'jpeg,jpg,gif,png', 2000, 3, 1000, 800, 500, 705, 342, 385, 250, 250, 250, 500, 300, 80, 'UA-26708176-1', 400, 27, 'https://www.facebook.com/groups/175047865085/', 'http://www.linkedin.com/', 'https://www.youtube.com/user/lifecoachingegypt', '', 'lce@mohamedelsayed.net', 10, 1900, 2020, 100, 'lce@mohamedelsayed.net', 10, 'Home', 'Blog', 'FAQS', 'FAQS in coaching', 0, '<p style="text-align: center;">\r\n	<strong>The site is under maintenance</strong></p>\r\n<p style="text-align: center;">\r\n	&nbsp;</p>\r\n', 21, 66, 33, 1, 'me@mohamedelsayed.net', 4, 600, 'me@mohamedelsayed.net', NULL, NULL, NULL),
(2, 'http://www.lifecoachingegypt.com', 'me@mohamedelsayed.net2', 'LCE - Life Coaching Egypt', '© All Copyrights Reserved.', '', '', 'zip,rar,pdf,doc,docx,flv,mp3,xls,xlsx,ppt,pptx,jpeg,jpg,gif,png,mp4', 'jpeg,jpg,gif,png', 2000, 3, 1000, 800, 500, 705, 342, 385, 250, 250, 250, 500, 300, 80, 'UA-26708176-1', 400, 27, 'https://www.facebook.com/groups/175047865085/', 'http://www.linkedin.com/', 'https://www.youtube.com/user/lifecoachingegypt', '', 'lce@mohamedelsayed.net', 10, 1900, 2020, 100, 'lce@mohamedelsayed.net', 10, 'Home', 'Blog', 'FAQS', 'FAQS in coaching', 0, '<p style="text-align: center;">\r\n	<strong>The site is under maintenance</strong></p>\r\n<p style="text-align: center;">\r\n	&nbsp;</p>\r\n', 21, 66, 33, 1, 'me@mohamedelsayed.net', 4, 600, 'me@mohamedelsayed.net', '#ff6699', '#3300ff', '#ff0033');

-- --------------------------------------------------------

--
-- Table structure for table `slideshows`
--

CREATE TABLE IF NOT EXISTS `slideshows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `target` tinyint(1) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `forum_flag` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=57 ;

--
-- Dumping data for table `slideshows`
--

INSERT INTO `slideshows` (`id`, `image`, `link`, `target`, `approved`, `weight`, `created`, `updated`, `forum_flag`) VALUES
(49, 'LeadingByCoaching_1_11330.jpg', 'http://lce.mohamedelsayed.net/page/show/2?nodeid=8', 0, 1, 3, '2014-05-18 18:20:52', '2016-07-01 16:38:47', 0),
(50, 'TransformationalLeadership_1_539fe.jpg', 'http://lce.mohamedelsayed.net/page/show/2?nodeid=22', 0, 1, 2, '2014-05-18 18:21:22', '2016-07-01 16:37:11', 0),
(53, 'DCC_modified_b45f8.jpg', 'http://lce.mohamedelsayed.net/page/show/2?nodeid=26', 0, 1, 1, '2015-12-02 08:59:25', '2016-07-01 16:38:04', 0),
(54, '', 'dddd', 0, 1, 1, '2016-10-15 00:46:30', '2016-10-15 00:46:30', 0),
(55, '1D.JPG_ac623.jpg', 'http://bxslider.com/examples/auto-show-start-stop-controls', 0, 1, 1, '2016-10-15 00:46:56', '2016-10-15 01:26:00', 1),
(56, '2image001_cca9f.jpg', 'https://docs.google.com/spreadsheets/d/1I9Fa8cIesNDVOp1Vc6lMolH__E_-tGf5wxwVXf0DbV0/edit#gid=1073428916', 1, 1, 0, '2016-10-15 00:57:42', '2016-10-15 00:57:42', 1);

-- --------------------------------------------------------

--
-- Table structure for table `specializations`
--

CREATE TABLE IF NOT EXISTS `specializations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `specializations`
--

INSERT INTO `specializations` (`id`, `title`, `approved`, `weight`, `created`, `updated`) VALUES
(1, 'Life Coach', 1, 0, '2016-06-18 00:12:48', '2016-06-18 00:12:48'),
(2, 'Career Coach', 1, 0, '2016-06-18 00:13:04', '2016-06-18 00:13:04'),
(3, 'Family Coach', 1, 0, '2016-06-19 17:47:15', '2016-06-19 17:47:15'),
(4, 'Relationship Coach', 1, 0, '2016-06-19 17:51:19', '2016-06-19 17:51:19'),
(5, 'Team Coach', 1, 0, '2016-06-19 17:51:36', '2016-06-19 17:51:36'),
(6, 'Health Coach', 1, 0, '2016-06-19 17:51:52', '2016-06-19 17:51:52'),
(7, 'Business Coach', 1, 0, '2016-06-20 15:47:16', '2016-06-20 15:47:16');

-- --------------------------------------------------------

--
-- Table structure for table `subscribers`
--

CREATE TABLE IF NOT EXISTS `subscribers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `job` varchar(255) DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `sent` tinyint(1) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=242 ;

--
-- Dumping data for table `subscribers`
--

INSERT INTO `subscribers` (`id`, `name`, `email`, `phone`, `job`, `created`, `updated`, `sent`, `user_id`) VALUES
(7, NULL, 'me@mohamedelsayed.net', NULL, NULL, '2014-04-22 16:31:20', '2014-04-22 16:31:20', 1, 0),
(8, NULL, 'sarah.muhammed.saleh@gmail.com', NULL, NULL, '2014-07-05 18:05:41', '2014-07-05 18:05:41', 0, 0),
(9, NULL, 'heba_yasser@eng.asu.edu.eg', NULL, NULL, '2014-07-08 04:09:59', '2014-07-08 04:09:59', 0, 0),
(10, NULL, 'Ahmedradwan2002@yahoo.com', NULL, NULL, '2014-07-09 22:46:40', '2014-07-09 22:46:40', 0, 0),
(11, NULL, 'Abdelazizshahtout@gmail.com', NULL, NULL, '2014-07-09 23:51:41', '2014-07-09 23:51:41', 0, 0),
(12, NULL, 'alielshourbagy@gmail.com', NULL, NULL, '2014-07-09 23:56:40', '2014-07-09 23:56:40', 0, 0),
(13, NULL, 'hanankhater@hotmail.com', NULL, NULL, '2014-07-10 00:14:57', '2014-07-10 00:14:57', 0, 0),
(14, NULL, 'pixel.dream@hotmail.com', NULL, NULL, '2014-07-10 00:18:15', '2014-07-10 00:18:15', 0, 0),
(15, NULL, 'Areiga_faith@hotmail.com', NULL, NULL, '2014-07-10 04:18:14', '2014-07-10 04:18:14', 0, 0),
(16, NULL, 'mayoy@live.com', NULL, NULL, '2014-07-10 05:43:22', '2014-07-10 05:43:22', 0, 0),
(17, NULL, 'aida_nady25@yahoo.com', NULL, NULL, '2014-07-10 08:04:18', '2014-07-10 08:04:18', 0, 0),
(18, NULL, 'okoraiem@gmail.com', NULL, NULL, '2014-07-10 12:39:22', '2014-07-10 12:39:22', 0, 0),
(19, NULL, 'moh_elsherkawy@hotmail.com', NULL, NULL, '2014-07-10 17:10:11', '2014-07-10 17:10:11', 0, 0),
(20, NULL, 'ranapt.2010@gmail.com', NULL, NULL, '2014-07-13 01:16:52', '2014-07-13 01:16:52', 0, 0),
(21, NULL, 'hossam.meta.coach@gmail.com', NULL, NULL, '2014-07-14 13:54:02', '2014-07-14 13:54:02', 0, 0),
(22, NULL, 'mhaggag202013@yahoo.com', NULL, NULL, '2014-07-16 02:19:45', '2014-07-16 02:19:45', 0, 0),
(23, NULL, 'aawar@lifecoachingegypt.com', NULL, NULL, '2014-07-19 03:07:30', '2014-07-19 03:07:30', 0, 0),
(24, NULL, 'immortal_wisdom@hotmail.com', NULL, NULL, '2014-07-21 17:15:29', '2014-07-21 17:15:29', 0, 0),
(25, NULL, 'hossam.moghazy2012@gmail.com', NULL, NULL, '2014-07-22 05:43:32', '2014-07-22 05:43:32', 0, 0),
(26, NULL, 'lasthero.2020@yahoo.com', NULL, NULL, '2014-07-25 17:08:11', '2014-07-25 17:08:11', 0, 0),
(27, NULL, 'Ahmed.career78@gmail.com', NULL, NULL, '2014-07-25 17:34:31', '2014-07-25 17:34:31', 0, 0),
(28, NULL, 'waelmagdimahmoudfarag@gmail.com', NULL, NULL, '2014-07-30 05:34:26', '2014-07-30 05:34:26', 0, 0),
(29, NULL, 'yasseradel389@gmail.com', NULL, NULL, '2014-08-02 11:21:03', '2014-08-02 11:21:03', 0, 0),
(30, NULL, 'r.melsayed@yahoo.com', NULL, NULL, '2014-08-02 18:46:18', '2014-08-02 18:46:18', 0, 0),
(31, NULL, 'y_sarhan@hotmail.com', NULL, NULL, '2014-08-06 09:08:58', '2014-08-06 09:08:58', 0, 0),
(32, NULL, 'r_shakankiri@yahoo.com', NULL, NULL, '2014-08-06 11:35:42', '2014-08-06 11:35:42', 0, 0),
(33, NULL, 'amryousef.moro@gmail.com', NULL, NULL, '2014-08-08 18:58:49', '2014-08-08 18:58:49', 0, 0),
(34, NULL, 'saly.waly@hotmail.com', NULL, NULL, '2014-08-15 23:14:15', '2014-08-15 23:14:15', 0, 0),
(35, NULL, 'miryumyum@hotmail.com', NULL, NULL, '2014-08-19 14:03:49', '2014-08-19 14:03:49', 0, 0),
(36, NULL, 'karimmarc@gmail.com', NULL, NULL, '2014-09-01 19:01:12', '2014-09-01 19:01:12', 0, 0),
(37, NULL, 'sahar_mohamed150@yahoo.com', NULL, NULL, '2014-09-15 08:47:13', '2014-09-15 08:47:13', 0, 0),
(38, NULL, 'mostapha.phahmy@hotmail.com', NULL, NULL, '2014-09-18 03:17:36', '2014-09-18 03:17:36', 0, 0),
(39, NULL, 'heba@amrabdo.com', NULL, NULL, '2014-09-23 07:23:56', '2014-09-23 07:23:56', 0, 0),
(40, NULL, 'sherinehanykaram@hotmail.com', NULL, NULL, '2014-09-24 13:58:46', '2014-09-24 13:58:46', 0, 0),
(41, NULL, 'yomna1717@yahoo.com', NULL, NULL, '2014-09-27 16:46:26', '2014-09-27 16:46:26', 0, 0),
(42, NULL, 'gogo41332@yahoo.com', NULL, NULL, '2014-09-28 13:07:01', '2014-09-28 13:07:01', 0, 0),
(43, NULL, 'dahliazaki@gmail.com', NULL, NULL, '2014-10-01 23:09:49', '2014-10-01 23:09:49', 0, 0),
(44, NULL, 'Ayamohamed@hotmail.co.uk', NULL, NULL, '2014-10-05 11:31:43', '2014-10-05 11:31:43', 0, 0),
(45, NULL, 'raneem.afifi.9@gmail.com', NULL, NULL, '2014-10-12 13:10:23', '2014-10-12 13:10:23', 0, 0),
(46, NULL, 'sarahmehany@hotmail.com', NULL, NULL, '2014-10-13 17:26:43', '2014-10-13 17:26:43', 0, 0),
(47, NULL, 'egyptienpassionate@yahoo.com', NULL, NULL, '2014-10-18 02:09:55', '2014-10-18 02:09:55', 0, 0),
(48, NULL, 'freedomtaste@yahoo.com', NULL, NULL, '2014-10-19 21:50:28', '2014-10-19 21:50:28', 0, 0),
(49, NULL, 'sara.moustafa12@yahoo.com', NULL, NULL, '2014-10-21 07:14:51', '2014-10-21 07:14:51', 0, 0),
(50, NULL, 'omnahelmy@yahoo.com', NULL, NULL, '2014-10-21 09:12:55', '2014-10-21 09:12:55', 0, 0),
(51, NULL, 'h.abuelfotouh@gmail.com', NULL, NULL, '2014-11-02 08:11:58', '2014-11-02 08:11:58', 0, 0),
(52, NULL, 'naivenhelmy@hotmail.com', NULL, NULL, '2014-11-03 13:24:21', '2014-11-03 13:24:21', 0, 0),
(53, NULL, 'karimmarc@ymail.com', NULL, NULL, '2014-11-04 19:52:56', '2014-11-04 19:52:56', 0, 0),
(54, NULL, 'salma.abdelghaffar13@gmail.com', NULL, NULL, '2014-11-10 12:45:02', '2014-11-10 12:45:02', 0, 0),
(55, NULL, 'Farouktaman@gmail.com', NULL, NULL, '2014-11-13 15:47:58', '2014-11-13 15:47:58', 0, 0),
(56, NULL, 'Heba.hussein@g-eagle.net', NULL, NULL, '2014-11-17 16:59:47', '2014-11-17 16:59:47', 0, 0),
(57, NULL, 'haidy_elkorayty86@hotmail.com', NULL, NULL, '2014-11-20 20:29:18', '2014-11-20 20:29:18', 0, 0),
(58, NULL, 'haitham.say6@gmail.com', NULL, NULL, '2014-11-22 20:39:37', '2014-11-22 20:39:37', 0, 0),
(59, NULL, 'marwafahmyramadan@gmail.com', NULL, NULL, '2014-11-24 12:34:20', '2014-11-24 12:34:20', 0, 0),
(60, NULL, 'aya.bedir@gmail.com', NULL, NULL, '2014-12-06 15:07:08', '2014-12-06 15:07:08', 0, 0),
(61, NULL, 'culverani0@gmail.com', NULL, NULL, '2014-12-07 03:50:36', '2014-12-07 03:50:36', 0, 0),
(62, NULL, 'sherif.ibrahim78@gmail.com', NULL, NULL, '2014-12-07 15:10:57', '2014-12-07 15:10:57', 0, 0),
(63, NULL, 'Nashwaelaraby73@gmail.com', NULL, NULL, '2014-12-07 20:16:53', '2014-12-07 20:16:53', 0, 0),
(64, NULL, 'Nourshawky953@gmail.com', NULL, NULL, '2014-12-08 03:09:34', '2014-12-08 03:09:34', 0, 0),
(65, NULL, 'yaraamr@live.com', NULL, NULL, '2014-12-08 15:11:58', '2014-12-08 15:11:58', 0, 0),
(66, NULL, 'hebat_allah_m92@yahoo.com', NULL, NULL, '2014-12-08 19:06:18', '2014-12-08 19:06:18', 0, 0),
(67, NULL, 'noriforiq39@gmail.com', NULL, NULL, '2014-12-08 22:00:19', '2014-12-08 22:00:19', 0, 0),
(68, NULL, 'amr.elselouky@hotmail.com', NULL, NULL, '2014-12-09 09:47:23', '2014-12-09 09:47:23', 0, 0),
(69, NULL, 'Noha.Labib@hbfuller.com', NULL, NULL, '2014-12-10 17:05:25', '2014-12-10 17:05:25', 0, 0),
(70, NULL, 'eldeeb.rana@gmail.com', NULL, NULL, '2014-12-11 17:26:01', '2014-12-11 17:26:01', 0, 0),
(71, NULL, 'sheriff.atef9@gmail.com', NULL, NULL, '2014-12-12 13:55:28', '2014-12-12 13:55:28', 0, 0),
(72, NULL, 'heba.hesin@gmail.com', NULL, NULL, '2014-12-17 11:22:28', '2014-12-17 11:22:28', 0, 0),
(73, NULL, 'hagernage7@yahoo.com', NULL, NULL, '2014-12-18 02:40:16', '2014-12-18 02:40:16', 0, 0),
(74, NULL, 'inji.ayad@gmail.com', NULL, NULL, '2014-12-19 19:10:39', '2014-12-19 19:10:39', 0, 0),
(75, NULL, 'G.aboughazalah@gmail.com', NULL, NULL, '2014-12-20 19:51:32', '2014-12-20 19:51:32', 0, 0),
(76, NULL, 'eman.ali@banqueaudi.com', NULL, NULL, '2014-12-22 11:31:12', '2014-12-22 11:31:12', 0, 0),
(77, NULL, 'alaayassen95@gmail.com', NULL, NULL, '2014-12-27 22:19:10', '2014-12-27 22:19:10', 0, 0),
(78, NULL, 'captain_a_sief@hotmail.com', NULL, NULL, '2014-12-30 20:32:10', '2014-12-30 20:32:10', 0, 0),
(79, NULL, 'miral.wagdy@gmail.com', NULL, NULL, '2014-12-30 23:35:54', '2014-12-30 23:35:54', 0, 0),
(80, NULL, 'amira.galal@bedayia.com', NULL, NULL, '2014-12-31 08:19:45', '2014-12-31 08:19:45', 0, 0),
(81, NULL, 'hasmig57@hotmail.com', NULL, NULL, '2015-01-03 08:43:54', '2015-01-03 08:43:54', 0, 0),
(82, NULL, 'elseyoufy@hotmail.com', NULL, NULL, '2015-01-19 09:03:05', '2015-01-19 09:03:05', 0, 0),
(83, NULL, 'sara.sarraf@gmail.com', NULL, NULL, '2015-01-19 12:19:31', '2015-01-19 12:19:31', 0, 0),
(84, NULL, 'reemkhalil7@gmail.com', NULL, NULL, '2015-01-29 08:52:32', '2015-01-29 08:52:32', 0, 0),
(85, NULL, 'reem.khalil@mundipharma.eg', NULL, NULL, '2015-01-29 08:58:01', '2015-01-29 08:58:01', 0, 0),
(86, NULL, 'dr.shaimaa25@hotmail.com', NULL, NULL, '2015-02-06 23:30:20', '2015-02-06 23:30:20', 0, 0),
(87, NULL, 'mohbak@gmail.com', NULL, NULL, '2015-02-09 12:11:00', '2015-02-09 12:11:00', 0, 0),
(88, NULL, 'ghadashaker@live.com', NULL, NULL, '2015-02-15 14:14:59', '2015-02-15 14:14:59', 0, 0),
(89, NULL, 'tarekkamaleldin77@gmail.com', NULL, NULL, '2015-02-21 10:33:06', '2015-02-21 10:33:06', 0, 0),
(90, NULL, 'hajamaro@yahoo.com', NULL, NULL, '2015-03-04 09:40:04', '2015-03-04 09:40:04', 0, 0),
(91, NULL, 'Rania.a.khalil@gmail.com', NULL, NULL, '2015-03-09 08:17:51', '2015-03-09 08:17:51', 0, 0),
(92, NULL, 'engmohamedbahaa@gmail.com', NULL, NULL, '2015-03-09 10:46:06', '2015-03-09 10:46:06', 0, 0),
(93, NULL, 'phoebeselim@hotmail.com', NULL, NULL, '2015-03-09 12:37:33', '2015-03-09 12:37:33', 0, 0),
(94, NULL, 'mohamednassar27@hotmail.com', NULL, NULL, '2015-03-12 08:46:00', '2015-03-12 08:46:00', 0, 0),
(95, NULL, 'helalmona1@Gmail.com', NULL, NULL, '2015-03-14 14:00:09', '2015-03-14 14:00:09', 0, 0),
(96, NULL, 'islambanna@gmail.com', NULL, NULL, '2015-03-26 12:40:11', '2015-03-26 12:40:11', 0, 0),
(97, NULL, 'ahmedelsabagh@live.com', NULL, NULL, '2015-03-29 19:49:21', '2015-03-29 19:49:21', 0, 0),
(98, NULL, 'ahmedwael74@gmail.com', NULL, NULL, '2015-03-29 22:48:47', '2015-03-29 22:48:47', 0, 0),
(99, NULL, 'gamil_99@hotmail.com', NULL, NULL, '2015-03-31 10:37:56', '2015-03-31 10:37:56', 0, 0),
(100, NULL, 'nadashatat@hotmail.com', NULL, NULL, '2015-03-31 13:58:35', '2015-03-31 13:58:35', 0, 0),
(101, NULL, 'osman.basmah@gmail.com', NULL, NULL, '2015-04-03 00:09:09', '2015-04-03 00:09:09', 0, 0),
(102, NULL, 'rasha.sillman@yahoo.com', NULL, NULL, '2015-04-04 21:23:14', '2015-04-04 21:23:14', 0, 0),
(103, NULL, 'mhalawany@slb.com', NULL, NULL, '2015-04-05 12:58:13', '2015-04-05 12:58:13', 0, 0),
(104, NULL, 'tarekhassan63@gmail.com', NULL, NULL, '2015-04-06 09:39:03', '2015-04-06 09:39:03', 0, 0),
(105, NULL, 'h.mohamed2019@gmail.com', NULL, NULL, '2015-04-08 20:50:33', '2015-04-08 20:50:33', 0, 0),
(106, NULL, 'abdallahalaa15@gmail.com', NULL, NULL, '2015-04-09 23:37:55', '2015-04-09 23:37:55', 0, 0),
(107, NULL, 'hamo7za@gmail.com', NULL, NULL, '2015-04-10 21:53:18', '2015-04-10 21:53:18', 0, 0),
(108, NULL, 'Sara.Khaled@gmail.com', NULL, NULL, '2015-04-14 20:55:13', '2015-04-14 20:55:13', 0, 0),
(109, NULL, 'lamya_munsour@hotmail.com', NULL, NULL, '2015-04-24 14:39:56', '2015-04-24 14:39:56', 0, 0),
(110, NULL, 'sarahzee28@hotmail.com', NULL, NULL, '2015-04-28 20:10:49', '2015-04-28 20:10:49', 0, 0),
(111, NULL, 'Nohamail@yahoo.com', NULL, NULL, '2015-05-01 22:42:15', '2015-05-01 22:42:15', 0, 0),
(112, NULL, 'naira_ragab@yahoo.com', NULL, NULL, '2015-05-03 22:15:10', '2015-05-03 22:15:10', 0, 0),
(113, NULL, 'mohgasaeed@yahoo.com', NULL, NULL, '2015-05-04 11:02:05', '2015-05-04 11:02:05', 0, 0),
(114, NULL, 'tasneem.mahmoud@hotmail.com', NULL, NULL, '2015-05-05 00:15:45', '2015-05-05 00:15:45', 0, 0),
(115, NULL, 'Nivine.elsaid@gmail.com', NULL, NULL, '2015-05-06 14:00:48', '2015-05-06 14:00:48', 0, 0),
(116, NULL, 'Adhamradwan@gmail.com', NULL, NULL, '2015-05-16 09:19:05', '2015-05-16 09:19:05', 0, 0),
(117, NULL, 'mdemam3@gmail.com', NULL, NULL, '2015-05-21 05:15:50', '2015-05-21 05:15:50', 0, 0),
(118, NULL, 'ramy.bahy@live.com', NULL, NULL, '2015-05-24 22:54:49', '2015-05-24 22:54:49', 0, 0),
(119, NULL, 'mnagy@aucegypt.edu', NULL, NULL, '2015-05-25 00:13:56', '2015-05-25 00:13:56', 0, 0),
(120, NULL, 'dreamscometrue80@yahoo.com', NULL, NULL, '2015-05-31 20:13:04', '2015-05-31 20:13:04', 0, 0),
(121, NULL, 'ahmedomar77@gmail.com', NULL, NULL, '2015-06-01 23:23:34', '2015-06-01 23:23:34', 0, 0),
(122, NULL, 'amal.rifaat@hotmail.com', NULL, NULL, '2015-06-08 21:23:14', '2015-06-08 21:23:14', 0, 0),
(123, NULL, 'noor.ramadan12@gmail.com', NULL, NULL, '2015-06-09 10:58:10', '2015-06-09 10:58:10', 0, 0),
(124, NULL, 'aya.shalaby615@hotmail.com', NULL, NULL, '2015-06-12 14:35:16', '2015-06-12 14:35:16', 0, 0),
(125, NULL, 'mora_metwally@yahoo.com', NULL, NULL, '2015-06-15 15:02:18', '2015-06-15 15:02:18', 0, 0),
(126, NULL, 'sabaligh@gmail.com', NULL, NULL, '2015-06-21 07:03:04', '2015-06-21 07:03:04', 0, 0),
(127, NULL, 'oaawar@gmail.com', NULL, NULL, '2015-06-28 18:26:08', '2015-06-28 18:26:08', 0, 0),
(128, NULL, 'aliaa.reda@yahoo.com', NULL, NULL, '2015-06-30 14:41:56', '2015-06-30 14:41:56', 0, 0),
(129, NULL, 'Ola.tarek91@gmail.com', NULL, NULL, '2015-07-01 00:12:25', '2015-07-01 00:12:25', 0, 0),
(130, NULL, 'aya_azab@hotmail.com', NULL, NULL, '2015-07-01 11:08:28', '2015-07-01 11:08:28', 0, 0),
(131, NULL, 'doha.orabi98@gmail.com', NULL, NULL, '2015-07-01 19:15:19', '2015-07-01 19:15:19', 0, 0),
(132, NULL, 'Fadwasadek123@hotmail.com', NULL, NULL, '2015-07-10 16:40:36', '2015-07-10 16:40:36', 0, 0),
(133, NULL, 'j.najoua@gmail.com', NULL, NULL, '2015-07-14 06:25:16', '2015-07-14 06:25:16', 0, 0),
(134, NULL, 'me2@egytek.com', NULL, NULL, '2015-07-22 23:36:37', '2015-07-22 23:36:37', 0, 0),
(135, NULL, 'mahmoud5dash@yahoo.com', NULL, NULL, '2015-07-27 03:25:10', '2015-07-27 03:25:10', 0, 0),
(136, NULL, 'mogahed1971@yahoo.com', NULL, NULL, '2015-07-28 12:21:58', '2015-07-28 12:21:58', 0, 0),
(137, NULL, 'Dentistmahasabry@gmail.com', NULL, NULL, '2015-07-29 02:08:21', '2015-07-29 02:08:21', 0, 0),
(138, NULL, 'Lobnamaghraby.12@hotmail.com', NULL, NULL, '2015-07-31 07:41:46', '2015-07-31 07:41:46', 0, 0),
(139, NULL, 'khaled.abushady8@hotmail.com', NULL, NULL, '2015-08-09 02:30:59', '2015-08-09 02:30:59', 0, 0),
(140, NULL, 'hakim.khodeir@hotmail.com', NULL, NULL, '2015-08-09 16:56:11', '2015-08-09 16:56:11', 0, 0),
(141, NULL, 'nadawans@yahoo.com', NULL, NULL, '2015-08-10 03:23:41', '2015-08-10 03:23:41', 0, 0),
(142, NULL, 'Israa.elleithy@hotmail.com', NULL, NULL, '2015-08-10 14:03:52', '2015-08-10 14:03:52', 0, 0),
(143, NULL, 'maigamal@aucegypr.edu', NULL, NULL, '2015-08-13 20:07:41', '2015-08-13 20:07:41', 0, 0),
(144, NULL, 'Agymb5@gmail.com', NULL, NULL, '2015-08-13 21:29:35', '2015-08-13 21:29:35', 0, 0),
(145, NULL, 'K.elnokaly@gmail.com', NULL, NULL, '2015-08-16 14:16:07', '2015-08-16 14:16:07', 0, 0),
(146, NULL, 'alshimaa.magdy86@gmail.com', NULL, NULL, '2015-08-17 22:07:05', '2015-08-17 22:07:05', 0, 0),
(147, NULL, 'samar1982.tahoun@gmail.com', NULL, NULL, '2015-08-22 06:29:26', '2015-08-22 06:29:26', 0, 0),
(148, NULL, 'ahmedgamal3195@gmail.com', NULL, NULL, '2015-08-25 00:45:28', '2015-08-25 00:45:28', 0, 0),
(149, NULL, 'hishamegy82@hotmail.com', NULL, NULL, '2015-08-26 18:19:42', '2015-08-26 18:19:42', 0, 0),
(150, NULL, 'ola.mahmoud84@gmail.com', NULL, NULL, '2015-08-30 09:15:58', '2015-08-30 09:15:58', 0, 0),
(151, NULL, 'alaa_09@hotmail.com', NULL, NULL, '2015-09-04 11:06:52', '2015-09-04 11:06:52', 0, 0),
(152, NULL, 'inas.hafez@getsircles.com', NULL, NULL, '2015-09-06 20:20:35', '2015-09-06 20:20:35', 0, 0),
(153, NULL, 'Mohab.elhoseany@yahoo.com', NULL, NULL, '2015-09-07 12:35:16', '2015-09-07 12:35:16', 0, 0),
(154, NULL, 'anasomara2014@gmail.com', NULL, NULL, '2015-09-09 13:23:05', '2015-09-09 13:23:05', 0, 0),
(155, NULL, 'howayda_abdelkader@yahoo.co.uk', NULL, NULL, '2015-09-11 17:18:38', '2015-09-11 17:18:38', 0, 0),
(156, NULL, 'Saraamen@gmail.com', NULL, NULL, '2015-09-15 00:05:08', '2015-09-15 00:05:08', 0, 0),
(157, NULL, 'bosaalkahky@yahoo.com', NULL, NULL, '2015-09-21 19:53:44', '2015-09-21 19:53:44', 0, 0),
(158, NULL, 'shady.saad@etisalat.com', NULL, NULL, '2015-09-22 13:52:14', '2015-09-22 13:52:14', 0, 0),
(159, NULL, 'mohamed.dynamo@gmail.com', NULL, NULL, '2015-10-04 23:17:47', '2015-10-04 23:17:47', 0, 0),
(160, NULL, 'Noha_motaz2011@yahoo.com', NULL, NULL, '2015-10-06 21:30:57', '2015-10-06 21:30:57', 0, 0),
(161, NULL, 'raniah.askar@gmail.com', NULL, NULL, '2015-10-11 11:23:48', '2015-10-11 11:23:48', 0, 0),
(162, NULL, 'eng.nabiloun@hotmail.com', NULL, NULL, '2015-10-11 22:12:41', '2015-10-11 22:12:41', 0, 0),
(163, NULL, 'Marzouk1@hotmail.com', NULL, NULL, '2015-10-24 15:19:43', '2015-10-24 15:19:43', 0, 0),
(164, NULL, 'Sirene.rawash@gmail.com', NULL, NULL, '2015-10-26 21:16:09', '2015-10-26 21:16:09', 0, 0),
(165, NULL, 'radwa.rezk91@gmail.com', NULL, NULL, '2015-10-29 15:59:41', '2015-10-29 15:59:41', 0, 0),
(166, NULL, 'nicoletta.foresti@gmail.com', NULL, NULL, '2015-11-02 15:23:24', '2015-11-02 15:23:24', 0, 0),
(167, NULL, 'hegzo_girl@hotmail.com', NULL, NULL, '2015-11-06 14:31:17', '2015-11-06 14:31:17', 0, 0),
(168, NULL, 'black_pearl85@hotmail.com', NULL, NULL, '2015-11-07 18:04:06', '2015-11-07 18:04:06', 0, 0),
(169, NULL, 'Passentnazihaly@gmail.com', NULL, NULL, '2015-11-10 21:04:34', '2015-11-10 21:04:34', 0, 0),
(170, NULL, 'nihal_soliman@hotmail.com', NULL, NULL, '2015-11-11 17:30:31', '2015-11-11 17:30:31', 0, 0),
(171, NULL, 'hager_in@yahoo.com', NULL, NULL, '2015-11-14 18:59:13', '2015-11-14 18:59:13', 0, 0),
(172, NULL, 'nour_elghamry@hotmail.com', NULL, NULL, '2015-11-18 14:30:53', '2015-11-18 14:30:53', 0, 0),
(173, NULL, 'Magda_f@aucegypt.edu', NULL, NULL, '2015-11-25 07:33:32', '2015-11-25 07:33:32', 0, 0),
(174, NULL, 'donzydonz@gmail.com', NULL, NULL, '2015-11-25 10:37:02', '2015-11-25 10:37:02', 0, 0),
(175, NULL, 'sarah.ragab1@gmail.com', NULL, NULL, '2015-11-25 11:12:38', '2015-11-25 11:12:38', 0, 0),
(176, NULL, 'dinamatta@aucegypt.edu', NULL, NULL, '2015-11-29 03:43:50', '2015-11-29 03:43:50', 0, 0),
(177, NULL, 'selshafei@gmail.com', NULL, NULL, '2015-11-29 15:13:30', '2015-11-29 15:13:30', 0, 0),
(178, NULL, 'abuhamid1966@gmail.com', NULL, NULL, '2015-11-29 23:21:09', '2015-11-29 23:21:09', 0, 0),
(179, NULL, 'Rania23amer@yahoo.com', NULL, NULL, '2015-12-02 11:27:12', '2015-12-02 11:27:12', 0, 0),
(180, NULL, 'Thaer.Ashraf@contact.eg', NULL, NULL, '2015-12-02 14:16:24', '2015-12-02 14:16:24', 0, 0),
(181, NULL, 'noha_abozeid_122@hotmail.com', NULL, NULL, '2015-12-03 11:09:54', '2015-12-03 11:09:54', 0, 0),
(182, NULL, 'rehab.ibrahim75@yahoo.com', NULL, NULL, '2015-12-03 17:54:28', '2015-12-03 17:54:28', 0, 0),
(183, NULL, 'basant.nabil@gmail.com', NULL, NULL, '2015-12-04 17:00:35', '2015-12-04 17:00:35', 0, 0),
(184, NULL, 'omar.abd-elazim@hotmail.com', NULL, NULL, '2015-12-06 08:51:14', '2015-12-06 08:51:14', 0, 0),
(185, NULL, 'tnounou86@gmail.com', NULL, NULL, '2015-12-10 01:14:26', '2015-12-10 01:14:26', 0, 0),
(186, NULL, 'rehab.shahien@yahoo.com', NULL, NULL, '2015-12-24 07:50:41', '2015-12-24 07:50:41', 0, 0),
(187, NULL, 'ayman@gasco.com.eg', NULL, NULL, '2015-12-25 14:46:43', '2015-12-25 14:46:43', 0, 0),
(188, NULL, 'huda.m.elhady@gmail.com', NULL, NULL, '2015-12-30 10:42:53', '2015-12-30 10:42:53', 0, 0),
(189, NULL, 'con.mervatsalman@gmail.com', NULL, NULL, '2015-12-30 10:57:19', '2015-12-30 10:57:19', 0, 0),
(190, NULL, 'khedresara@gmail.com', NULL, NULL, '2016-01-01 22:39:13', '2016-01-01 22:39:13', 0, 0),
(191, NULL, 'et_taha@yahoo.com', NULL, NULL, '2016-01-05 20:07:32', '2016-01-05 20:07:32', 0, 0),
(192, NULL, 'robaaa22@hotmail.com', NULL, NULL, '2016-01-08 12:08:37', '2016-01-08 12:08:37', 0, 0),
(193, NULL, 'Drshahendamorsy@gmail.com', NULL, NULL, '2016-01-11 14:50:31', '2016-01-11 14:50:31', 0, 0),
(194, NULL, 'rashaaezzat@gmail.com', NULL, NULL, '2016-01-12 10:44:51', '2016-01-12 10:44:51', 0, 0),
(195, NULL, 'Eman.rifaat@vodafone.com', NULL, NULL, '2016-01-14 19:49:40', '2016-01-14 19:49:40', 0, 0),
(196, NULL, 'aisha-hana@hotmail.com', NULL, NULL, '2016-01-15 20:46:34', '2016-01-15 20:46:34', 0, 0),
(197, NULL, 'osama.ibrahiem1@gmail.com', NULL, NULL, '2016-01-17 22:12:22', '2016-01-17 22:12:22', 0, 0),
(198, NULL, 'Dina.moanes@gmail.com', NULL, NULL, '2016-01-19 11:31:24', '2016-01-19 11:31:24', 0, 0),
(199, NULL, 'fathymarwan@yahoo.com', NULL, NULL, '2016-01-21 23:29:02', '2016-01-21 23:29:02', 0, 0),
(200, NULL, 'Halaelhawary1@gmail.com', NULL, NULL, '2016-01-23 13:31:25', '2016-01-23 13:31:25', 0, 0),
(201, NULL, 'mohamed.alkabbany@gmail.com', NULL, NULL, '2016-01-24 01:18:02', '2016-01-24 01:18:02', 0, 0),
(202, NULL, 'omar_aia_1975@yahoo.com', NULL, NULL, '2016-01-25 17:00:26', '2016-01-25 17:00:26', 0, 0),
(203, NULL, 'Carine.nabil@gmail.com', NULL, NULL, '2016-01-31 23:26:56', '2016-01-31 23:26:56', 0, 0),
(204, NULL, 'tuka@universe-eg.com', NULL, NULL, '2016-02-04 13:55:45', '2016-02-04 13:55:45', 0, 0),
(205, NULL, 'amirsahban@gmail.com', NULL, NULL, '2016-02-07 14:37:38', '2016-02-07 14:37:38', 0, 0),
(206, NULL, 'Hedayatn2003@yahoo.com', NULL, NULL, '2016-02-11 00:50:12', '2016-02-11 00:50:12', 0, 0),
(207, NULL, 'phantom.memo@yahoo.com', NULL, NULL, '2016-02-13 22:31:59', '2016-02-13 22:31:59', 0, 0),
(208, NULL, 'Daliasakhawy@yahoo.com', NULL, NULL, '2016-02-16 12:02:27', '2016-02-16 12:02:27', 0, 0),
(209, NULL, 'fatimaothman1987@gmail.com', NULL, NULL, '2016-02-18 12:08:36', '2016-02-18 12:08:36', 0, 0),
(210, NULL, 'Alaa.tantawi@gmail.com', NULL, NULL, '2016-02-18 19:33:05', '2016-02-18 19:33:05', 0, 0),
(211, NULL, 'Mahi12008@hotmail.com', NULL, NULL, '2016-02-23 01:59:25', '2016-02-23 01:59:25', 0, 0),
(212, NULL, 'suzan.salem@hotmail.com', NULL, NULL, '2016-02-25 12:27:23', '2016-02-25 12:27:23', 0, 0),
(213, NULL, 'Kholoud_ellithy@yahoo.com', NULL, NULL, '2016-02-26 09:46:02', '2016-02-26 09:46:02', 0, 0),
(214, NULL, 'michaelmaged94@gmail.com', NULL, NULL, '2016-02-27 23:00:48', '2016-02-27 23:00:48', 0, 0),
(215, NULL, 'hani.naiem@hotmail.com', NULL, NULL, '2016-03-01 09:19:22', '2016-03-01 09:19:22', 0, 0),
(216, NULL, 'eimanbadwy@gmail.com', NULL, NULL, '2016-03-19 17:17:37', '2016-03-19 17:17:37', 0, 0),
(217, NULL, 'wafaa.shoukry2@gmail.com', NULL, NULL, '2016-03-20 01:00:29', '2016-03-20 01:00:29', 0, 0),
(218, NULL, 'hamadaeldaley116@yahoo.com', NULL, NULL, '2016-03-22 19:32:16', '2016-03-22 19:32:16', 0, 0),
(219, NULL, 'maikhattab15@gmail.com', NULL, NULL, '2016-03-26 17:41:42', '2016-03-26 17:41:42', 0, 0),
(220, NULL, 'basma-khater@outlook.com', NULL, NULL, '2016-03-28 11:54:16', '2016-03-28 11:54:16', 0, 0),
(221, NULL, 'omarkhaled97@hotmail.com', NULL, NULL, '2016-04-10 23:51:12', '2016-04-10 23:51:12', 0, 0),
(222, NULL, 'hala.3ssal@gmail.com', NULL, NULL, '2016-04-17 09:20:24', '2016-04-17 09:20:24', 0, 0),
(223, NULL, 'Found.amin87@hotmail.com', NULL, NULL, '2016-04-21 14:06:27', '2016-04-21 14:06:27', 0, 0),
(224, NULL, 'ranias86@hotmail.com', NULL, NULL, '2016-04-21 20:39:36', '2016-04-21 20:39:36', 0, 0),
(225, NULL, 'gurunagy@gmail.com', NULL, NULL, '2016-04-27 15:47:00', '2016-04-27 15:47:00', 0, 0),
(226, NULL, 'yasserfayed69@yahoo.com', NULL, NULL, '2016-04-28 17:39:00', '2016-04-28 17:39:00', 0, 0),
(227, NULL, 'Sherwina78@yahoo.com', NULL, NULL, '2016-05-03 14:46:09', '2016-05-03 14:46:09', 0, 0),
(228, NULL, 'naremanmagdyy@gmail.com', NULL, NULL, '2016-05-09 23:04:27', '2016-05-09 23:04:27', 0, 0),
(229, NULL, 'lobna.maraghy@gmail.com', NULL, NULL, '2016-05-13 15:43:53', '2016-05-13 15:43:53', 0, 0),
(230, NULL, 'Esraaelsaady1988@live.com', NULL, NULL, '2016-05-14 17:26:06', '2016-05-14 17:26:06', 0, 0),
(231, NULL, 'smouniry@yahoo.com', NULL, NULL, '2016-05-20 02:38:58', '2016-05-20 02:38:58', 0, 0),
(232, NULL, 'hanyabdellha@gmail.com', NULL, NULL, '2016-05-22 16:02:18', '2016-05-22 16:02:18', 0, 0),
(233, NULL, 'rashaaezzzat@gmail.com', NULL, NULL, '2016-05-22 16:11:12', '2016-05-22 16:11:12', 0, 0),
(234, NULL, 'nohanagymahmoud@gmail.com', NULL, NULL, '2016-05-24 14:02:40', '2016-05-24 14:02:40', 0, 0),
(235, NULL, 'mohamad.kamel@live.com', NULL, NULL, '2016-05-24 16:29:16', '2016-05-24 16:29:16', 0, 0),
(236, NULL, 'rizkshereen9@gmail.com', NULL, NULL, '2016-05-27 18:30:57', '2016-05-27 18:30:57', 0, 0),
(237, NULL, 'sarahsalemb@gmail.com', NULL, NULL, '2016-05-28 11:38:27', '2016-05-28 11:38:27', 0, 0),
(238, NULL, 'epsf.amr.wafeek@gmail.com', NULL, NULL, '2016-05-29 04:39:41', '2016-05-29 04:39:41', 0, 0),
(239, NULL, 'yahiamohamed902@yahoo.com', NULL, NULL, '2016-06-03 14:57:13', '2016-06-03 14:57:13', 0, 0),
(240, NULL, 'mohamedaly625@gmail.com', NULL, NULL, '2016-06-09 04:01:08', '2016-06-09 04:01:08', 0, 0),
(241, NULL, 'fashvio@gmail.com', NULL, NULL, '2016-06-09 19:17:16', '2016-06-09 19:17:16', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `team_members`
--

CREATE TABLE IF NOT EXISTS `team_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `biography` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `linkedin` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `type` int(11) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `team_members`
--

INSERT INTO `team_members` (`id`, `name`, `position`, `biography`, `image`, `mail`, `linkedin`, `created`, `updated`, `type`, `approved`, `weight`) VALUES
(14, 'Ahmed El Aawar', 'CEO & Lead Instructor', '<p>\r\n	Ahmed is the founder and CEO of Life Coaching Egypt, with more than18 years of progressively responsible leadership positions in multi-national and local companies directing more than 2,000 employeesand up to 15 direct reports of senior department heads. Posts held by Ahmed were:</p>\r\n<ul>\r\n	<li>\r\n		McDonalds Operations Manager</li>\r\n	<li>\r\n		McDonalds Training Director</li>\r\n	<li>\r\n		KFC Egypt General Manager</li>\r\n	<li>\r\n		Vice President Business Development El Sewedy Group</li>\r\n	<li>\r\n		Vice Chairman Siemens</li>\r\n	<li>\r\n		Board member at several companies in the industries of</li>\r\n	<li>\r\n		Petroleum, manufacturing and retail.</li>\r\n</ul>\r\n<p>\r\n	Ahmed&nbsp; now being a professional Coach (First international accredited coach in Egypt) and Psychologist leads workshops all around the world with significant success, handles culture management projects with large and middle size businesses. Ahmed holds an Executive MBA in Management Strategy, Georgetown, USA, Master Degree In Cognitive Psychology Columbia State University, He&rsquo;s PhD. Student in Organizational Psychology, University of London, Certified Professional Co Active Coach (CCPC), the Coaches Training Institute (CTI).</p>\r\n<ul>\r\n	<li>\r\n		Accredited Certified Coach (ACC) from the International Coach Federation (ICF)</li>\r\n	<li>\r\n		Certified Cognitive Behavioral Therapist (CBT), Arthur Freeman Institute, USA</li>\r\n	<li>\r\n		Graduate from The Co Active Accredited Leadership Program, Sitges, Spain.</li>\r\n</ul>\r\n<p>\r\n	Ahmed currently travels all around the world as a keynote speaker, managing culture transformation, leading leadership Programs and Value Based programs.</p>\r\n<p>\r\n	Ahmed has consistent appearance in Media and has a consistent Radio Program that is heard from more than 5 million people.</p>\r\n', '253__533x800__34179.jpg', 'aawar@lifecoachingegypt.com', '', '2014-05-04 12:18:59', '2014-06-29 12:37:47', 0, 1, 0),
(15, 'Marijke Van Liemt', 'Coach & Instructor', '<p>\r\n	Marijke&rsquo;s strength is translating complex issues to practical solutions. With her business background, international experience and intercultural know how, Marijke brings a unique perspective to executive coaching and global leadership development. Through her coaching, clients develop the skills to become true global leaders and to maximize their effectiveness in a variety of global business contexts. In addition to coaching, Marijke develops and delivers in-house training for effectiveness of (multicultural teams), facilitates diversity awareness workshops and gives intercultural seminars for groups and individuals.</p>\r\n<p>\r\n	Marijke has lived and worked in the Netherlands, Brazil, the USA, and Austria before moving to Egypt in 2011. Prior to founding her business in 2003, she worked 10 years as a senior executive in the financial sector in various positions, including Mergers &amp; Acquisition, Sales, and Financial Restructuring and Recovery. Marijke has lectured at the Donau University in Krems and the University of Applied Sciences BFI in Vienna</p>\r\n<ul>\r\n	<li>\r\n		Masters Degree in Economics (University of Groningen, the Netherlands)</li>\r\n	<li>\r\n		Masters Degree in Intercultural Competencies (Donau University Krems, Austria)</li>\r\n	<li>\r\n		Certified Coach (ICI, Brazil)</li>\r\n	<li>\r\n		Intercultural Trainer (Interchange Institute, USA)</li>\r\n	<li>\r\n		Certificate in Organizational Development &amp; Leadership (New York University,USA)</li>\r\n</ul>\r\n', 'marijke_a2__800x659__38944.jpg', 'mvanliemt@lifecoachingegypt.com', '', '2014-05-05 09:28:30', '2014-06-30 16:33:39', 0, 1, 0),
(17, 'Monica Larrabeiti', 'Coach & Instructor', '<p>\r\n	Monica is an executive and teams&rsquo; coach. She combines it with training executives in coaching, leadership, mentoring and sales skills. She collaborates with the Francisco de Vitoria University in Madrid (Spain) as a supervisor for coaches, trainer and coach for their successful Dialogic Coaching Programme as well as in their Leadership Master. She has coached and trained for Etisalat, Al Ahram- Heineken, Vodafone, Zurich, Desigual, Airbus, Nestl&eacute;, Bank Sabadell, Airbus, Telefonica etc. Monica is an ICF certified coach with more than 1500 coaching hours. She helps people find their inner talent and develop it to its full potential in order to maximize results in their organizations and their lives. Before founding her freelance business in 2008, she developed a successful career at P&amp;G for 16 years as an executive manager in Sales and Marketing leading multifunctional and intercultural teams up to 200 people. &nbsp;She speaks Spanish, English and French.</p>\r\n<ul>\r\n	<li>\r\n		Professional Certified Coach (PCC) by ICF (International Coach Federation) (+1500hrs)</li>\r\n	<li>\r\n		Co-active and Ontologic Coach (CTI and European School of coaching)</li>\r\n	<li>\r\n		Graduate in International Leadership and Coaching CTI (Coaches Training Institute)</li>\r\n	<li>\r\n		Organizations and Relationships Systemic Coaching CRR (Center for Right Relationship)</li>\r\n	<li>\r\n		NLP Practitioner (Neuro-linguistic Programming) SCT Systemic</li>\r\n	<li>\r\n		Advanced Systemic Constellations with Bert Hellinger and Svagito Liebermeister</li>\r\n	<li>\r\n		Counselling Skills Training</li>\r\n	<li>\r\n		Systemic Pedagogy</li>\r\n	<li>\r\n		Masters Degree in Economics and Business Administration. Deusto University. Spain</li>\r\n	<li>\r\n		Enneagram. Enneagram Institute NY - USA</li>\r\n</ul>\r\n', 'Monica_f5acb.jpg', 'monica.larrabeiti@lifecoachingegypt.com', '', '2014-05-05 15:25:43', '2014-06-29 12:21:41', 0, 1, 0),
(18, 'Shady Barakat', 'Coach & Instructor', '<p>\r\n	Shady is a coach and a corporate trainer delivering topics of Leadership, Conflict Resolution and Emotional Intelligence.&nbsp; Shady&rsquo;s real strength lies in his ability to explain sophisticated theories in a simple and humorous manner,&nbsp; giving people deep insights and understanding of the concept and its applications in the day to day life.&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Shady has a corporate experience of more than 8 years in well Known multinational firms (Mars chocolates, Vodafone and Etisalat) where he has worked in the commercial areas and joined Vodafone&rsquo;s Program for youth Development (YLI) as a trainer.&nbsp; He then had his entrepreneurial experience in founding an online business that was ranked by Google as one of the top 20 startups in Egypt (2012, &ldquo;Start with Google&rdquo; competition).&nbsp; He then decided to focus on training, coaching and studying human behavior on a full time basis after he completed an assignment with reputable companies like MTN, EMC, TE Data and Rich Bake</p>\r\n<p>\r\n	&nbsp;</p>\r\n<ul>\r\n	<li>\r\n		Co-active Coach, Coach Training Institute, CTI, Turkey.</li>\r\n	<li>\r\n		Certified Trainer by JS International</li>\r\n	<li>\r\n		TEDx AUC speaker, Egypt 2012.</li>\r\n</ul>\r\n', 'CTI_TURKEY__800x533__29420.jpg', 'shady.barakat@lifecoachingegypt.com', '', '2014-05-05 16:28:50', '2014-05-20 03:14:21', 0, 1, 0),
(20, 'Marcel Herwegh', 'Coach & Instructor', '<p>\r\n	Marcel has over ten years of corporate experience in customer care, management, coaching and training. He started his own coaching and training company in 2010 and is also a board member of a Dutch nonprofit organization.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	The focus of his coaching and training is the continuous and dynamical process of attuning who we are to the world around us. He is inspired by western and eastern psychology and specialized in personal leadership topics.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	His coaching clients range from unemployed people to senior executives. He works in an international context with various universities and multinationals in leadership development programs. &nbsp;&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	As certified e-coach he supervised over 150 coaches in their training to become an e-coach. He (co-)designs training programs and writes about personal leadership. &nbsp;Marcel has more than 1000 hours of team and personal coaching experience and speaks English and Dutch.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<ul>\r\n	<li>\r\n		Master&rsquo;s degree in Cultural Anthropology (Vrije Universiteit Amsterdam)</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Bachelor&rsquo;s degree in Education Policy (Universiteit van Amsterdam)</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Bachelor&rsquo;s degree in Arts (Fontys Hogeschool Tilburg)</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Graduated from the CTI Leadership program</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Trained in Co-Active (CTI), Organization and Relationship Systems Coaching (CRR) and Emergent Essence Dynamics (Troy Yorke).</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Certified e-coach (eCoachPro)</li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		Member of the Dutch coaching association (Nobco), a registered member of the Dutch association for career counseling and outplacement coaches (Noloc) and member of the International Coach Federation.</li>\r\n</ul>\r\n', 'IMG_3465.JPG_48ee4.jpg', 'mherwegh@lifecoachingegypt.com', '', '2014-06-29 12:25:48', '2014-06-30 10:37:57', 0, 1, 0),
(23, 'Saad E. A. Sallam ', 'Chairman', '<p>\r\n	Dr. Saad is the Chairman of Paradise Capital, which is the holding company for Olympic Group financial investment Co., B-Tech, Namaa for Development, Mathal holdings Co. for small and medium enterprises, a position he has held starting 2009. He is a member of The Federation of Egyptian Industries, The Egyptian Businessmen Association, American Chamber of Commerce, German Arab Chamber of Industry and Commerce (AHK), as well as the Board of Trustees for the General Authority for Investment (GAFI), and Board of Trustees for the Sinai University. He holds a Bachelors in Civil Engineering from Cairo University and Masters and PhD in Civil Engineering from McMastre University in Hamilton Ontario Canada.Dr. Saad is the Chairman of Paradise Capital, which is the holding company for Olympic Group financial investment Co., B-Tech, Namaa for Development, Mathal holdings Co. for small and medium enterprises, a position he has held starting 2009. He is a member of The Federation of Egyptian Industries, The Egyptian Businessmen Association, American Chamber of Commerce, German Arab Chamber of Industry and Commerce (AHK), as well as the Board of Trustees for the General Authority for Investment (GAFI), and Board of Trustees for the Sinai University. He holds a Bachelors in Civil Engineering from Cairo University and Masters and PhD in Civil Engineering from McMastre University in Hamilton Ontario Canada.</p>\r\n', 'Saad_1_cfcfb.jpg', '', '', '2014-07-18 16:12:05', '2014-07-18 16:15:01', 1, 1, 1),
(24, 'Ahmed El Aawar', 'Founder', '<p>\r\n	Ahmed is the founder and CEO of Life Coaching Egypt, with more than 18 years of progressively responsible leadership positions in multi-national and local companies such as: McDonald&rsquo;s, KFC, El Seweedy Group.&nbsp; After a long corporate career Ahmed decided to study psychology and establish LCE with the vision of creating real transformation in individuals and organizations.&nbsp; Ahmed holds an executive MBA in Management Strategy from Georgetown University, a Masters Degree in Cognitive Psychology from Colombia State University and currently he is a PhD student in Organizational Psychology at the University of London.&nbsp; In addition to that, Ahmed is an Accredited Certified Coach (ACC) from the International Coach Federation and a certified Cognitive Behavioral Therapist (CBT) form the Arthur Freeman Institute in the USA.&nbsp;</p>\r\n', '253__533x800__81db1.jpg', '', '', '2014-07-18 16:17:45', '2014-12-09 21:05:40', 1, 1, 2),
(26, 'Mohamed El Sawy', 'Board Member', '<p>\r\n	Mohamed is the General Manager of Alamia Publishing and Advertising Co. since 1980. He is also the General Manager of Alamia Road Signs Co. He is the founder and director of the first private culture center in 2003 under the name of Abdel Monem El Sawy, &ldquo;El Sawy Culturewheel, El Sakia.&rdquo; Since its inception it attracted audiences from all walks of life and to date it&rsquo;s become a hub for all types of arts at affordable prices. Mohamed is a member of the American Chamber of Commerce, the German Chamber of Commerce, National Youth Council, the Rotary Club Rhein-Nile, the Motorsports Committee of the Automobile and Touring Club of Egypt, the Union of the German Graduates in Cairo, Egyptian Advertising Committee, he is a board member in Gezira Club, co-founder of the EJB (the Egyptian Junior Businessmen), and President of Zamalek Development Committee. His passion for the arts led him to write and produce ten marionette plays, while also establishing the Om Kolthoum returns anew program and subsequently Abdel Halim Hafez and Farid Elatrash works as well as comic plays. He holds a Bachelor&rsquo;s degree in Fine Arts from Helwan Univeristy.</p>\r\n', 'Mohamed_El_Sawy_2_0715e.jpg', '', '', '2014-07-18 16:23:54', '2014-07-18 16:23:54', 1, 0, 3),
(27, 'Ibrahim Tarek El Attar', 'Board Member', '<p>\r\n	Ibrahim is the CEO of Experts Group, manufacturer in the food industry. He is also a board member in Winning Co. for Commercial Agencies and Distribution. He holds a Bachelors from MSA University in Marketing and International business.</p>\r\n', 'Ibrahim_El_Attar_Crop_2_4cad4.jpg', '', '', '2014-07-18 16:33:20', '2014-07-18 16:33:20', 1, 0, 4),
(28, 'Amr M. El-Kadi ', '', '', '', '', '', '2014-07-18 16:48:07', '2014-07-18 16:48:07', 1, 0, 5),
(29, 'Mostafa Ghalwash ', 'Board Member', '<p>\r\n	Mostafa is the Managing Director and major shareholder of Yadco Petroleum Services since 1989. His career path started as maintenance and sales engineer for heavy equipment then as operations manager for Egyptian American and Aqua Water Well Drilling Cos. until he became a founder of Yadco Petroleum Services in 1989. He has always been working in the private sector and also held major investments in the Food and Entertainment industries. He became a founding board member of LCE after attending several workshops with Ahmed El Aawar with the intention and strong belief that spreading this information and experience will strongly benefit anyone (no matter what profession or age) and thereby our communities as a whole. He holds a Bachelors degree in Mechanical Engineering from the American University in Cairo, is a member of the Egyptian Engineers Syndicate, Society of Petroleum Engineers and is a contributor and active member with several Egyptian NGO&rsquo;s dedicated to the betterment of Egyptian society.</p>\r\n', 'Mr._Mostafa_photo_504c3.jpg', '', '', '2014-07-18 16:52:29', '2014-07-18 16:52:29', 1, 0, 6);

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE IF NOT EXISTS `testimonials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `body` text,
  `image` varchar(255) NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `weight` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`id`, `name`, `position`, `body`, `image`, `approved`, `featured`, `created`, `updated`, `weight`) VALUES
(1, 'Waseem Darwish', 'Head of Strategy and Planning Office', '<p>\r\n	Anticipating, buy in, and then fully immersed! I am now willing to try and fail and keep trying</p>\r\n', 'Vodafone_Logo_Crop_2_test_b6ca2.jpg', 1, 1, '2014-04-06 01:10:41', '2014-06-30 11:02:07', 9),
(2, 'Karim Mourad', 'Product Manager', '<p>\r\n	Know yourself as you haven&#39;t before</p>\r\n', 'Sanofi_Logo_Crop_2_test_0eba9.jpg', 1, 0, '2014-04-12 00:10:30', '2014-08-18 13:09:33', 7),
(3, 'Magdy Nessim', 'Franchise Manager', '<p>\r\n	It&#39;s not a traditional workshop, It dug into the deeper side of myself and helped me realize new things deep inside.</p>\r\n', 'Sanofi_Logo_Crop_2_test_1e649.jpg', 1, 1, '2014-05-28 14:08:39', '2014-06-30 11:02:50', 11),
(4, 'Daniel Jaeger', 'Pre-sales Director ', '<p>\r\n	Weeks after the workshop, I am still impressed by the results of the 2 day workshop. I am really looking forward to take our team to the next level with Ahmed El Aawar</p>\r\n', 'Alcatel_Lucent_2_9fcc6.jpg', 1, 1, '2014-05-28 18:47:28', '2014-08-18 13:05:32', 5),
(5, 'Nivine Rushdy', 'HR Senior Manager', '<p>\r\n	Many thanks to the whole team for a world class experience!</p>\r\n', 'Etisalat_Logo_Crop_3_tets_46f86.jpg', 1, 1, '2014-05-29 16:47:25', '2014-06-30 11:06:15', 10),
(6, 'Rania Salah', 'Head of People Capabilities', '<p>\r\n	A great different new learning experience! My key learning was the Self-confidence model and in fact everything.</p>\r\n', 'Vodafone_Logo_Crop_2_test_00c26.jpg', 1, 0, '2014-06-25 11:50:33', '2014-06-30 11:04:28', 4),
(7, 'Yehia Hafez', 'Head of Planning & Development', '<p>\r\n	It was a very different training/workshop for me that I really enjoyed, full of new experience and information.</p>\r\n', 'Vodafone_Logo_Crop_2_test_4b285.jpg', 1, 0, '2014-06-25 11:52:26', '2014-06-30 11:06:59', 12),
(8, 'Essam Sobh', 'Plant Manager', '<p>\r\n	I was impressed of how much I didn&#39;t know about my own self. I feel I have more command of myself, I am now more of the guy who has the PlayStation Player in his hands rather than being a character on the screen!</p>\r\n', 'Fayrouz_Logo_Crop_4_test_bc334.jpg', 1, 1, '2014-06-25 12:41:49', '2014-06-30 11:00:49', 6),
(9, 'Sally Soliman', 'Head of Content & Production', '<p>\r\n	This is a journey to the core of your soul. An opportunity to get in-touch with what really matters. A springboard to inner peace. The workshop provides a diversity of self-empowerment tools; if practiced, I believe, could evolve for its master into the Power of Living</p>\r\n', 'TPA_Media_Logo_Crop_2_test_1279f.jpg', 1, 0, '2014-06-25 12:49:50', '2014-08-18 13:08:20', 2),
(10, 'Amr El Helaly', 'CEO', '<p>\r\n	This workshop holds the secret to self management</p>\r\n', 'Rich_Bake_Logo_Crop_1_test_d30a1.jpg', 1, 0, '2014-06-25 12:57:18', '2014-06-30 11:00:17', 4),
(11, 'Dr. Dalia Abdel Kader     ', 'VP Marketing', '<p>\r\n	The Power of Decision workshop is a step towards reaching out for the power within you, a step towards creating the change you want rather than accommodating change</p>\r\n', 'AAI_Logo_Crop_3_test_e6f36.jpg', 1, 0, '2014-06-25 13:05:12', '2014-06-30 10:59:49', 3),
(12, 'Ahmed Naim', 'Marketing Director', '<p>\r\n	Attending the workshop raised my awareness through a process similar to second birth with all the trauma and cries... it was worth it!</p>\r\n', 'Smart_Village_Logo_Crop_2_test_e3544.jpg', 1, 0, '2014-06-25 13:17:48', '2014-06-30 11:07:22', 13),
(13, 'Mona Arishi', 'Quality Function Manager', '<p>\r\n	The Power of Decision is one workshop you will never regret coming to</p>\r\n', 'IBM_Logo_Crop_6_test_97559.png', 1, 0, '2014-06-25 13:24:42', '2014-06-30 11:05:45', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `gender` tinyint(1) NOT NULL DEFAULT '1',
  `email` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `group_id` int(11) NOT NULL,
  `confirm_code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username_2` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `gender`, `email`, `image`, `username`, `password`, `group_id`, `confirm_code`) VALUES
(1, 'Mohamed Elsayed', 1, 'me@mohamedelsayed.net', '', 'elsayed', 'a35d9bbf0dc74e631486c1be1ec6ca8ba2335e4b', 0, '5356802d-4358-448b-9f07-71c1c0b91184'),
(2, 'Mohamed Elsayed', 0, 'lce@mohamedelsayed.net', '', 'admin', '88326122b923be10c6b1dbfe118867c886b15c49', 0, '53568126-f530-4224-8d5a-5a37c0b91184'),
(3, 'Shady Barakat', 1, 'shady.a.barakat@gmail.com', '', 'shadybarakat', 'eb017f54162e5c65733c5063f2434f1bce4578ac', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `values`
--

CREATE TABLE IF NOT EXISTS `values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `body` text,
  `image` varchar(255) DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `weight` int(11) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `values`
--

INSERT INTO `values` (`id`, `title`, `body`, `image`, `created`, `updated`, `weight`, `approved`) VALUES
(1, 'ِAuthenticity', '<p>\r\n	<span style="font-size:18px;">We believe that true pride comes with being vulnerable, imperfect and real. &nbsp;We would rather work on ourselves than claim perfection.</span></p>\r\n', 'icon_about_values_authenticity_ce71f.png', '2016-06-11 21:06:58', '2016-06-11 21:06:58', 1, 1),
(2, 'Passion', '<p>\r\n	<span style="font-size:18px;">We do what we do for something more than the cash. We believe that passion is an excellent shortcut to dedication </span></p>\r\n', 'icon2_about_values_passion_5293a.png', '2016-06-11 21:07:32', '2016-06-11 21:07:32', 2, 1),
(3, 'Quality', '<p>\r\n	<span style="font-size:18px;">We do things well not to look good, but for the sake of who we want to become in the process of improvement.</span></p>\r\n', 'icon3_about_values_guality_6c9cc.png', '2016-06-11 21:08:10', '2016-06-11 21:08:10', 3, 1),
(4, 'Responsibility', '<p>\r\n	<span style="font-size:18px;">We believe that we always have a choice and take responsibility for the things we have done and have not done</span></p>\r\n', 'icon4_about_values_responsibility_4f2bd.png', '2016-06-11 21:08:37', '2016-06-11 21:08:37', 4, 1),
(5, 'Knowledge', '<p>\r\n	<span style="font-size:18px;">We believe in a deeper sense of knowledge than just information. We learn to become wiser</span></p>\r\n', 'icon5_about_values_knowledge_59de5.png', '2016-06-11 21:08:59', '2016-06-11 21:08:59', 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE IF NOT EXISTS `videos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `hits` int(11) NOT NULL,
  `node_id` int(11) NOT NULL DEFAULT '0',
  `content_id` int(11) NOT NULL DEFAULT '0',
  `event_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
